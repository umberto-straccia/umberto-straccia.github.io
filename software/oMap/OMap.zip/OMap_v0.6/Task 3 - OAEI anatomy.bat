@echo off

rem author: R. Troncy - IST/CNR - 22/08/2005

rem -----------------
rem    MAIN SCRIPT
rem -----------------

echo **  oMap - Raphael Troncy - 22/08/2005 **
echo **  OAEI Contest 2005 - Banff, Canada  **
echo **   Data from the 2005 OAEI Campaign  **
echo **   Anatomy tests                     **

set WORK_DIRECTORY="D:\ERCIM\CNR Pise\Implementation\OMap"
set OAEI_DIRECTORY=D:\ERCIM\Ontologies\anatomy
set BASE_URI=file:///D:/ERCIM/Ontologies/anatomy

@echo.
set sourceOnto=%BASE_URI%/FMA.owl
set targetOnto=%BASE_URI%/OpenGALEN.owl

set method=it.cnr.isti.OMapAlignment
set renderer=fr.inrialpes.exmo.align.impl.renderer.RDFRendererVisitor
set resultFile=%BASE_URI%/isti-cnr-anatomy.rdf

cd %OAEI_DIRECTORY%

del isti-cnr-anatomy.rdf

java -jar %WORK_DIRECTORY%/lib/omap.jar -i %method% -r %renderer% -o %resultFile% %sourceOnto% %targetOnto%

cd %WORK_DIRECTORY%

set WORK_DIRECTORY=
set OAEI_DIRECTORY=
set BASE_URI=

echo **  END SCRIPT **

pause
