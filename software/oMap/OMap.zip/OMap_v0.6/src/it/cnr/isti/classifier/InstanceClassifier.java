/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.semanticweb.owl.model.*;
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentProcess;
import org.semanticweb.owl.align.Cell;
import org.semanticweb.owl.align.Parameters;
import fr.inrialpes.exmo.align.impl.BasicAlignment;

import it.cnr.isti.util.Tuple;

/** The Instance Classifier Class.
@author Rapha�l Troncy
 */

public abstract class InstanceClassifier extends Classifier implements AlignmentProcess {

	protected Hashtable sourceInstances = null;
	protected Hashtable targetInstances = null;
	private String RDFSLabel = "http://www.w3.org/2000/01/rdf-schema#label";

	public InstanceClassifier(OWLOntology onto1, OWLOntology onto2, int instanceDepth) {

		super(onto1, onto2);
		sourceInstances = collectAllInstances(onto1, instanceDepth);
		targetInstances = collectAllInstances(onto2, instanceDepth);
	}

	private Hashtable collectAllInstances(OWLOntology onto, int d) {

		// The hashtable containing all individuals
		// The keys are OWLNamedObject (Class, ObjectProperty or DatatypeProperty)
		// The values are Vector containing a StringTokenizer for each value

		// Strategy Summary: parameter d = depth of the structure to enter while collecting the values
		// Identified individuals: collect the value of the rdfs:label annotation property of the individual
		//		Note: we could also enter in the structure for the identified individuals, but it is NOT done now !!!
		// Anonymous individuals: collect all pairs "<property_name> <property_values>" of the individual
		// DataProperty: collect all the data values
		// ObjectProperty: collect all the types (OWLClass) of the filler and for each filler, re-apply the function with the parameter depth-1

		Hashtable allInstances = new Hashtable();
		OWLNamedObject key = null;
		String value = null;
		try {
			Set individuals = onto.getIndividuals();
			for (Iterator i=individuals.iterator(); i.hasNext();) {
				OWLIndividual anInstance = (OWLIndividual)i.next();
				Set types = anInstance.getTypes(onto);
				for (Iterator j=types.iterator(); j.hasNext();) {
					OWLDescription aType = (OWLDescription)j.next();
					// If the OWLDescription is an OWLClass
					if (aType instanceof OWLClass) {
						value = getInstanceValues(anInstance, onto, d);
					}
					// Should NOT be possible?
					else {
						System.out.println("ERROR: Encountering " + aType + " (which is not an OWLClass) while gathering the instances !");
						value = "OTHER_THAN_CLASS";
					}
					key = (OWLNamedObject)aType;
					if (value != null)
						allInstances = fill(allInstances, key, value);
				}
				//The individual IS NOT linked to the OWLOntology Object (e.g. rdf:nil or the ontology itself)
				if (!types.isEmpty()) {
					// Collect all the data values, for each datatype properties of this individual
					Map DPValues = anInstance.getDataPropertyValues(onto);
					for (Iterator j=DPValues.keySet().iterator(); j.hasNext();) {
						key = (OWLNamedObject)j.next();
						HashSet allValues = (HashSet)(DPValues.get((OWLDataProperty)key));
						value = "";
						for (Iterator k=allValues.iterator(); k.hasNext();) {
							OWLDataValue dv = (OWLDataValue)k.next();
							value = value + dv.getValue().toString() + " ";
						}
						allInstances = fill(allInstances, key, value);
					}
					// Collect all the types (OWLClass) of the filler, for each object properties of this individual
					Map OPValues = anInstance.getObjectPropertyValues(onto);
					for (Iterator j=OPValues.keySet().iterator(); j.hasNext();) {
						key = (OWLNamedObject)j.next();
						HashSet allFillers = (HashSet)(OPValues.get((OWLObjectProperty)key));
						value = "";
						for (Iterator k=allFillers.iterator(); k.hasNext();) {
							OWLIndividual aFiller = (OWLIndividual)k.next();
							Set fillerTypes = aFiller.getTypes(onto);
							for (Iterator l=fillerTypes.iterator(); l.hasNext();) {
								OWLDescription desc = (OWLDescription)l.next();
								if (((OWLNamedObject)desc).getURI().getFragment() == null)
									value = value + ((OWLNamedObject)desc).getURI().toString() + " ";
								else
									value = value + ((OWLNamedObject)desc).getURI().getFragment() + " ";
							}
							value = value + getInstanceValues(aFiller, onto, d-1) + " ";
						}
						allInstances = fill(allInstances, key, value);
					}
				}
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return allInstances;
	}

	private String getInstanceValues(OWLIndividual anInstance, OWLOntology onto, int d) {

		OWLNamedObject key = null;
		String value = null;
		try {
			// The individual is http://www.w3.org/1999/02/22-rdf-syntax-ns#nil
			if (anInstance.getTypes(onto).isEmpty())
				return "NIL";
			// The individual is NOT anonymous, i.e. the individual has an identifier (a URI)
			if (!anInstance.isAnonymous()) {
				// Collect the value of the rdfs:label annotation property of this individual
				Set annotations = anInstance.getAnnotations(onto);
				for (Iterator k=annotations.iterator(); k.hasNext(); ) {
					OWLAnnotationInstance anAnnotation = (OWLAnnotationInstance)k.next();
					if (anAnnotation.getProperty().getURI().toString().equals(RDFSLabel)) {
						value = anAnnotation.getContent().toString();
						if (value == null)
							value = "NO_LABEL_FOUND";
					}
				}
			}
			// The individual is anonymous
			else {
				// According to the depth parameter d, collect the pairs "<property_name> <property_values>" of this individual
				value = "";
				if (d > 0) {
					// For each datatype properties, collect all the data values
					Map DPValues = anInstance.getDataPropertyValues(onto);
					for (Iterator j=DPValues.keySet().iterator(); j.hasNext();) {
						key = (OWLNamedObject)j.next();
						HashSet allValues = (HashSet)(DPValues.get((OWLDataProperty)key));
						value = value + key.getURI().getFragment() + " ";
						for (Iterator k=allValues.iterator(); k.hasNext();) {
							OWLDataValue dv = (OWLDataValue)k.next();
							value = value + dv.getValue().toString() + " ";
						}
					}
					// For each object properties, re-apply the function for all fillers, decreasing the depth parameter
					Map OPValues = anInstance.getObjectPropertyValues(onto);
					for (Iterator j=OPValues.keySet().iterator(); j.hasNext();) {
						key = (OWLNamedObject)j.next();
						HashSet allFillers = (HashSet)(OPValues.get((OWLObjectProperty)key));
						value = value + key.getURI().getFragment() + " ";
						for (Iterator k=allFillers.iterator(); k.hasNext();) {
							OWLIndividual aFiller = (OWLIndividual)k.next();
							value = value + getInstanceValues(aFiller, onto, d-1) + " ";
						}
					}
				}
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return value;
	}

	private Hashtable fill(Hashtable allInstances, OWLNamedObject key, String value) {

		// Remove all special characters ... useful when applying Lucene for kNN
		value = value.replaceAll("[(){}~*?:]", "");
		// Add the key/value in the hashtable
		if (allInstances.containsKey(key)) {
			Vector v = (Vector)allInstances.get(key);
			v.add(value);
		}
		else {
			Vector v = new Vector();
			v.add(value);
			allInstances.put(key, v);
		}
		return allInstances;
	}

	public Vector generatePossibleMappings() {

		String ns1, ns2;
		Vector mappings = new Vector();
		try {
			for (Iterator i=sourceInstances.keySet().iterator(); i.hasNext();) {
				OWLNamedObject sElem = (OWLNamedObject)i.next();
				ns1 = sElem.getURI().getScheme() + ":" + sElem.getURI().getSchemeSpecificPart();
				if (onto1.getLogicalURI().toString().equals(ns1)) {
					for (Iterator j=targetInstances.keySet().iterator(); j.hasNext();) {
						OWLNamedObject tElem = (OWLNamedObject)j.next();
						ns2 = tElem.getURI().getScheme() + ":" + tElem.getURI().getSchemeSpecificPart();
						if (onto2.getLogicalURI().toString().equals(ns2)) {
							if ((sElem instanceof OWLClass) && (tElem instanceof OWLClass) ||
								(sElem instanceof OWLProperty) && (tElem instanceof OWLProperty)) {
								Tuple mappingRule = new Tuple(new Object[4]);
								if ((sElem instanceof OWLClass) && (tElem instanceof OWLClass)) {
									mappingRule.set(0, "CLASS");						
									mappingRule.set(1, (OWLClass)sElem);
									mappingRule.set(2, (OWLClass)tElem);
								}
								else if ((sElem instanceof OWLProperty) && (tElem instanceof OWLProperty)) {
									mappingRule.set(0, "PROPERTY");						
									mappingRule.set(1, (OWLProperty)sElem);
									mappingRule.set(2, (OWLProperty)tElem);
								}
								else
									System.err.println("ERROR ! Should NOT encounter the elements " + sElem.toString() + " and " + tElem.toString());

								mappings.addElement(mappingRule);
							}
						}
					}
				}
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return mappings;
	}

	protected abstract double predict(OWLNamedObject Si, OWLNamedObject Tj);

	public void align(Alignment alignment, Parameters params) throws AlignmentException, OWLException {

		Vector instanceMappings = (Vector)params.getParameter("instanceMappings");
		Vector mappingsFound = (Vector)params.getParameter("mappingsFound");
		Vector currentMappings = null;
		if (mappingsFound == null) {
			currentMappings = new Vector(instanceMappings);
		}
		else {
			currentMappings = pruneMappingsFound(instanceMappings, mappingsFound);
		}
		Vector finalMappings = new Vector();

		for (Iterator i=currentMappings.iterator(); i.hasNext();) {
			Tuple rule = (Tuple)i.next();
			double w = predict((OWLNamedObject)rule.get(1), (OWLNamedObject)rule.get(2));
			rule.set(3, new Double(w));
		}
		currentMappings = normalize(dropZero(currentMappings));

		Vector tempMappings = new Vector(currentMappings);
		for (Iterator i=currentMappings.iterator(); i.hasNext(); ) {
			Tuple rule = (Tuple)i.next();
			double value = ((Double)rule.get(3)).doubleValue();
			for (Iterator j=tempMappings.iterator(); j.hasNext(); ) {
				Tuple r = (Tuple)j.next();
				if (rule.get(1)==r.get(1)) {
					double v = ((Double)r.get(3)).doubleValue();
					if (value < v)
						rule = r;
				}
			}
			rule.set(3, new Double(1.0));
			finalMappings.add(rule);
		}

		for (Iterator i=finalMappings.iterator(); i.hasNext(); ) {
			Tuple rule = (Tuple)i.next();
			addAlignCell((OWLEntity)rule.get(1), (OWLEntity)rule.get(2), "=", ((Double)rule.get(3)).doubleValue());
		}
	}

	protected Vector dropZero(Vector mappings) {

		int i = 0;
		while (!mappings.isEmpty() && i<mappings.size()) {
			Tuple rule = (Tuple)mappings.get(i);
			if (((Double)rule.get(3)).doubleValue() == 0.0)
				mappings.removeElement(rule);
			else
				i = i+1;
		}
		return mappings;
	}

	protected Vector normalize(Vector mappings) {

		double min = 1.0;
		double max = 0.0;
		for (Iterator i=mappings.iterator(); i.hasNext();) {
			Tuple rule = (Tuple)i.next();
			min = Math.min(min, ((Double)rule.get(3)).doubleValue());
			max = Math.max(max, ((Double)rule.get(3)).doubleValue());
		}
		for (Iterator i=mappings.iterator(); i.hasNext();) {
			Tuple rule = (Tuple)i.next();
			double v = (((Double)rule.get(3)).doubleValue()-min) / (max-min);
			// To Keep the min to its value
			if (v != 0)
				rule.set(3, new Double(v));
		}
		return mappings;
	}

	protected Vector gatherInstances(OWLNamedObject elem, Hashtable allInstances) {

		Vector allValues = new Vector();
		for (Iterator iter=((Vector)allInstances.get(elem)).iterator(); iter.hasNext();) {
			String[] result = ((String)iter.next()).split("\\s");
			for (int i=0; i<result.length; i++)
				allValues.add(result[i]);
		}
		return allValues;
	}

	public void printAllInstances(OWLOntology onto, int d, PrintWriter out) {

		try {
			Hashtable allInstances = collectAllInstances(onto, d);
			if (allInstances.isEmpty())
				out.println("\n** There is no instances in the ontology: " + onto.getLogicalURI().toString() + " **\n");
			else {
				out.println("\n** Instances contained in the ontology: " + onto.getLogicalURI().toString() + " **");
				out.println("** Found " + allInstances.size() + " different categories **\n");
				for (Iterator i=allInstances.keySet().iterator(); i.hasNext();) {
					OWLNamedObject entity = (OWLNamedObject)i.next();
					Vector values = (Vector)allInstances.get(entity);
					out.println("Entity: " + entity.getURI() + " (" + values.size() + " instances)");
					for (Iterator j=values.iterator(); j.hasNext();) {
						String[] result = ((String)j.next()).split("\\s");
						for (int x=0; x<result.length; x++)
							out.print(result[x] + " ");
						if (j.hasNext())
							out.print("; ");
 					}
					out.println("\n");
				}
				out.print("\n");
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
	}

}