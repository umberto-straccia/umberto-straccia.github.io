/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.io.PrintWriter;
import java.io.IOException;
import java.net.URI;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Vector;

import org.semanticweb.owl.impl.model.*;
import org.semanticweb.owl.model.*;
import org.semanticweb.owl.util.*;
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentProcess;
import org.semanticweb.owl.align.Cell;
import org.semanticweb.owl.align.Parameters;
import fr.inrialpes.exmo.align.impl.BasicAlignment;

import it.cnr.isti.util.Tuple;

/** The Structural Classifier Class. From a Source Ontology S and
	a Target Ontology T, the Structural Classifier will try to align them

    The <CODE>source_ontology</CODE> and <CODE>target_ontology</CODE> are absolute URIs.

@author Rapha�l Troncy
 */

public class StructuralClassifier extends Classifier implements AlignmentProcess {

	public StructuralClassifier(OWLOntology onto1, OWLOntology onto2) {

		super(onto1, onto2);
	}

	private Set generateSSets(Set Cs, OWLOntology sOnto, Set Dt, OWLOntology tOnto, int card, String type) throws OWLException {

		// Generate allS, the set of all possible S defined as follow:
		//		S \in {C_1...C_m} * {D_1...D_n}
		//		|S| = min(m,n)
		//		(c,d) \in S and (c',d') \in S => c \ned c' and d \neq d'
		// Each Set contains a list of Tuple
		HashSet allS = new HashSet();
		OWLObject source = null;
		OWLObject target = null;
		boolean compatibility = true;
		for (Iterator i=Cs.iterator(); i.hasNext();) {
			source = (OWLObject)i.next();
			for (Iterator j=Dt.iterator(); j.hasNext();) {
				target = (OWLObject)j.next();
				if (type.equals("DATA_PROPERTY"))
					compatibility = checkDataRange((OWLDataProperty)source, (OWLDataProperty)target);
				else if (type.equals("DESCRIPTION"))
					compatibility = checkDescription((OWLDescription)source, (OWLDescription)target);
				if (compatibility) {
					if (card == 1) {
						HashSet aS = new HashSet();
						Tuple mappingRule = new Tuple(new Object[4]);
						mappingRule.set(0, type);
						mappingRule.set(1, source);
						mappingRule.set(2, target);
						aS.add(mappingRule);
						allS.add(aS);
					}
					else {
						HashSet tempCs = new HashSet(Cs);
						HashSet tempDt = new HashSet(Dt);
						tempCs.remove(source);
						tempDt.remove(target);
						Set tempAllS = generateSSets(tempCs, sOnto, tempDt, tOnto, card-1, type);
						for (Iterator k=tempAllS.iterator(); k.hasNext();) {
							HashSet aS = (HashSet)k.next();
							Tuple mappingRule = new Tuple(new Object[4]);
							mappingRule.set(0, type);
							mappingRule.set(1, source);
							mappingRule.set(2, target);
							aS.add(mappingRule);
							allS.add(aS);
						}
					}
				}
			}
		}
		return allS;
	}

	private boolean checkDataRange(OWLDataProperty sDP, OWLDataProperty tDP) {

		boolean compatibility = false;
		try {
			Set rSource = sDP.getRanges(onto1);
			Set rTarget = tDP.getRanges(onto2);
			// Use the XML Schema datatypes hierarchy
			// TO DO
			compatibility = rSource.equals(rTarget);
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return compatibility;
	}

	private boolean checkDescription(OWLDescription sDesc, OWLDescription tDesc) {

		// An OWLDescription can be: OWLClass, OWLRestriction, OWLBooleanDescription, OWLEnumeration
		return (((sDesc instanceof OWLClass) && (tDesc instanceof OWLClass)) ||
			((sDesc instanceof OWLDataCardinalityRestriction) && (tDesc instanceof OWLDataCardinalityRestriction)) ||
			((sDesc instanceof OWLDataQuantifiedRestriction) && (tDesc instanceof OWLDataQuantifiedRestriction)) ||
			((sDesc instanceof OWLObjectCardinalityRestriction) && (tDesc instanceof OWLObjectCardinalityRestriction)) ||
			((sDesc instanceof OWLObjectQuantifiedRestriction) && (tDesc instanceof OWLObjectQuantifiedRestriction)) ||
			((sDesc instanceof OWLBooleanDescription) && (tDesc instanceof OWLBooleanDescription)) ||
			((sDesc instanceof OWLEnumeration) && (tDesc instanceof OWLEnumeration)));
	}

	/*
	public int generateAllSigma(int i, Vector mappings, Hashtable sigma, PrintWriter out) {

		int nbValidSubset = 0;
		try {
			if (i == mappings.size()) {
				if (isValidSigma(sigma)) {
					nbValidSubset = nbValidSubset + 1;
					for (Enumeration e=sigma.keys(); e.hasMoreElements();) {
						String key = (String)e.nextElement();
						Tuple rule = (Tuple)sigma.get(key);
						rule.set(3, new Double(computeStructuralWeight(rule, sigma)));
					}
					double evaluation = evaluateSigma(sigma);
					allSigma.put(sigma, new Double(evaluation));
					//printMappingRules(sigma, evaluation, out);
				}
			}
			else {
				Tuple rule = (Tuple)mappings.get(i);
				if (isValidSigma(sigma) || ((String)rule.get(0)).equals("CLASS")) {
					Hashtable temp = new Hashtable(sigma);
					nbValidSubset = nbValidSubset + generateAllSigma(i+1, mappings, sigma, out);
					temp.put(rule.get(1).toString() + rule.get(2).toString(), rule);
					nbValidSubset = nbValidSubset + generateAllSigma(i+1, mappings, temp, out);
				}
			}
		}
		catch (NullPointerException npe) {
			System.err.println("Null pointer exception ... " + npe.getMessage());
			npe.printStackTrace();
		}
		return nbValidSubset;
	}
	*/
	
	/*
	private boolean isValidSigma(Hashtable sigma) {

		// Given a set sigma, this function return true if it is valid, i.e. it respects some constraints:
		// Constraint 1: at least one mapping rule involving (defined) classes is in the set
		// NOTE: the vector contains first pairs involving CLASS, then OBJECT_PROPERTY, and then DATA_PROPERTY
		// Constraint 2: have one to atmost one mapping ?
		// NOT YET IMPLEMENTED
		// Constraint 3: for a given target class, sigma contains only the closure of all OWL objects necessary for its definition
		// NOT YET IMPLEMENTED
		for (Enumeration e=sigma.elements(); e.hasMoreElements();) {
			Tuple mapping = (Tuple)e.nextElement();
			if (((String)mapping.get(0)).equals("CLASS"))
				return true;
		}		
		return false;
	}
	*/

	public Hashtable generateAllSigma(Vector mappingsFound, PrintWriter out) {

		Hashtable allSigma = new Hashtable();
		Set allS = new HashSet();

		long tb = System.currentTimeMillis();
		System.out.print("Generating all sigma sets using the matching entries already found ("+ mappingsFound.size() + ") ...");
		try {
			Set SC = onto1.getClasses();
			Set TC = onto2.getClasses();
			Set SOP = onto1.getObjectProperties();
			Set TOP = onto2.getObjectProperties();
			Set SDP = onto1.getDataProperties();
			Set TDP = onto2.getDataProperties();
			// Preparing the S sets for Classes, ObjectProperties and DatatypeProperties to generate
			if (!mappingsFound.isEmpty()) {
				for (Enumeration e=mappingsFound.elements(); e.hasMoreElements();) {
					Tuple rule = (Tuple)e.nextElement();
					if (((String)rule.get(0)).equals("CLASS")) {
						SC.remove(rule.get(1));
						TC.remove(rule.get(2));
					}
					else if (((String)rule.get(0)).equals("OBJECT_PROPERTY")) {
						SOP.remove(rule.get(1));
						TOP.remove(rule.get(2));
					}
					else if (((String)rule.get(0)).equals("DATA_PROPERTY")) {
						SDP.remove(rule.get(1));
						TDP.remove(rule.get(2));
					}
					else
						System.err.println("ERROR: Should not encounter " + (String)rule.get(0));
				}
			}
			System.out.println("\n   Considering in Source: " + SC.size() + " C, " + SOP.size() + " OP, " + SDP.size() + " DP");
			System.out.println("   Considering in Target: " + TC.size() + " C, " + TOP.size() + " OP, " + TDP.size() + " DP");
			// Generate the possible S sets for Classes, ObjectProperties and DatatypeProperties
			Set allSClass = generateSSets(SC, onto1, TC, onto2, Math.min(SC.size(), TC.size()), "CLASS");
			long ti = System.currentTimeMillis() - tb;
			out.println("\tSize of allSClass = " + allSClass.size() + " generated in " + ti + " milliseconds!");
			Set allSOP = generateSSets(SOP, onto1, TOP, onto2, Math.min(SOP.size(), TOP.size()), "OBJECT_PROPERTY");
			ti = System.currentTimeMillis() - ti;
			out.println("\tSize of allSOP = " + allSOP.size() + " generated in " + ti + " milliseconds!");
			Set allSDP = generateSSets(SDP, onto1, TDP, onto2, Math.min(SDP.size(), TDP.size()), "DATA_PROPERTY");
			ti = System.currentTimeMillis() - ti;
			out.println("\tSize of allSDP = " + allSDP.size() + " generated in " + ti + " milliseconds!");

			// Generate the cartesian product
			allS = cartesianProduct(allSClass, allSOP, allSDP);

			// Adding the mappings already found
			for (Iterator i=allS.iterator(); i.hasNext();) {
				Set aS = (Set)i.next();
				Hashtable sigma = new Hashtable();
				for (Iterator j=aS.iterator(); j.hasNext();) {
					Tuple mappingRule = (Tuple)j.next();
					sigma.put(mappingRule.get(1).toString() + mappingRule.get(2).toString(), mappingRule);
				}
				if (!mappingsFound.isEmpty()) {
					for (Enumeration e=mappingsFound.elements(); e.hasMoreElements();) {
						Tuple mappingRule = (Tuple)e.nextElement();
						sigma.put(mappingRule.get(1).toString() + mappingRule.get(2).toString(), mappingRule);
					}
				}
				// Initialization: the overall evaluation of Sigma is -1.0 
				allSigma.put(sigma, new Double(-1.0));
			}
			long te = System.currentTimeMillis() - tb;
			out.println("\tGeneration of all sigma sets = " + allSigma.size() + " done in " + te + " milliseconds!");
			System.out.println(" done\n");
		}
		catch (NullPointerException npe) {
			System.err.println("Null pointer exception ... " + npe.getMessage());
			npe.printStackTrace();
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return allSigma;
	}

	private HashSet cartesianProduct(Set allClass, Set allOP, Set allDP) {

		HashSet allS = new HashSet();
		// Generate the cartesian product of these 3 sets
		for (Iterator i=allClass.iterator(); i.hasNext();) {
			Set aClass = (Set)i.next();
			if (!allOP.isEmpty()) {
				for (Iterator j=allOP.iterator(); j.hasNext();) {
					Set aOP = (Set)j.next();
					if (!allDP.isEmpty()) {
						for (Iterator k=allDP.iterator(); k.hasNext();) {
							Set aDP = (Set)k.next();
							HashSet fusionSet = new HashSet();
							fusionSet.addAll(aClass);
							fusionSet.addAll(aOP);
							fusionSet.addAll(aDP);
							allS.add(fusionSet);
						}
					}
					else {
						HashSet fusionSet = new HashSet();
						fusionSet.addAll(aClass);
						fusionSet.addAll(aOP);
						allS.add(fusionSet);
					}
				}
			}
			else {
				if (!allDP.isEmpty()) {
					for (Iterator k=allDP.iterator(); k.hasNext();) {
						Set aDP = (Set)k.next();
						HashSet fusionSet = new HashSet();
						fusionSet.addAll(aClass);
						fusionSet.addAll(aDP);
						allS.add(fusionSet);
					}
				}
				else {
					HashSet fusionSet = new HashSet();
					fusionSet.addAll(aClass);
					allS.add(fusionSet);
				}
			}
		}
		return allS;
	}

	public Hashtable predictAll(Hashtable allEmptySigma) {

		// Compute the weight of each mapping rules in each sigma set, and evaluate the whole sigma
		Hashtable allSigma = new Hashtable();
		System.out.print("Beginning the computation of each sigma sets (" + allEmptySigma.size() + ")...");
		for (Enumeration enum=allEmptySigma.keys(); enum.hasMoreElements();) {
			Hashtable emptySigma = (Hashtable)enum.nextElement();
			Hashtable sigma = predict(emptySigma);
			double evaluation = evaluateSigma(sigma);
			allSigma.put(sigma, new Double(evaluation));
		}
		System.out.println(" done\n");
		return allSigma;
	}

	private Hashtable predict(Hashtable emptySigma) {

		Hashtable sigma = new Hashtable();
		for (Enumeration e=emptySigma.keys(); e.hasMoreElements();) {
			String key = (String)e.nextElement();
			Tuple emptyRule = (Tuple)emptySigma.get(key);
			Tuple mappingRule = new Tuple(new Object[4]);
			mappingRule.set(0, emptyRule.get(0));
			mappingRule.set(1, emptyRule.get(1));
			mappingRule.set(2, emptyRule.get(2));
			mappingRule.set(3, new Double(computeStructuralWeight(emptyRule, emptySigma)));
			sigma.put(key, mappingRule);
		}
		return sigma;
	}

	private Hashtable predict(Hashtable emptySigma, Hashtable bestSigma) {

		Hashtable sigma = new Hashtable();
		Hashtable fusionSigma = new Hashtable();
		for (Enumeration e=bestSigma.keys(); e.hasMoreElements();) {
			String key = (String)e.nextElement();
			Tuple rule = (Tuple)bestSigma.get(key);
			fusionSigma.put(key, rule);
		}
		for (Enumeration e=emptySigma.keys(); e.hasMoreElements();) {
			String key = (String)e.nextElement();
			Tuple emptyRule = (Tuple)emptySigma.get(key);
			fusionSigma.put(key, emptyRule);
		}
		for (Enumeration e=emptySigma.keys(); e.hasMoreElements();) {
			String key = (String)e.nextElement();
			Tuple emptyRule = (Tuple)emptySigma.get(key);
			Tuple mappingRule = new Tuple(new Object[4]);
			mappingRule.set(0, emptyRule.get(0));
			mappingRule.set(1, emptyRule.get(1));
			mappingRule.set(2, emptyRule.get(2));
			mappingRule.set(3, new Double(computeStructuralWeight(emptyRule, fusionSigma)));
			sigma.put(key, mappingRule);
		}
		return sigma;
	}

	public void align(Alignment alignment, Parameters params) throws AlignmentException, OWLException {

		BasicAlignment align = (BasicAlignment)params.getParameter("mappingsFound");
		Vector mappingsFound = buildMappingsFound(align);
		Hashtable result = predictAll(mappingsFound);
		for (Iterator i=result.keySet().iterator(); i.hasNext();) {
			String key = (String)i.next();
			Tuple rule = (Tuple)result.get(key);
			addAlignCell((OWLEntity)rule.get(1), (OWLEntity)rule.get(2), "=", ((Double)rule.get(3)).doubleValue());
		}
	}

	public Hashtable predictAll(Vector mappingsFound) {

		Hashtable bestSigma = new Hashtable();		// the mappings found by the other classifier
		Hashtable newSigma = new Hashtable();		// the mappings found by the structural classifier
		Hashtable finalSigma = new Hashtable();
		Hashtable allSmallSigma = new Hashtable();
		double evaluation;
		HashSet SC = new HashSet();
		HashSet SOP = new HashSet();
		HashSet SDP = new HashSet();
		HashSet TC = new HashSet();
		HashSet TOP = new HashSet();
		HashSet TDP = new HashSet();
		try {
			if (!mappingsFound.isEmpty()) {
				for (Enumeration e=mappingsFound.elements(); e.hasMoreElements();) {
					Tuple mappingRule = (Tuple)e.nextElement();
					bestSigma.put(mappingRule.get(1).toString() + mappingRule.get(2).toString(), mappingRule);
				}
			}
			//System.out.println("Best sigma contains already " + bestSigma.size() + " alignments and has evaluation " + evaluateSigma(bestSigma) + "\n");

			// Generate the list of class from the source that remain to be aligned
			Set currentSC = onto1.getClasses();
			for (Iterator i=onto1.getClasses().iterator(); i.hasNext();) {
				OWLClass sClass = (OWLClass)i.next();
				String ns = sClass.getURI().getScheme() + ":" + sClass.getURI().getSchemeSpecificPart();
				if (!onto1.getLogicalURI().toString().equals(ns))
					currentSC.remove(sClass);
			}
			Set currentTC = onto2.getClasses();
			for (Iterator i=onto2.getClasses().iterator(); i.hasNext();) {
				OWLClass tClass = (OWLClass)i.next();
				String ns = tClass.getURI().getScheme() + ":" + tClass.getURI().getSchemeSpecificPart();
				if (!onto2.getLogicalURI().toString().equals(ns))
					currentTC.remove(tClass);
			}
			for (Enumeration e=mappingsFound.elements(); e.hasMoreElements(); ) {
				Tuple rule = (Tuple)e.nextElement();
				if (((String)rule.get(0)).equals("CLASS")) {
					currentSC.remove(rule.get(1));
					currentTC.remove(rule.get(2));
				}
			}
			LinkedList restSC = new LinkedList(currentSC);
			System.out.println("Still missing to align from the source ontology, " + restSC.size() + " classes!\n");

			// Find the best alignment for all these classes
			while (restSC.size() != 0) {
				System.out.println("Left to align " + restSC.size() + " classes ...");
				// Get all the entities directly (or by closure ?) involved in the definition of the source class
				OWLClass sClass = (OWLClass)restSC.getFirst();
				System.out.println("   Aligning " + sClass.getURI().getFragment() + " ...");
				Set descS = sClass.getSuperClasses(onto1);
				for (Iterator i=descS.iterator(); i.hasNext(); ) {
					getDefinition((OWLDescription)i.next(), SC, SOP, SDP);
					//fillClosureDef((OWLDescription)i.next(), SC, SOP, SDP);
				}
				// Remove the ones for which we have already the alignment given by the other classifier
				HashSet mappingsList = cleanSets(bestSigma, SC, SOP, SDP, 1);
				int nbElemS = SC.size() + SOP.size() + SDP.size() + 1;
				System.out.println("   We should find aligments for " + nbElemS + " entities!");

				for (Iterator i=currentTC.iterator(); i.hasNext(); ) {
					OWLClass tClass = (OWLClass)i.next();
					System.out.print("\ttrying with: " + tClass.getURI().getFragment());
					Set descT = tClass.getSuperClasses(onto2);
					for (Iterator j=descT.iterator(); j.hasNext(); ) {
						getDefinition((OWLDescription)j.next(), TC, TOP, TDP);
						//fillClosureDef((OWLDescription)j.next(), TC, TOP, TDP);
					}
					// Remove the ones for which we have already the alignment
					cleanSets(bestSigma, TC, TOP, TDP, 2);
					int nbElemT = TC.size() + TOP.size() + TDP.size() + 1;

					// Generate the possible S sets for Classes, ObjectProperties and DatatypeProperties
					Set allSClass = generateSSets(SC, onto1, TC, onto2, Math.min(SC.size(), TC.size()), "CLASS");
					Set allSOP = generateSSets(SOP, onto1, TOP, onto2, Math.min(SOP.size(), TOP.size()), "OBJECT_PROPERTY");
					Set allSDP = generateSSets(SDP, onto1, TDP, onto2, Math.min(SDP.size(), TDP.size()), "DATA_PROPERTY");
					// Generate the cartesian product
					HashSet allS = cartesianProduct(allSClass, allSOP, allSDP);

					// Generate the possible sigma sets
					Hashtable allEmptySigma = new Hashtable();
					if (allS.isEmpty()) {
						Tuple rule = new Tuple(new Object[4]);
						rule.set(0, "CLASS");
						rule.set(1, sClass);
						rule.set(2, tClass);
						Hashtable sigma = new Hashtable();
						sigma.put(sClass.toString() + tClass.toString(), rule);
						allEmptySigma.put(sigma, new Double(-1.0));
					}
					else {
						for (Iterator j=allS.iterator(); j.hasNext();) {
							Set aS = (Set)j.next();
							Hashtable sigma = new Hashtable();
							for (Iterator k=aS.iterator(); k.hasNext();) {
								Tuple mappingRule = (Tuple)k.next();
								sigma.put(mappingRule.get(1).toString() + mappingRule.get(2).toString(), mappingRule);
							}
							Tuple rule = new Tuple(new Object[4]);
							rule.set(0, "CLASS");
							rule.set(1, sClass);
							rule.set(2, tClass);
							sigma.put(sClass.toString() + tClass.toString(), rule);
							allEmptySigma.put(sigma, new Double(-1.0));
						}
					}

					// Compute the weight of each mapping rules in each sigma set, and evaluate the whole sigma
					Hashtable allSigma = new Hashtable();
					for (Enumeration enum=allEmptySigma.keys(); enum.hasMoreElements();) {
						Hashtable emptySigma = (Hashtable)enum.nextElement();
						Hashtable sigma = predict(emptySigma, bestSigma);
						evaluation = evaluateSigma(sigma, (double)Math.max(nbElemS, nbElemT));
						allSigma.put(sigma, new Double(evaluation));
					}

					// Get the best Sigma Sets
					Vector bestSigmaList = new Vector();
					evaluation = getBestSigma(allSigma, bestSigmaList);
					System.out.println("... : best overall evaluation = " + evaluation + " (found " + bestSigmaList.size() + " sets)");
					allSmallSigma.put(fusionSigma(bestSigmaList), new Double(evaluation));

					// Clear T sets 
					TC.clear();
					TOP.clear();
					TDP.clear();
				}

				// Get the best from allSmallSigma
				Vector bestSigmaList = new Vector();
				evaluation = getBestSigma(allSmallSigma, bestSigmaList);
				System.out.println("\nThere are " + bestSigmaList.size() + " best small Sigma with evaluation = " + evaluation);
				Vector newSigmaList = new Vector();
				for (Iterator j=bestSigmaList.iterator(); j.hasNext(); ) {
					Hashtable sigma = (Hashtable)j.next();
					//if (sigma.size() <= nbElemS)
						newSigmaList.add(sigma);
					//else
						//System.err.println("ERROR: the size of Sigma (" + sigma.size() + ") can't be greater than " + nbElemS + " !");
				}
				Hashtable fusion = fusionSigma(newSigmaList);
				if ((fusion.size() <= nbElemS) && (evaluation == 1.0)) {
					bestSigma.putAll(fusion);
					System.out.println("\t\t Added in BestSigma !");
					cleanSets(fusion, currentTC, null, null, 2);
					restSC.removeAll(SC);
				}
				else {
					newSigma.putAll(fusion);
					System.out.println("\t\t Added in NewSigma !");
				}
				printSigmaSet(fusion, evaluation);

				// Remove from restSC the class now aligned (SC) and clean all
				restSC.remove(sClass);
				bestSigmaList.clear();
				allSmallSigma.clear();
				SC.clear();
				SOP.clear();
				SDP.clear();
			}
			System.out.println("Before postTreatment: bestSigma contains " + bestSigma.size() + " elements, and newSigma " + newSigma.size() + " elements!");
			finalSigma = postTreatment(bestSigma, newSigma);
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return finalSigma;
	}

	private HashSet cleanSets(Hashtable sigma, Set C, Set OP, Set DP, int i) {

		HashSet mappingsList = new HashSet();
		for (Enumeration e=sigma.elements(); e.hasMoreElements();) {
			Tuple rule = (Tuple)e.nextElement();
			if (((OWLEntity)rule.get(i)) instanceof OWLClass) {
				if ((C!=null) && (C.remove(rule.get(i))))
					mappingsList.add(rule);
			}
			else if (((OWLEntity)rule.get(i)) instanceof OWLObjectProperty) {
				if ((OP!=null) && (OP.remove(rule.get(i))))
					mappingsList.add(rule);
			}
			else if (((OWLEntity)rule.get(i)) instanceof OWLDataProperty) {
				if ((DP!=null) && (DP.remove(rule.get(i))))
					mappingsList.add(rule);
			}
		}
		return mappingsList;
	}

	private void fillClosureDef(OWLDescription desc, Set C, Set OP, Set DP) {

		try {
			// An OWLDescription can be: OWLClass, OWLRestriction, OWLBooleanDescription, OWLEnumeration
			if (desc instanceof OWLClass) {
				C.add((OWLClass)desc);
				for (Iterator i=((OWLClass)desc).getSuperClasses(onto1).iterator(); i.hasNext(); ) {
					fillClosureDef((OWLDescription)i.next(), C, OP, DP);
				}
			}
			else if (desc instanceof OWLBooleanDescription) {
				if (desc instanceof OWLNot)
					fillClosureDef(((OWLNot)desc).getOperand(), C, OP, DP);
				else if (desc instanceof OWLNaryBooleanDescription) {
					for (Iterator i=((OWLNaryBooleanDescription)desc).getOperands().iterator(); i.hasNext();) {
						fillClosureDef((OWLDescription)i.next(), C, OP, DP);
					}
				}
				else
					System.err.println("ERROR: a boolean description is either a NOT, or a n-ary description!");
			}
			else if (desc instanceof OWLDataRestriction)
				DP.add(((OWLDataRestriction)desc).getDataProperty());
			else if (desc instanceof OWLObjectRestriction) {
				OP.add(((OWLObjectRestriction)desc).getObjectProperty());
				if (desc instanceof OWLObjectQuantifiedRestriction)
					fillClosureDef(((OWLObjectQuantifiedRestriction)desc).getDescription(), C, OP, DP);
			}
			else
				System.err.println("ERROR: the description " + desc.toString() + " is not yet considered!");
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
	}

	private void getDefinition(OWLDescription desc, Set C, Set OP, Set DP) {

		try {
			// An OWLDescription can be: OWLClass, OWLRestriction, OWLBooleanDescription, OWLEnumeration
			if (desc instanceof OWLClass)
				C.add((OWLClass)desc);
			else if (desc instanceof OWLBooleanDescription) {
				if (desc instanceof OWLNot)
					getDefinition(((OWLNot)desc).getOperand(), C, OP, DP);
				else if (desc instanceof OWLNaryBooleanDescription) {
					for (Iterator i=((OWLNaryBooleanDescription)desc).getOperands().iterator(); i.hasNext();) {
						getDefinition((OWLDescription)i.next(), C, OP, DP);
					}
				}
				else
					System.err.println("ERROR: a boolean description is either a NOT, or a n-ary description!");
			}
			else if (desc instanceof OWLDataRestriction)
				DP.add(((OWLDataRestriction)desc).getDataProperty());
			else if (desc instanceof OWLObjectRestriction) {
				OP.add(((OWLObjectRestriction)desc).getObjectProperty());
			}
			else
				System.err.println("ERROR: the description " + desc.toString() + " is not yet considered!");
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
	}

	private double getBestSigma(Hashtable allSigma, Vector bestSigmaList) {

		double bestEval = -1.0;
		if (allSigma != null) {
			for (Enumeration e=allSigma.elements(); e.hasMoreElements(); ) {
				double v = ((Double)e.nextElement()).doubleValue();
				if (v > bestEval)
					bestEval = v;
			}
			for (Iterator i=allSigma.keySet().iterator(); i.hasNext(); ) {
				Hashtable sigma = (Hashtable)i.next();
				if (((Double)allSigma.get(sigma)).doubleValue() == bestEval)
					bestSigmaList.add(sigma);
			}
		}
		return bestEval;
	}

	private Hashtable fusionSigma(Vector bestSigmaList) {

		Hashtable sigma = new Hashtable();
		for (Iterator i=bestSigmaList.iterator(); i.hasNext(); ) {
			Hashtable s = (Hashtable)i.next();
			sigma.putAll(s);
		}
		return sigma;
	}

	private void printSigmaSet(Hashtable sigma, double evaluation) {

		System.out.println("Sigma = {");
		for (Enumeration e=sigma.keys(); e.hasMoreElements();) {
			String key = (String)e.nextElement();
			Tuple mapping = (Tuple)sigma.get(key);
			System.out.println("\t" + mapping.toString());
		}
		System.out.println("}");
	}

	private Hashtable postTreatment(Hashtable bestSigma, Hashtable newSigma) {

		Hashtable finalSigma = new Hashtable();
		Hashtable fusionSigma = new Hashtable(bestSigma);
		for (Enumeration e=newSigma.keys(); e.hasMoreElements();) {
			String key = (String)e.nextElement();
			Tuple rule = (Tuple)newSigma.get(key);
			Tuple emptyRule = new Tuple(new Object[4]);
			emptyRule.set(0, rule.get(0));
			emptyRule.set(1, rule.get(1));
			emptyRule.set(2, rule.get(2));
			emptyRule.set(3, null);
			fusionSigma.put(key, emptyRule);
		}
		Hashtable predictedSigma = predict(fusionSigma);

		Hashtable fullSigma = new Hashtable(predictedSigma);
		for (Enumeration i=predictedSigma.keys(); i.hasMoreElements(); ) {
			String key = (String)i.nextElement();
			Tuple rule = (Tuple)predictedSigma.get(key);
			double value = ((Double)rule.get(3)).doubleValue();
			for (Enumeration j=fullSigma.keys(); j.hasMoreElements(); ) {
				String k = (String)j.nextElement();
				Tuple r = (Tuple)fullSigma.get(k);
				if (rule.get(1)==r.get(1)) {
					double v = ((Double)r.get(3)).doubleValue();
					if (value < v)
						rule = r;
				}
			}
			finalSigma.put(key, rule);
		}
		return finalSigma;
	}

	private double computeStructuralWeight(Tuple rule, Hashtable sigma) {

		double weight = 0.0;
		if (((OWLEntity)rule.get(1)) instanceof OWLProperty)
			weight = computePropertyWeight(rule, sigma);
		else if (((OWLEntity)rule.get(1)) instanceof OWLClass)
			weight = computeConceptNameWeight(rule, sigma);
		else {
			System.err.println("ERROR: should be either CLASS or PROPERTY!");
			System.exit(0);
		}
		return weight;
	}

	private double computePropertyWeight(Tuple rule, Hashtable sigma) {

		if (sigma.containsKey(rule.get(1).toString() + rule.get(2).toString()))
			return 1.0;
		else
			return 0.0;
	}

	private double computeConceptNameWeight(Tuple rule, Hashtable sigma) {

		double weight = 0.0;
		try {
			String key = rule.get(1).toString() + rule.get(2).toString();
			if (!(sigma.containsKey(key))) {
				weight = 0.0;
			}
			else {
				if (((Tuple)sigma.get(key)).get(3) != null) {
					weight = ((Double)((Tuple)sigma.get(key)).get(3)).doubleValue();
				}
				else {
					// We get all the superClasses (i.e. the definition) of the two concepts involved in the rule
					// We should get all the equivalentClasses of Cs and Dt if the ontology was normalized
					Set Cs = ((OWLClass)rule.get(1)).getSuperClasses(onto1);
					Set Dt = ((OWLClass)rule.get(2)).getSuperClasses(onto2);
					int norm = Cs.size() * Dt.size();
					if (norm==0)
						weight = 1.0;
					else {
						// Generate allS, the set of all possible S
						int card = Math.min(Cs.size(), Dt.size());
						Set allS = generateSSets(Cs, onto1, Dt, onto2, card, "DESCRIPTION");
						// Compute the weight
						for (Iterator i=allS.iterator(); i.hasNext();) {
							Set aS = (Set)i.next();
							double wtemp = 0.0;
							for (Iterator j=aS.iterator(); j.hasNext();) {
								Tuple r = (Tuple)j.next();
								OWLDescription sDesc = (OWLDescription)r.get(1);
								OWLDescription tDesc = (OWLDescription)r.get(2);
								wtemp = wtemp + computeOWLDescriptionWeight(sDesc, tDesc, sigma);
							}
							weight = Math.max(weight, wtemp);
						}
						weight = (1.0 / ((double)(card + 1))) * (1.0 + weight);										
					}
				}
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return weight;
	}

	private double computeOWLDescriptionWeight(OWLDescription sDesc, OWLDescription tDesc, Hashtable sigma) {

		double weight = 0.0;
		// sDesc and tDesc are OWLDescription
		// An OWLDescription can be: OWLClass, OWLRestriction, OWLBooleanDescription, OWLEnumeration
		if ((sDesc instanceof OWLClass) && (tDesc instanceof OWLClass)) {
			Tuple rule = new Tuple(new Object[4]);
			rule.set(0, "CLASS");
			rule.set(1, (OWLClass)sDesc);
			rule.set(2, (OWLClass)tDesc);
			weight = computeConceptNameWeight(rule, sigma);
		}
		else if ((sDesc instanceof OWLRestriction) && (tDesc instanceof OWLRestriction))
			weight = computeRestrictionWeight((OWLRestriction)sDesc, (OWLRestriction)tDesc, sigma);
		else if ((sDesc instanceof OWLBooleanDescription) && (tDesc instanceof OWLBooleanDescription))
			weight = computeBooleanDescriptionWeight((OWLBooleanDescription)sDesc, (OWLBooleanDescription)tDesc, sigma);
		else if ((sDesc instanceof OWLEnumeration) && (tDesc instanceof OWLEnumeration))
			// TO DO
			weight = 0.0;
		else
			// The two OWLDescription are not of the same kind
			weight = 0.0;
		return weight;
	}

	private double computeRestrictionWeight(OWLRestriction Rs, OWLRestriction Rt, Hashtable sigma) {

		// Rs and Rt are OWLRestriction
		// An OWLRestriction can be: OWLDataRestriction,  OWLObjectRestriction, OWLCardinalityRestriction
		// NOTE : it is VERY important to test at the beginning the OWLCardinalityRestriction since it can be also a Data or an Object Restriction
		double weight = 0.0;
		try {
			Tuple rule = new Tuple(new Object[4]);
			if ((Rs instanceof OWLCardinalityRestriction) && (Rt instanceof OWLCardinalityRestriction)) {
				// REMINDER: An OWLCardinalityRestriction represents an assertion about the number of role fillers a property can or must have.
				// In a change from DAML+OIL, OWL cardinality restrictions are unqualified, i.e. they do not state what type the filler should have.
				OWLCardinalityRestriction CRs = (OWLCardinalityRestriction)Rs;
				OWLCardinalityRestriction CRt = (OWLCardinalityRestriction)Rt;
				double wcar = 0.0;
				if (CRs.isAtLeast()) {
					if (CRt.isAtLeast())
						wcar = computeCardinalityWeight("ATLEAST", CRs.getAtLeast(), "ATLEAST", CRt.getAtLeast());
					else
						wcar = computeCardinalityWeight("ATLEAST", CRs.getAtLeast(), "ATMOST", CRt.getAtMost());
				}
				else {
					if (CRt.isAtLeast())
						wcar = computeCardinalityWeight("ATMOST", CRs.getAtMost(), "ATLEAST", CRt.getAtLeast());
					else
						wcar = computeCardinalityWeight("ATMOST", CRs.getAtMost(), "ATMOST", CRt.getAtMost());
				}
				if ((Rs instanceof OWLDataCardinalityRestriction) && (Rt instanceof OWLDataCardinalityRestriction)) {
					rule.set(0, "DATA_PROPERTY");
					rule.set(1, ((OWLDataCardinalityRestriction)Rs).getDataProperty());
					rule.set(2, ((OWLDataCardinalityRestriction)Rt).getDataProperty());
					weight = wcar * computePropertyWeight(rule, sigma);
				}
				else if ((Rs instanceof OWLObjectCardinalityRestriction) && (Rt instanceof OWLObjectCardinalityRestriction)) {
					rule.set(0, "OBJECT_PROPERTY");
					rule.set(1, ((OWLObjectCardinalityRestriction)Rs).getObjectProperty());
					rule.set(2, ((OWLObjectCardinalityRestriction)Rt).getObjectProperty());
					weight = wcar * computePropertyWeight(rule, sigma);
				}
			}
			else if ((Rs instanceof OWLDataRestriction) && (Rt instanceof OWLDataRestriction)) {
				// REMINDER: An OWLDataRestriction represents a Restriction that particularly applies to an OWLDataProperty.
				double wq = 0.0;
				if (Rs instanceof OWLDataAllRestriction) {
					if (Rt instanceof OWLDataAllRestriction)
						wq = computeQuantifierWeight("FORALL","FORALL");
					else if (Rt instanceof OWLDataSomeRestriction)
						wq = computeQuantifierWeight("FORALL","EXIST");
				}
				else if (Rs instanceof OWLDataSomeRestriction) {
					if (Rt instanceof OWLDataAllRestriction)
						wq = computeQuantifierWeight("EXIST","FORALL");
					else if (Rt instanceof OWLDataSomeRestriction)
						wq = computeQuantifierWeight("EXIST","EXIST");
				}
				rule.set(0, "DATA_PROPERTY");
				rule.set(1, ((OWLDataRestriction)Rs).getDataProperty());
				rule.set(2, ((OWLDataRestriction)Rt).getDataProperty());
				weight = wq * computePropertyWeight(rule, sigma);
			}
			else if ((Rs instanceof OWLObjectRestriction) && (Rt instanceof OWLObjectRestriction)) {
				// REMINDER: An OWLObjectRestriction represents a Restriction that particularly applies to an OWLObjectProperty.
				double wq = 0.0;
				if (Rs instanceof OWLObjectAllRestriction) {
					if (Rt instanceof OWLObjectAllRestriction)
						wq = computeQuantifierWeight("FORALL","FORALL");
					else if (Rt instanceof OWLObjectSomeRestriction)
						wq = computeQuantifierWeight("FORALL","EXIST");
				}
				else if (Rs instanceof OWLObjectSomeRestriction) {
					if (Rt instanceof OWLObjectAllRestriction)
						wq = computeQuantifierWeight("EXIST","FORALL");
					else if (Rt instanceof OWLObjectSomeRestriction)
						wq = computeQuantifierWeight("EXIST","EXIST");
				}
				rule.set(0, "OBJECT_PROPERTY");
				rule.set(1, ((OWLObjectRestriction)Rs).getObjectProperty());
				rule.set(2, ((OWLObjectRestriction)Rt).getObjectProperty());
				weight = wq * computePropertyWeight(rule, sigma) * computeOWLDescriptionWeight(
					((OWLObjectQuantifiedRestriction)Rs).getDescription(), 
					((OWLObjectQuantifiedRestriction)Rt).getDescription(), 
					sigma);
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return weight;
	}

	private double computeCardinalityWeight(String symbolSource, int vs, String symbolTarget, int vt) {

		if (symbolSource.equals("ATMOST")) {
			if (symbolTarget.equals("ATMOST"))
				return 1.0;
			else if (symbolTarget.equals("ATLEAST"))
				return 1.0/3.0;
			else
				return 0.0;
		}
		else if (symbolSource.equals("ATLEAST")) {
			if (symbolTarget.equals("ATMOST"))
				return 1.0/3.0;
			else if (symbolTarget.equals("ATLEAST"))
				return 1.0;
			else
				return 0.0;
		}
		else
			return 0.0;
	}

	private double computeQuantifierWeight(String symbolSource, String symbolTarget) {

		if (symbolSource.equals("EXIST")) {
			if (symbolTarget.equals("EXIST"))
				return 1.0;
			else if (symbolTarget.equals("FORALL"))
				return 1.0/4.0;
			else
				return 0.0;
		}
		else if (symbolSource.equals("FORALL")) {
			if (symbolTarget.equals("EXIST"))
				return 1.0/4.0;
			else if (symbolTarget.equals("FORALL"))
				return 1.0;
			else
				return 0.0;
		}
		else
			return 0.0;
	}

	private double computeBooleanDescriptionWeight(OWLBooleanDescription BDs, OWLBooleanDescription BDt, Hashtable sigma) {

		// BDs and BDt are OWLBooleanDescription
		// An OWLBooleanDescription can be: OWLNot, OWLAnd, OWLOr
		double weight = 0.0;
		double wop = 0.0;
		try {
			if ((BDs instanceof OWLNot) && (BDt instanceof OWLNot)) {
				// Unary Operator
				wop = computeOperatorWeight("NOT", "NOT");
				weight = wop * computeOWLDescriptionWeight(((OWLNot)BDs).getOperand(), ((OWLNot)BDt).getOperand(), sigma);
			}
			else {
				// NAry Operator
				if (BDs instanceof OWLAnd) {
					if (BDt instanceof OWLAnd)
						wop = computeOperatorWeight("AND", "AND");
					else if (BDt instanceof OWLOr)
						wop = computeOperatorWeight("AND", "OR");
				}
				else if (BDs instanceof OWLOr) {
					if (BDt instanceof OWLAnd)
						wop = computeOperatorWeight("OR", "AND");
					else if (BDt instanceof OWLOr)
						wop = computeOperatorWeight("OR", "OR");
				}
				Set Cs = ((OWLNaryBooleanDescription)BDs).getOperands();
				Set Dt = ((OWLNaryBooleanDescription)BDt).getOperands();

				// Generate allS, the set of all possible S
				int card = Math.min(Cs.size(), Dt.size());
				Set allS = generateSSets(Cs, onto1, Dt, onto2, card, "DESCRIPTION");
				// Compute the weight
				for (Iterator i=allS.iterator(); i.hasNext();) {
					Set aS = (Set)i.next();
					double wtemp = 0.0;
					for (Iterator j=aS.iterator(); j.hasNext();) {
						Tuple r = (Tuple)j.next();
						OWLDescription sDesc = (OWLDescription)r.get(1);
						OWLDescription tDesc = (OWLDescription)r.get(2);
						wtemp = wtemp + computeOWLDescriptionWeight(sDesc, tDesc, sigma);
					}
					weight = Math.max(weight, wtemp);
				}
				weight = wop * (weight / (double)card);
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return weight;
	}

	private double computeOperatorWeight(String symbolSource, String symbolTarget) {

		if (symbolSource.equals("AND")) {
			if (symbolTarget.equals("AND"))
				return 1.0;
			else if (symbolTarget.equals("OR"))
				return 1.0/4.0;
			else
				return 0.0;
		}
		else if (symbolSource.equals("OR")) {
			if (symbolTarget.equals("AND"))
				return 1.0/4.0;
			else if (symbolTarget.equals("OR"))
				return 1.0;
			else
				return 0.0;
		}
		else if (symbolSource.equals("NOT")) {
			if (symbolTarget.equals("NOT"))
				return 1.0;
			else
				return 0.0;
		}
		else
			return 0.0;
	}

	public double evaluateSigma(Hashtable sigma) {

		double evaluation = 0.0;
		// TO DO: compute the real evaluation, and not this simple average
		for (Enumeration e=sigma.elements(); e.hasMoreElements();) {
			Tuple rule = (Tuple)e.nextElement();
			evaluation = evaluation + ((Double)rule.get(3)).doubleValue();
		}
		evaluation = evaluation / (double)sigma.size();
		return evaluation;
	}

	public double evaluateSigma(Hashtable sigma, double nbElem) {

		double evaluation = 0.0;
		// TO DO: compute the real evaluation, and not this simple average
		for (Enumeration e=sigma.elements(); e.hasMoreElements();) {
			Tuple rule = (Tuple)e.nextElement();
			evaluation = evaluation + ((Double)rule.get(3)).doubleValue();
		}
		evaluation = evaluation / nbElem;
		return evaluation;
	}

}