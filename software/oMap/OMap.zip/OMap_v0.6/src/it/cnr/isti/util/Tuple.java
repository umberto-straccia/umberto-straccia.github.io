/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.util;

import org.semanticweb.owl.model.*;

/** The Tuple Class for expessing the mappings
 * Adapted from $Id: Tuple.java,v 1.3 2003/09/23 12:28:28 nottelma Exp $
    
@author Rapha�l Troncy
 */

public class Tuple {

	protected Object[] array;

	public Tuple(Object[] array) {
		this.array = array;
	}

	public int length() {
		return array.length;
	}

	public int size() {
		return length();
	}

	public Object get(int i) {
		return array[i];
	}

	public void set(int i, Object o) {
		array[i] = o;
	}

	public double getDouble(int i) {
		Double ret = (Double) get(i);
		return ret == null ? 0 : ret.doubleValue();
	}

	public int getInt(int i) {
		Integer ret = (Integer) get(i);
		return ret == null ? 0 : ret.intValue();
	}

	public String getString(int i) {
		Object ret = get(i);
		if (ret instanceof String)
			return (String) ret;
		return ret == null ? null : ret.toString();
	}

	public boolean equals(Object o) {
		if (!(o instanceof Tuple))
			return false;
		Tuple t = (Tuple) o;
		if (t.length() != length())
			return false;
		for (int i = 0; i < length(); i++) {
			Object o1 = get(i);
			Object o2 = get(i);
			if (o1 == null && o2 == null)
				continue;
			if (o1 == null || o2 == null || !get(i).equals(t.get(i)))
				return false;
		}
		return true;
	}

	public int hashCode() {
		return toHash().hashCode();
	}

//	public String toString() {
//		StringBuffer buf = new StringBuffer("Tuple[");
//		for (int i = 0; i < length(); i++) {
//			buf.append(get(i));
//			if (i < length() - 1)
//				buf.append(",");
//		}
//		buf.append("]");
//		return buf.toString();
//	}

	public String toHash() {

		// For generating the hashcode of a Mapping Rule
		StringBuffer buf = new StringBuffer();
		buf = buf.append("Tuple[");
		buf.append(get(0));
		buf.append(",");
		buf.append(get(1).toString());
		buf.append(",");
		buf.append(get(2).toString());
		buf.append(",");
		buf.append(get(3));
		buf.append("]");
		return buf.toString();
	}
	
	public String toString() {

		// Overwrite for pretty print of a Mapping Rule
		StringBuffer buf = new StringBuffer();
		try {
			buf = buf.append("Tuple[");
			buf.append(get(0));
			buf.append(",");
			if (((OWLNamedObject)get(1)).getURI().getFragment()==null)
				buf.append(((OWLNamedObject)get(1)).getURI());
			else
				buf.append(((OWLNamedObject)get(1)).getURI().getFragment());
			buf.append(",");
			if (((OWLNamedObject)get(2)).getURI().getFragment()==null)
				buf.append(((OWLNamedObject)get(2)).getURI());
			else
				buf.append(((OWLNamedObject)get(2)).getURI().getFragment());
			buf.append(",");
			buf.append(get(3));
			buf.append("]");
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return buf.toString();
	}

}
