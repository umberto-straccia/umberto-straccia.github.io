/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import org.semanticweb.owl.model.*;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;

/** The kNN Classifier Class.

@author Rapha�l Troncy
 */

public class kNNClassifier extends InstanceClassifier {

	private int k = 5;
	private static String INDEX = "index";

	public kNNClassifier(OWLOntology onto1, OWLOntology onto2, int instanceDepth) {

		super(onto1, onto2, instanceDepth);
		buildIndex(sourceInstances);
	}

	/**
	 * Computes a prediction Pr(Si|Tj,C) by applying this classifier C.
	 * 
	 * @param Si source entity Si
	 * @param Tj target entity Tj
	 * @return prediction value Pr(Si|Tj,C)
	 */
	protected double predict(OWLNamedObject Si, OWLNamedObject Tj) {

		double weight = 0.0;
		try {
			Vector values = (Vector)targetInstances.get(Tj);
			for (Iterator i=values.iterator(); i.hasNext(); ) {
				String v = (String)i.next();
				weight = weight + ((Double)computeRSV(v).get(Si.getURI().toString())).doubleValue();
			}
			weight = weight / values.size();
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		//System.out.println("w(Si,Tj) = " + weight + " with (Si=" + Si.toString() + "), (Tj=" + Tj.toString() + ")");
		return weight;
	}

	private Hashtable computeRSV(String v) {

		Hashtable RSV = new Hashtable();
		try {
			for (Iterator i=sourceInstances.keySet().iterator(); i.hasNext(); ) {
				OWLNamedObject category = (OWLNamedObject)i.next();
				RSV.put(category.getURI().toString(), new Double(0.0));
			}
			IndexSearcher searcher = new IndexSearcher(INDEX);
			Query q = QueryParser.parse(v, "value", new StandardAnalyzer());
			Hits h = searcher.search(q);
			//System.out.println("For the query " + q + " , found " + h.length() + " documents");
			// For the TOP k
			for (int i=0; i<Math.min(k, h.length()); i++) {
				String category = (String)h.doc(i).getField("category").stringValue();
				double score = ((Double)RSV.get(category)).doubleValue();
				score = score + h.score(i);
				RSV.put(category, new Double(score));
			}
		}
		catch (IOException ioe) {
			System.err.println("IO exception ... " + ioe.getMessage());
			ioe.printStackTrace();
		}
		catch (ParseException pe) {
			System.err.println("Parse Query exception ... " + pe.getMessage());
			pe.printStackTrace();
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return RSV;
	}

	private void buildIndex(Hashtable allInstances) {

		try {
			IndexWriter writer = new IndexWriter(INDEX, new StandardAnalyzer(), true);
			for (Iterator i=allInstances.keySet().iterator(); i.hasNext();) {
				OWLNamedObject category = (OWLNamedObject)i.next();
				Vector values = (Vector)allInstances.get(category);
				for (Iterator j=values.iterator(); j.hasNext();) {
					String u = (String)j.next();
					Document doc = new Document();
					doc.add(new Field("category", category.getURI().toString(), true, false, false));
					doc.add(new Field("value", u, true, true, true));
					writer.addDocument(doc);
				}
			}
			writer.optimize();
			writer.close();
		}
		catch (IOException ioe) {
			System.err.println("IO exception ... " + ioe.getMessage());
			ioe.printStackTrace();
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
	}

}