/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import org.semanticweb.owl.model.*;

/** The Naive Bayes Classifier Class.

@author Rapha�l Troncy
 */

public class NaiveBayesClassifier extends InstanceClassifier {

	public NaiveBayesClassifier(OWLOntology onto1, OWLOntology onto2, int instanceDepth) {

		super(onto1, onto2, instanceDepth);
	}

	/**
	 * Computes a prediction Pr(Si|Tj,C) by applying this classifier C.
	 * 
	 * @param Si source entity Si
	 * @param Tj target entity Tj
	 * @return prediction value Pr(Si|Tj,C)
	 */
	protected double predict(OWLNamedObject Si, OWLNamedObject Tj) {

		double weight = 0.0;

		// Gather all the values for Si in a single Vector
		Vector allSiValues = gatherInstances(Si, sourceInstances);

		// Si and Tj are the source and the target ontology elements
		// V_Si and V_Tj represent the categories corresponding to Si and Tj (i.e. the list of all their instances)
		// Compute the weight w(Si,Tj) with the following formula:
		// W(Si,Tj) = Pr(V_Si) \cdot \sum_{x \in V_Tj) \prod_{m \in x} Pr(m|V_Si)
		// where: Pr(m|V_Si) = number of times word m appears in V_Si / number of all words in V_Si
		// and: Pr(V_Si) = 1 / number of categories V_Si
		Vector VTj = (Vector)targetInstances.get(Tj);
		for (Iterator iter=VTj.iterator(); iter.hasNext();) {
			double prob = 1.0;
			String[] x = ((String)iter.next()).split("\\s");
			for (int i=0; i<x.length; i++) {
				prob = prob * (count(x[i],allSiValues) / allSiValues.size());
			}
			weight = weight + prob;
		}
		weight = weight / sourceInstances.size();
		return weight;
	}

	private double count(String word, Vector values) {

		int nb = 0;
		for (Iterator i=values.iterator(); i.hasNext();) {
			if (((String)i.next()).equals(word))
				nb++;
		}
		return (double)nb;
	}

}