/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.net.URI;
import java.util.Iterator;
import java.util.Vector;

import org.semanticweb.owl.model.*;
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentProcess;
import org.semanticweb.owl.align.Cell;
import org.semanticweb.owl.align.Parameters;
import fr.inrialpes.exmo.align.impl.BasicAlignment;

import it.cnr.isti.util.Tuple;

/** The Binary Prediction Classifier Class.
	
@author Rapha�l Troncy
 */

public abstract class BinaryPredictionClassifier extends Classifier implements AlignmentProcess {

	public BinaryPredictionClassifier(OWLOntology onto1, OWLOntology onto2) {

		super(onto1, onto2);
	}

	protected abstract double predict(URI entityA, URI entityB);

	public void align(Alignment alignment, Parameters params) throws AlignmentException, OWLException {

		Vector allMappings = (Vector)params.getParameter("allMappings");
		if (!allMappings.isEmpty()) {
			try {
				for (Iterator i=allMappings.iterator(); i.hasNext();) {
					Tuple rule = (Tuple)i.next();
					double w = predict(((OWLNamedObject)rule.get(1)).getURI(), ((OWLNamedObject)rule.get(2)).getURI());
					if (w != 0.0)
						addAlignCell((OWLEntity)rule.get(1), (OWLEntity)rule.get(2), "=", w);
				}
			}
			catch (OWLException oe) {
				System.err.println("OWL exception ... " + oe.getMessage());
				oe.printStackTrace();
			}
		}
	}

}