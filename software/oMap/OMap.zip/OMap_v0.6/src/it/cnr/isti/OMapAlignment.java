/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Properties;

import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;

import org.semanticweb.owl.model.*;
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentProcess;
import org.semanticweb.owl.align.Cell;
import org.semanticweb.owl.align.Parameters;
import fr.inrialpes.exmo.align.impl.BasicAlignment;
import fr.inrialpes.exmo.align.impl.BasicParameters;
import fr.inrialpes.exmo.align.impl.method.EditDistNameAlignment;
import fr.inrialpes.exmo.align.ling.JWNLAlignment;
import fr.inrialpes.exmo.align.parser.AlignmentParser;

import it.cnr.isti.classifier.SameNameClassifier;
import it.cnr.isti.classifier.SameStemClassifier;
import it.cnr.isti.classifier.NaiveBayesClassifier;
import it.cnr.isti.classifier.kNNClassifier;
import it.cnr.isti.classifier.StructuralClassifier;
import it.cnr.isti.util.Tuple;

/** The main OMapAlignment class. Compatible with the Alignment API

@author Rapha�l Troncy
 */

public class OMapAlignment extends BasicAlignment implements AlignmentProcess {

	private Vector classifierPriorityList;
	private int instanceDepth;
	private boolean debug;
	private boolean chaining;

	public OMapAlignment(OWLOntology onto1, OWLOntology onto2) {

		super();
		init(onto1, onto2);
		setType("11");
	}

	private void loadParam(InputStream configFile) {

		classifierPriorityList = new Vector();
		try {
			Properties param = new Properties();
			param.load(configFile);
			configFile.close();
			// Set the various properties from the configuration file
			String[] result = param.getProperty("ClassifierPriorityList").split("[,\\s]");
			for (int i=0; i<result.length; i++) {
				classifierPriorityList.add(result[i]);
			}
			instanceDepth = Integer.parseInt(param.getProperty("InstanceDepth", "3"));
			debug = param.getProperty("DebugMode", "FALSE").equals("TRUE") ? true : false;
			chaining = param.getProperty("ChainingMode", "TRUE").equals("TRUE") ? true : false;
		}
		catch (IOException ioe) {
			System.err.println("IO exception ... " + ioe.getMessage());
			ioe.printStackTrace();
		}
	}

	private Vector generateAllMappings() {

		Vector mappings = new Vector();
		String ns1, ns2;
		try {
			//System.out.println("Onto1: total = " + onto1.getClasses().size() + " Classes; " + onto1.getObjectProperties().size() + " OP; " + onto1.getDataProperties().size() + " DP");
			//System.out.println("Onto2: total = " + onto2.getClasses().size() + " Classes; " + onto2.getObjectProperties().size() + " OP; " + onto2.getDataProperties().size() + " DP");
			for (Iterator i=onto1.getClasses().iterator(); i.hasNext();) {
				OWLClass sClass = (OWLClass)i.next();
				ns1 = sClass.getURI().getScheme() + ":" + sClass.getURI().getSchemeSpecificPart();
				if (onto1.getLogicalURI().toString().equals(ns1)) {
					for (Iterator j=onto2.getClasses().iterator(); j.hasNext();) {
						OWLClass tClass = (OWLClass)j.next();
						ns2 = tClass.getURI().getScheme() + ":" + tClass.getURI().getSchemeSpecificPart();
						if (onto2.getLogicalURI().toString().equals(ns2)) {
							Tuple mappingRule = new Tuple(new Object[4]);
							mappingRule.set(0, "CLASS");
							mappingRule.set(1, sClass);
							mappingRule.set(2, tClass);
							mappings.addElement(mappingRule);
						}
					}
				}
			}
			Set sProperties = onto1.getObjectProperties();
			sProperties.addAll(onto1.getDataProperties());
			Set tProperties = onto2.getObjectProperties();
			tProperties.addAll(onto2.getDataProperties());
			for (Iterator i=sProperties.iterator(); i.hasNext();) {
				OWLProperty sProp = (OWLProperty)i.next();
				ns1 = sProp.getURI().getScheme() + ":" + sProp.getURI().getSchemeSpecificPart();
				if (onto1.getLogicalURI().toString().equals(ns1)) {
					for (Iterator j=tProperties.iterator(); j.hasNext();) {
						OWLProperty tProp = (OWLProperty)j.next();
						ns2 = tProp.getURI().getScheme() + ":" + tProp.getURI().getSchemeSpecificPart();
						if (onto2.getLogicalURI().toString().equals(ns2)) {
							Tuple mappingRule = new Tuple(new Object[4]);
							mappingRule.set(0, "PROPERTY");
							mappingRule.set(1, sProp);
							mappingRule.set(2, tProp);
							mappings.addElement(mappingRule);
						}
					}
				}
			}
		}
		catch (OWLException oe) {
			System.err.println("OWL exception ... " + oe.getMessage());
			oe.printStackTrace();
		}
		return mappings;
	}

	private void fillResultTable(Hashtable resultTable, Alignment alignment, String clName) throws OWLException {

		for (Enumeration e=alignment.getElements(); e.hasMoreElements(); ) {
			Cell c = (Cell)e.nextElement();
			String key = ((OWLEntity)c.getObject1()).getURI().toString() + "-->" + ((OWLEntity)c.getObject2()).getURI().toString();
			//String key = ((OWLEntity)c.getObject1()).getURI().getFragment() + "-->" + ((OWLEntity)c.getObject2()).getURI().getFragment();
			Vector v = (Vector)resultTable.get(key);
			if (v == null) {
				v = new Vector();
				resultTable.put(key, v);
			}
			v.add(clName);
		}
	}

	private void printResultTable(Hashtable finalResultTable, PrintWriter out) throws OWLException {

		out.println("Final result given by oMAP:\n");
		out.println("Source ontology: " + onto1.getURI());
		out.println("Target ontology: " + onto2.getURI() + "\n");
		out.println("\nMappings\tCL_SN\tCL_SS\tCL_ED\tCL_WN\tCL_NB\tCL_kNN\tCL_Sem\tReference\n");

		//String uri = onto2.getLogicalURI().toString();
		String uri = onto2.getPhysicalURI().toString();
		String sub = uri.substring(0, uri.lastIndexOf('/'));
		String dirName = sub.substring(sub.lastIndexOf('/')+1, sub.length());
		String ref = (new File(System.getProperty("user.dir"))).toURI().toString() + dirName + "/" + "refalign.rdf";

		try {
			AlignmentParser parser = new AlignmentParser(0);
			Alignment refalign = parser.parse(ref, new Hashtable());
			fillResultTable(finalResultTable, refalign, "REFERENCE");
		}
		catch (ParserConfigurationException pce) {
			System.err.println("Parser Configuration exception ... " + pce.getMessage());
			pce.printStackTrace();
		}
		catch (SAXException saxe) {
			System.err.println("SAX exception ... " + saxe.getMessage());
			saxe.printStackTrace();
		}
		catch (IOException ioe) {
			System.err.println("IO exception ... " + ioe.getMessage());
			ioe.printStackTrace();
		}

		for (Iterator j=finalResultTable.keySet().iterator(); j.hasNext();) {
			String key = (String)j.next();
			Vector v = (Vector)finalResultTable.get(key);
			out.print(key);
			for (int k=0; k<30-key.length(); k++)
				out.print(" ");
			if (v.contains("CL_SN"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("CL_SS"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("CL_ED"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("CL_WN"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("CL_NB"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("CL_KNN"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("CL_Sem"))
				out.print("\t  1");
			else
				out.print("\t  0");
			if (v.contains("REFERENCE"))
				out.print("\t    1");
			else
				out.print("\t    0");
			out.println();
		}
		out.flush();
	}

	public void align(Alignment alignment, Parameters params) throws AlignmentException, OWLException {

		PrintWriter out = null;
		Hashtable finalResultTable = new Hashtable();

		long tb = System.currentTimeMillis();
		System.out.println("Loading the oMAP configuration file ...\n");

		try {
			InputStream configFile = OMapAlignment.class.getResourceAsStream("/oMAP.config");
			loadParam(configFile);
		}
		catch (Exception ex) {
			ex.printStackTrace(System.err);
		}

		/* Debug Mode */
		if (debug) {
			try {
				String id = onto2.getLogicalURI().toString();
				String test = id.replaceAll("[:/.#]", "_");
				out = new PrintWriter(new FileWriter("trace-" + test + ".txt"));
			}
			catch (IOException ioe) {
				System.err.println("IO exception ... " + ioe.getMessage());
				ioe.printStackTrace();
			}
		}

		System.out.println("Beginning the ontology alignment ...\n");
		Vector mappingsFound = new Vector();

		/* Generate the possible mapping rules */
		System.out.println("Generate all possible mapping rules ...");
		Vector allMappings = generateAllMappings();
		System.out.println("\tFound " + allMappings.size() + " possible pairs");

		int i = 1;
		for (Iterator iter=classifierPriorityList.iterator(); iter.hasNext();) {
			String classifier = (String)iter.next();
			if (classifier.equals("CL_SN")) {
				/* Applying the SameNameClassifier */
				System.out.println("\n" + i + ") Applying the SameNameClassifier (same fragment or same URI) ...");
				params.setParameter("allMappings", allMappings);
				SameNameClassifier clName = new SameNameClassifier(onto1, onto2);
				clName.align(alignment, params);
				System.out.println("\tFound " + clName.nbCells() + " matching entities on possible " + allMappings.size());
				ingest(clName);
				if (debug) {
					fillResultTable(finalResultTable, clName, "CL_SN");
				}
				if (chaining) {
					allMappings = clName.pruneMappingsFound(allMappings, clName.buildMappingsFound(this));
				}
			}
			else if (classifier.equals("CL_SS")) {
				/* Applying the SameStemClassifier */
				System.out.println("\n" + i + ") Applying the SameStemClassifier (same stem fragment or same URI) ...");
				params.setParameter("allMappings", allMappings);
				SameStemClassifier clStem = new SameStemClassifier(onto1, onto2);
				clStem.align(alignment, params);
				System.out.println("\tFound " + clStem.nbCells() + " matching entities on possible " + allMappings.size());
				ingest(clStem);
				if (debug) {
					fillResultTable(finalResultTable, clStem, "CL_SS");
				}
				if (chaining) {
					allMappings = clStem.pruneMappingsFound(allMappings, clStem.buildMappingsFound(this));
				}
			}
			else if (classifier.equals("CL_ED")) {
				/* Applying the EditDistanceClassifier */
				System.out.println("\n" + i + ") Applying the EditDistanceClassifier ...");
				params.setParameter("allMappings", allMappings);
				EditDistNameAlignment clED = new EditDistNameAlignment(onto1, onto2);
				clED.align(alignment, params);
				clED.cut2(0.9);
				System.out.println("\tFound " + clED.nbCells() + " matching entities (with threshold=0.9)");
				ingest(clED);
				if (debug) {
					fillResultTable(finalResultTable, clED, "CL_ED");
				}
				if (chaining) {
					//allMappings = clEd.pruneMappingsFound(allMappings, clEd.buildMappingsFound(this));
				}
			}
			else if (classifier.equals("CL_WN")) {
				/* Applying the WordNet Classifier */
				System.out.println("\n" + i + ") Applying the WordNetClassifier ...");
				params.setParameter("allMappings", allMappings);
				JWNLAlignment clWN = new JWNLAlignment(onto1, onto2);
				clWN.align(alignment, params);
				System.out.println("\tFound " + clWN.nbCells() + " matching entities");
				ingest(clWN);
				if (debug) {
					fillResultTable(finalResultTable, clWN, "CL_WN");
				}
				if (chaining) {
					//allMappings = clWN.pruneMappingsFound(allMappings, clWN.buildMappingsFound(this));
				}
			}
			else if (classifier.equals("CL_NB")) {
				/* Applying the Naive Bayes Classifier */
				System.out.println("\n" + i + ") Applying the NaiveBayesClassifier ...");
				NaiveBayesClassifier clNB = new NaiveBayesClassifier(onto1, onto2, instanceDepth);
				/*
				 try {
				 String id = onto2.getLogicalURI().toString();
				 String test = id.replaceAll("[:/.#]", "_");
				 PrintWriter out = new PrintWriter(new FileWriter("intances-" + test + ".txt"));
				 clNB.printAllInstances(onto2, instanceDepth, out);
				 out.flush();
				 }
				 catch (IOException ioe) {
				 System.err.println("IO exception ... " + ioe.getMessage());
				 ioe.printStackTrace();
				 }
				 */
				Vector instanceMappings = clNB.generatePossibleMappings();
				params.setParameter("instanceMappings", instanceMappings);
				// Chain the classifiers
				if (chaining) {
					params.setParameter("mappingsFound", clNB.buildMappingsFound(this));
				}
				clNB.align(alignment, params);
				System.out.println("\tFound " + clNB.nbCells() + " matching entities on possible " + instanceMappings.size());
				ingest(clNB);
				if (debug) {
					fillResultTable(finalResultTable, clNB, "CL_NB");
				}
				if (chaining) {
					allMappings = clNB.pruneMappingsFound(allMappings, clNB.buildMappingsFound(this));
				}
			}
			else if (classifier.equals("CL_kNN")) {
				/* Applying the kNN Classifier */
				System.out.println("\n" + i + ") Applying the kNNClassifier ...");
				kNNClassifier clKNN = new kNNClassifier(onto1, onto2, instanceDepth);
				Vector instanceMappings = clKNN.generatePossibleMappings();
				params.setParameter("instanceMappings", instanceMappings);
				// Chain the classifiers
				if (chaining) {
					params.setParameter("mappingsFound", clKNN.buildMappingsFound(this));
				}
				clKNN.align(alignment, params);
				System.out.println("\tFound " + clKNN.nbCells() + " matching entities on possible " + instanceMappings.size());
				ingest(clKNN);
				if (debug) {
					fillResultTable(finalResultTable, clKNN, "CL_KNN");
				}
				if (chaining) {
					allMappings = clKNN.pruneMappingsFound(allMappings, clKNN.buildMappingsFound(this));
				}
			}
			else if (classifier.equals("CL_Sem")) {
				/* Applying the StructuralClassifier */
				System.out.println("\n" + i + ") Applying the StructuralClassifier ...");
				params.setParameter("allMappings", allMappings);
				StructuralClassifier clStruct = new StructuralClassifier(onto1, onto2);
				params.setParameter("mappingsFound", this);
				clStruct.align(alignment, params);
				System.out.println("\tFound " + clStruct.nbCells() + " matching entities");
				ingest(clStruct);
				if (debug) {
					fillResultTable(finalResultTable, clStruct, "CL_SS");
				}
				if (chaining) {
					allMappings = clStruct.pruneMappingsFound(allMappings, clStruct.buildMappingsFound(this));
				}			
			}
			else
				System.out.println("WARNING: the classifier " + classifier + " does not exist!\n");
			i++;

			if (allMappings.isEmpty()) {
				System.out.println("\nAll possible mappings were considered!");
				break;
			}
		}
		/* Generate the Alignment Cells */
		System.out.println("Generating the final alignment ... it contains " + nbCells() + " cells!");

		/* Debug Mode */
		if (debug)
			printResultTable(finalResultTable, out);

		long te = System.currentTimeMillis() - tb;
		System.out.println("\nJob done in " + te + " milliseconds!");
	}

}