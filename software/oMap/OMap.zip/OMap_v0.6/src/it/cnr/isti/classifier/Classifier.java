/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
import java.util.HashSet;

import org.semanticweb.owl.model.*;
import org.semanticweb.owl.align.Cell;
import fr.inrialpes.exmo.align.impl.BasicAlignment;

import it.cnr.isti.util.Tuple;

/** The Abstract Classifier Class. From a Source Ontology S and
	a Target Ontology T, a Classifier will try to align them

    The <CODE>source_ontology</CODE> and <CODE>target_ontology</CODE> are absolute URIs.

@author Rapha�l Troncy
 */

public abstract class Classifier extends BasicAlignment {

	public Classifier(OWLOntology onto1, OWLOntology onto2) {

		init(onto1, onto2);
		setType("11");
	}

	public OWLOntology getSourceOntology() {

		return onto1;
	}

	public void setSourceOntology(OWLOntology sOnto) {

		onto1 = sOnto;
	}

	public OWLOntology getTargetOntology() {

		return onto2;
	}

	public void setTargetOntology(OWLOntology tOnto) {

		onto2 = tOnto;
	}

	public void printMappingRules(Vector mappings, PrintWriter out) {

		if (!mappings.isEmpty()) {
			out.println("The matching entries are:");
			for (Iterator i=mappings.iterator(); i.hasNext();) {
				Tuple rule = (Tuple)i.next();
				out.println("\t" + rule.toString());
			}
			out.println();
		}
	}

	public Vector clean(Vector possibleMappings, Vector mappingsFound) {

		Vector mappings = new Vector(possibleMappings);
		for (Iterator i=possibleMappings.iterator(); i.hasNext();) {
			Tuple emptyRule = (Tuple)i.next();
			for (Iterator j=mappingsFound.iterator(); j.hasNext();) {
				Tuple rule = (Tuple)j.next();
				if (((OWLNamedObject)emptyRule.get(1)).equals((OWLNamedObject)rule.get(1)) && ((OWLNamedObject)emptyRule.get(2)).equals((OWLNamedObject)rule.get(2)))
					mappings.remove(emptyRule);
			}
		}
		return mappings;
	}

	protected Vector dropZero(Vector mappings) {

		int i = 0;
		while (!mappings.isEmpty() && i<mappings.size()) {
			Tuple rule = (Tuple)mappings.get(i);
			if (((Double)rule.get(3)).doubleValue() == 0.0)
				mappings.removeElement(rule);
			else
				i = i+1;
		}
		return mappings;
	}

	protected Vector normalize(Vector mappings) {

		double min = 1.0;
		double max = 0.0;
		for (Iterator i=mappings.iterator(); i.hasNext();) {
			Tuple rule = (Tuple)i.next();
			min = Math.min(min, ((Double)rule.get(3)).doubleValue());
			max = Math.max(max, ((Double)rule.get(3)).doubleValue());
		}
		for (Iterator i=mappings.iterator(); i.hasNext();) {
			Tuple rule = (Tuple)i.next();
			double v = (((Double)rule.get(3)).doubleValue()-min) / (max-min);
			// To Keep the min to its value
			if (v != 0)
				rule.set(3, new Double(v));
		}
		return mappings;
	}

	public Vector buildMappingsFound(BasicAlignment alignment) {

		Vector mappingsFound = new Vector();
		for (Enumeration e=alignment.getElements(); e.hasMoreElements(); ) {
			Cell c = (Cell)e.nextElement();
			Tuple rule = new Tuple(new Object[4]);
			if (c.getObject1() instanceof OWLClass) {
				rule.set(0, "CLASS");
				rule.set(1, (OWLClass)c.getObject1());
				rule.set(2, (OWLClass)c.getObject2());
			}
			else if (c.getObject1() instanceof OWLProperty) {
				rule.set(0, "PROPERTY");
				rule.set(1, (OWLProperty)c.getObject1());
				rule.set(2, (OWLProperty)c.getObject2());
			}
			else
				System.out.println("ERROR! " + c.getObject1());
			rule.set(3, new Double(c.getStrength()));
			mappingsFound.add(rule);
		}
		//System.out.println("\tAlready found " + mappingsFound.size() + " mappings ...");
		return mappingsFound;
	}

	public Vector pruneMappingsFound(Vector allMappings, Vector mappingsFound) {

		// Apply the 1-1 strategy: a source entity can be aligned with at most one target entity
		Vector result = new Vector();
		result.addAll(allMappings);
		for (Iterator i=mappingsFound.iterator(); i.hasNext();) {
			Tuple ruleFound = (Tuple)i.next();
			for (Iterator j=allMappings.iterator(); j.hasNext();) {
				Tuple rule = (Tuple)j.next();
				if (rule.get(1).equals(ruleFound.get(1))) {
					result.remove(rule);
				}
			}
		}
		//System.out.println("\tRemain to process " + result.size() + " possible mappings ...");
		return result;
	}
}