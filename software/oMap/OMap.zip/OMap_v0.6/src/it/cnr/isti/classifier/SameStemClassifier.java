/*
 *
 * The Initial Developer of the Original Code is Rapha�l Troncy.
 * Copyright (C) 2005. All Rights Reserved.
 *
 * Modifications to the initial code base are copyright of their
 * respective authors, or their employers as appropriate. Authorship
 * of the modifications may be determined from the ChangeLog placed at
 * the end of this file.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA.
 ****************************************************************/

package it.cnr.isti.classifier;

import java.net.URI;

import org.semanticweb.owl.model.*;
import de.unidu.is.text.StemmerFilter;

/** The Same Stem Classifier Class.
 * Adapted from $Id: SameStemClassifier.java,v 1.1 2005/01/03 09:28:22 nottelma Exp $

@author Rapha�l Troncy
 */

public class SameStemClassifier extends BinaryPredictionClassifier {

	private static StemmerFilter stemmer = new StemmerFilter(null);

	public SameStemClassifier(OWLOntology onto1, OWLOntology onto2) {

		super(onto1, onto2);
	}

	/**
	 * Computes a prediction Pr(A|B,C) by applying this classifier C.
	 * 
	 * @param nameA entity name A
	 * @param nameB entity name B
	 * @return prediction value Pr(A|B,C)
	 */
	protected double predict(URI entityA, URI entityB) {

		if ((entityA.getFragment()==null) || (entityB.getFragment())==null)
			return entityA.toString().equals(entityB.toString()) ? 1.0 : 0.0;
		else {
			String stemA = stemmer.run(entityA.getFragment()).toString();
			String stemB = stemmer.run(entityB.getFragment()).toString();
			return stemA.equals(stemB) ? 1.0 : 0.0;
		}
	}

}