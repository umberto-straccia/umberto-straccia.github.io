// $Id: SingleItemIterator.java,v 1.2 2003/07/06 15:14:19 nottelma Exp $
package de.unidu.is.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A iterator that returns only one single item.
 *
 * @author Henrik Nottelmann
 * @since 2001-04-29
 * @version $Revision: 1.2 $, $Date: 2003/07/06 15:14:19 $
 * @status finished 2001-06-29
 * @tests finished 2001-06-29
 */
public class SingleItemIterator implements Iterator {

	/**
	 * The only object returned by this iterator.
	 * 
	 * @status finished 2001-06-29
	 */
	protected Object item;

	/**
	 * Indicates if next() has ever been called.
	 *
	 * @status finished 2001-06-29
	 */
	protected boolean called;

	/**
	 * Creates a new iterator.
	 * 
	 * @param item only object returned by this iterator
	 * @status finished 2001-06-29
	 */
	public SingleItemIterator(Object item) {
		this.item = item;
		this.called = false;
	}

	/**
	 * Returns true if this iterator has more elements.
	 *
	 * @return true if the iterator has more elements
	 * @status finished 2001-06-29
	 */
	public boolean hasNext() {
		return !called;
	}

	/**
	 * Returns the next object.
	 * 
	 * @return next object
	 * @throws NoSuchElementException if there is no object available
	 * @status finished 2001-06-29
	 */
	public Object next() {
		if (called)
			throw new NoSuchElementException();
		called = true;
		return item;
	}

	/**
	 * <b>Removing objects is unsupported!</B>
	 * 
	 * @status finished 2001-06-29
	 */
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
