// $Id: EmptyIterator.java,v 1.2 2003/07/06 15:11:58 nottelma Exp $
package de.unidu.is.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A iterator over an empty set.
 *
 * @author Henrik Nottelmann
 * @since 2003-07-05
 * @version $Revision: 1.2 $, $Date: 2003/07/06 15:11:58 $
 * @status finished 2003-07-05
 */
public class EmptyIterator implements Iterator {


	/**
	 * Returns always <code>false</code>.
	 *
	 * @return always false
	 * @status finished 2003-07-05
	 */
	public boolean hasNext() {
		return false;
	}

	/**
	 * Always throws a <code>NoSuchElementException</code>.
	 * 
	 * @return nothing (an exception will be thrown)
	 * @throws NoSuchElementException 
	 * @status finished 2003-07-05
	 */
	public Object next() {
			throw new NoSuchElementException();
	}

	/**
	 * <b>Removing objects is unsupported!</B>
	 * 
	 * @status finished 2003-07-05
	 */
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
