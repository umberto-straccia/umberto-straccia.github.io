// $Id: StemmerFilter.java,v 1.4 2004/12/09 15:26:47 nottelma Exp $
package de.unidu.is.text;

/**
 * This filter converts a specified string into stemmed version.
 * <p>
 * 
 * This implementation uses the nonfree version is available (for backwards
 * compatibility), and the Apache Lucene implementation otherwise.
 * 
 * @author Henrik Nottelmann
 * @since 2003-07-04
 * @version $Revision: 1.4 $, $Date: 2004/12/09 15:26:47 $
 */
public class StemmerFilter extends AbstractSingleItemFilter {

	/**
	 * Soundex filter to which calls are delegated.
	 */
	protected SingleItemFilter stemmerFilter;

	/**
	 * Creates a new instance and sets the next filter in the chain.
	 * 
	 * @param nextFilter
	 *                   next filter in the filter chain
	 */
	public StemmerFilter(Filter nextFilter) {
		super(nextFilter);
		try {
			// test for nonfree version
			stemmerFilter = (SingleItemFilter) Class.forName(
					"de.unidu.is.text.NonFreeStemmerFilter").getConstructor(
					new Class[]{Filter.class}).newInstance(new Object[]{null});
		} catch (Exception e) {
			// use Codec instead
			stemmerFilter = new LuceneStemmerFilter(null);
		}
	}

	/**
	 * Converts the specified word into its stemmed version.
	 * 
	 * @param value
	 *                   word to stem
	 * @return stemmed word
	 */
	public Object run(Object value) {
		return stemmerFilter.run(value);
	}

}