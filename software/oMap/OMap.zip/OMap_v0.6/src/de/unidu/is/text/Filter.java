// $Id: Filter.java,v 1.3 2003/07/05 16:27:47 nottelma Exp $
package de.unidu.is.text;

import java.util.Iterator;

/**
 * A filter is used to modify objects (in most cases, objects) in a uniform 
 * way.  The filter converts an object into a list of other objects, 
 * represented by an iterator. In addition, a filter can be called with an 
 * iterator; then, the filter is applied on each object returned by the
 * filter.  
 *   
 * @author Henrik Nottelmann
 * @since 2003-07-03
 * @version $Revision: 1.3 $, $Date: 2003/07/05 16:27:47 $
 * @status finished 2003-07-05
 */
public interface Filter {

	/**
	 * Applies this filter on the specified single object.
	 * 
	 * @param seed object on which the filter is applied
	 * @return iterator over the resulting objects
	 * @status finished 2003-07-03
	 */
	public abstract Iterator apply(Object seed);

	/**
	 * Applies this filter on each object returned by the specified iterator.
	 * 
	 * @param iterator iterator over objects on which the filter is applied
	 * @return iterator over the resulting objects
	 * @status finished 2003-07-03
	 */
	public abstract Iterator apply(Iterator iterator);

}
