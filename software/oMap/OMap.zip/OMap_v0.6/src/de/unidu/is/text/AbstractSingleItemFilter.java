// $Id: AbstractSingleItemFilter.java,v 1.3 2003/09/11 17:32:33 nottelma Exp $
package de.unidu.is.text;

import java.util.Iterator;

import de.unidu.is.util.EmptyIterator;
import de.unidu.is.util.SingleItemIterator;

/**
 * This is an abstract filter implementation which converts every object into
 * exactly one object (or into null), and which allows for chaining filters.<p>
 * 
 * Subclasses have to implement the actual filtering method.
 * 
 * @author Henrik Nottelmann
 * @since 2003-07-04
 * @version $Revision: 1.3 $, $Date: 2003/09/11 17:32:33 $
 * @status finished 2003-07-05
 */
public abstract class AbstractSingleItemFilter
	extends AbstractFilter
	implements SingleItemFilter {

	/**
	 * Creates a new instance and sets the next filter in the chain.
	 * 
	 * @param nextFilter next filter in the filter chain
	 * @status finished 2003-07-04
	 */
	public AbstractSingleItemFilter(Filter nextFilter) {
		super(nextFilter);
	}

	/**
	 * Applies only this filter on the specified object, without considering 
	 * the other filters from the filter chain.<p>
	 * 
	 * This method applies <code>run(String)</code> on the specified object,
	 * and then returns a <code>SingleItemIterator</code> returning the
	 * resulting object. If <code>run(String)</code> returns null, a
	 * <codeEmptyIterator</code> is returned.
	 *  
	 * @param value value to be modified by this filter
	 * @return iterator over the resulting objects
	 * @status finished 2003-07-04
	 * @see de.unidu.is.text.AbstractFilter#filter(java.lang.Object)
	 */
	protected Iterator filter(Object value) {
		value = run(value);
		if (value == null)
			return new EmptyIterator();
		return new SingleItemIterator(value);
	}

}
