// $Id: SequenceIterator.java,v 1.2 2003/07/06 15:14:19 nottelma Exp $
package de.unidu.is.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A iterator that is a sequence of several iterators. <p>

 * The sequence iterator has an iterator returning objects which can deliver
 * iterators. The delivered iterators are traversed one after another by this
 * iterator. 
 *
 * @author Henrik Nottelmann
 * @since 2001-06-29
 * @version $Revision: 1.2 $, $Date: 2003/07/06 15:14:19 $
 * @status finished 2001-06-29
 * @tests finished 2001-06-29
 */
public abstract class SequenceIterator implements Iterator {

	/**
	 * The iterator returning objects which can deliver iterators.
	 * 
	 * @status finished 2001-06-29
	 */
	protected Iterator iterator;

	/**
	 * The current iterator producing items which are returned by this class.
	 * 
	 * @status finished 2001-06-29
	 */
	protected Iterator currentIterator;

	/**
	 * The next object to be returned.
	 * 
	 * @status finished 2001-06-29
	 */
	protected Object next;

	/**
	 * Indicates if next() has ever been called. This is needed for 
	 * initialisation outside the constructor (because that does not work!).
	 *
	 * @status finished 2001-06-29
	 */
	protected boolean called;

	/**
	 * Creates a new sequence iterator.
	 * 
	 * @param iterator iterator returning objects which can deliver iterators
	 * @status finished 2001-06-29
	 */
	public SequenceIterator(Iterator iterator) {
		this.iterator = iterator;
	}

	/**
	 * Returns true if this iterator has more elements.
	 *
	 * @return true if the iterator has more elements
	 * @status finished 2001-06-29
	 */
	public boolean hasNext() {
		if (!called) {
			called = true;
			calcNext();
		}
		return next != null;
	}

	/**
	 * Returns the next object.
	 * 
	 * @return next object
	 * @throws NoSuchElementException if there is no object available
	 * @status finished 2001-06-29
	 */
	public Object next() {
		if (!called) {
			called = true;
			calcNext();
		}
		if (next == null)
			throw new NoSuchElementException();
		Object ret = next;
		next = null;
		calcNext();
		return ret;
	}

	/**
	 * Calculates the next object to be returned.
	 * 
	 * @status finished 2001-04-23
	 */
	protected void calcNext() {
		while (currentIterator == null || !currentIterator.hasNext())
			if (iterator.hasNext())
				currentIterator = createIterator(iterator.next());
			else
				return;
		next = currentIterator.next();
	}

	/**
	 * Calls the speicified object to create an iterator.
	 * This method has to be overridden!
	 * 
	 * @param object object which should create an iterator
	 * @return iterator
	 * @status finished 2001-06-29
	 */
	public abstract Iterator createIterator(Object object);

	/**
	 * <b>Removing objects is unsupported!</B>
	 * 
	 * @status finished 2001-04-23
	 */
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
