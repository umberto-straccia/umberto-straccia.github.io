// $Id: SingleItemFilter.java,v 1.2 2003/07/05 10:05:29 nottelma Exp $
package de.unidu.is.text;

/**
 * A filter which converts each object into exactly one object (or into null).
 * This property makes it easy to use the filter also in environments where
 * it is not desireable to use an iterator.
 * 
 * @author Henrik Nottelmann
 * @since 2003-07-04
 * @version $Revision: 1.2 $, $Date: 2003/07/05 10:05:29 $
 * @status finished 2003-07-05
 */
public interface SingleItemFilter {

	/**
	 * Applies this filter on the specified object, and returns a single 
	 * object (or null).
	 *  
	 * @param value value to be modified by this filter
	 * @return resulting object, or null
	 * @status finished 2003-07-04
	 */
	public Object run(Object value);
}
