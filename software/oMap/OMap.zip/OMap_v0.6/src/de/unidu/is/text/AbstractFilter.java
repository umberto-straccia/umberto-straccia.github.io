// $Id: AbstractFilter.java,v 1.6 2004/01/02 15:24:54 nottelma Exp $
package de.unidu.is.text;

import java.util.Iterator;

import de.unidu.is.util.SequenceIterator;
import de.unidu.is.util.SingleItemIterator;

/**
 * This is an abstract filter implementation which allows for chaining filters.
 * Chaining filters means that the output of one filter is used as the input 
 * of another filter. This makes it easy to combine simple filters for
 * advanced applications.
 * 
 * <code>
 * Filter filter = new StemmerFilter(new WordSplitterFilter(null));
 * Iterator iterator = filter.apply("The quick brown fox jumps");
 * </code>
 * 
 * This code block chains a <code>StemmerFilter</code> with a
 * <code>WordSplitterFilter</code>. This means that the string 
 * "The quick brown fox jumps" is first applied on the 
 * <code>WordSplitterFilter</code>, which leads to an iterator over
 * "the", "quick", "brown", "fox" and "jumps". These objects are then applied
 * on the  <code>StemmerFilter</code>, resulting in "the", "quick", "brown", 
 * "fox" and "jump" (instead of "jump").<p>
 * 
 * Subclasses have to implement the actual filtering method.
 *   
 * @author Henrik Nottelmann
 * @since 2003-07-03
 * @version $Revision: 1.6 $, $Date: 2004/01/02 15:24:54 $
 * @status finished 2003-09-23
 */
public abstract class AbstractFilter implements Filter {

	/**
	 * The next filter in the filter chain.
	 * 
	 * @status finished 2003-07-03
	 */
	protected Filter nextFilter;

	/**
	 * Creates a new instance and sets the next filter in the chain.
	 * 
	 * @param nextFilter next filter in the filter chain
	 * @status finished 2003-07-03
	 */
	public AbstractFilter(Filter nextFilter) {
		this.nextFilter = nextFilter;
	}

	/**
	 * Applies this filter on the specified single object.
	 * 
	 * @param seed object on which the filter is applied
	 * @return iterator over the resulting objects
	 * @status finished 2003-07-05
	 * @see de.unidu.is.text.Filter#apply(java.lang.Object)
	 */
	public Iterator apply(Object seed) {
		return apply(new SingleItemIterator(seed));
	}

	/**
	 * Applies this filter on each object returned by the specified 
	 * iterator.<p>
	 * 
	 * This method first calls the next filter in the filter chain (if 
	 * existing), and then applies this filter on the specified iterator.
	 * 
	 * @param iterator iterator over objects on which the filter is applied
	 * @return iterator over the resulting objects
	 * @status finished 2003-09-23
	 * @see de.unidu.is.text.Filter#apply(java.util.Iterator)
	 */
	public Iterator apply(Iterator iterator) {
		if (nextFilter != null)
			iterator = nextFilter.apply(iterator);
		return new SequenceIterator(iterator) {
			public Iterator createIterator(Object object) {
				return AbstractFilter.this.filter(object);
			}
		};
	}

	/**
	 * Applies only this filter on the specified object, without considering 
	 * the other filters from the filter chain.<p>
	 * 
	 * This method is the working horse of filters extending this class, and 
	 * the only method which has to be implemented in concrete filters. The
	 * chaining of filters in done on <code>apply(Iterator)</code>.
	 *  
	 * @param value value to be modified by this filter
	 * @return iterator over the resulting objects
	 * @status finished 2003-07-03
	 */
	protected abstract Iterator filter(Object value);

}
