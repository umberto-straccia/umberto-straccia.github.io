@echo off

rem author: R. Troncy - IST/CNR - 22/08/2005

rem -----------------
rem    MAIN SCRIPT
rem -----------------

echo **  oMap - Raphael Troncy - 22/08/2005 **
echo **  OAEI Contest 2005 - Banff, Canada  **
echo **   Data from the 2005 OAEI Campaign  **
echo **     Benchmarks systematic tests     **

set WORK_DIRECTORY="D:\ERCIM\CNR Pise\Implementation\OMap"
set OAEI_DIRECTORY=D:\ERCIM\Ontologies\benchmarks
set BASE_URI=file:///D:/ERCIM/Ontologies/benchmarks

@echo.
set sourceOnto=%BASE_URI%/101/onto.rdf

set method=it.cnr.isti.OMapAlignment
set renderer=fr.inrialpes.exmo.align.impl.renderer.RDFRendererVisitor

cd %OAEI_DIRECTORY%

FOR %%x IN ( 201 202 203 204 205 206 207 208 209 210 221 222 223 224 225 228 230 231 232 233 236 237 238 239 240 241 246 247 248 249 250 251 252 253 254 257 258 259 260 261 262 265 266 ) DO IF EXIST %%x\onto.rdf ( CALL:align %%x ) ELSE echo    Test %%x didn't exist !

@echo.
echo **  Overall Evaluation  **

cd %OAEI_DIRECTORY%

set color=lightblue
set format=prfmo
set list=isti-cnr-benchmarks

@echo.
echo **  Generating HTML Result  **
set type=html
set output=%WORK_DIRECTORY%\result_isti_benchmarks_2xx.html
java -cp %WORK_DIRECTORY%/lib/procalign.jar fr.inrialpes.exmo.align.util.GroupEval -c %color% -f %format% -t %type% -l %list% -o %output%

cd %WORK_DIRECTORY%

set WORK_DIRECTORY=
set OAEI_DIRECTORY=
set BASE_URI=

echo **  END SCRIPT **

pause

rem ------------------
rem    ALIGN SCRIPT
rem ------------------

:align
@echo.
echo    Running test %1 ...
cd %1
del isti-cnr-benchmarks.rdf
cd ..
set targetOnto=%BASE_URI%/%1/onto.rdf
set resultFile=%1/isti-cnr-benchmarks.rdf
java -jar %WORK_DIRECTORY%/lib/omap.jar -i %method% -r %renderer% -o %resultFile% %sourceOnto% %targetOnto%
