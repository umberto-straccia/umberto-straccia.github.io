; ************************************************************
; Version:       1.0 (1997-02-26)
; Modifications: Ullrich Hustadt     1996-1997
;                Roberto Sebastiani
;                Enrico  Franconi
;                Umberto Straccia
; ************************************************************

; This is a propositional version of Hustadt's generator. 
; It generates random 3SAT propositions

; Declaration of parameters

;(load "3sat-random-gen-vars.lsp")

;--------------------------------------


;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% random propositional formulae generator
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;******************* general *************************************************

(defun gen-rand-prop (len)
  (progn
    (setq *and_br* len)
    (get-3sat-random-proposition)
  )
)
    
(defun get-3sat-random-proposition ()
  (let ((p (rand-conjunction-mak *and_br*)))
       (if (= 1 (length p))
           (car p)
           (p-mkand p)
       )
  )
)


;******************* make conjunction *********************************************

(defun rand-conjunction-mak (branch_rate)
 (cond
  ((equal branch_rate 0) NIL)
  ((equal branch_rate 1) (list (rand-disjunction-mak)))
  (T (cons (rand-disjunction-mak)
           (rand-conjunction-mak (- branch_rate 1))))))

;******************* make disjunction *********************************************

(defun rand-disjunction-mak ()
  (let ((p (rand-fixed-length-disjunction *or_br* NIL)))
       (if (= 1 (length p))
           (car p)
           (p-mkor p)
       )
  )
)

(defun rand-fixed-length-disjunction (branch_rate subterm-list)
 (cond
  ((equal branch_rate 0) NIL)
  ((equal branch_rate 1) (list (rand-literal-mak subterm-list)))
  (t (let ((subterm (rand-literal-mak subterm-list)))
       (cons subterm
	     (rand-fixed-length-disjunction (- branch_rate 1) 
					    		        (cons subterm subterm-list)))))))


;******************* literals *****************************************************

(defun rand-literal-mak (subterm-list)
  (let ((letter (p-mknumletter (+ 1 (random *var_num*)))))
    (if (or (member letter subterm-list :test #'equal)
	        (member (p-mknot letter) subterm-list :test #'equal))
	    (rand-literal-mak subterm-list)
        (if (rand-event *neg_prob*)
	        (p-mknot letter)
	        letter))))



;******************* random event ****************************************

;;returns T with probability prob, NIL with prbability 1-prob;
(defun rand-event (prob) (> (* prob *MAX_NUM*) (random *MAX_NUM*) ))

;***********************************************************



