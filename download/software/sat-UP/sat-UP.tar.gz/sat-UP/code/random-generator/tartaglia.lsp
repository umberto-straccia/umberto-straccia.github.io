;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Building of Tartaglia's triangles algorithm                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Antonio Lopreiato                                                       %                                                
;%%% antonio@iei.pi.cnr.it                                                   %                                                
;%%%                                                                         % 
;%%% March, 6th 1998                                                         %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

(defvar *tr_tar*)  

; builts a new Tartaglia's triangle and sets *tr_tar* to it
(defun make-Tartaglia (n)
  (setq *tr_tar* (Tartaglia n))
)

; builts a Tartaglia's triangle of n rows and returns it
(defun Tartaglia (n)
  (progn
     (setf tr (make-array (- n 1) :initial-element nil)) 
     (setf r1 (vector 1 2 1))
     (setf (svref tr 0) r1)
     (do ((r 1 (+ r 1)))
         ((>= r (- n 1)))
         (setf (svref tr r) (mk-row (svref tr (- r 1)) (+ r 2))) 
     )
     tr
   )
 )

; builts a row of triangle given the previous one 
(defun mk-row (tr-row d)
   (progn      
      (setf dim (+ d 1)) ;(floor (/ d 2)))
      (setf col (make-array dim :initial-element 1))
      (do ((j 1 (+ j 1)))
          ((>= j (- dim 1)))
          (setf (svref col j) (+ (svref tr-row (- j 1)) (svref tr-row j)))
      )
      col
    )
)

; return the binomial coefficient (n on k)
(defun get-n-k (tr n k)
   (if (or (= n 0) (= n 1))
        1
       (svref (svref tr (- n 2)) k)
    )
)

; default value for *tr_tar*
(setq *tr_tar* (make-Tartaglia 40))
