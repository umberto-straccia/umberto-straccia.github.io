;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% print functions for test                                                           %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; prints the header
(defun print-header (samples-per-point num-cl-start num-cl-end step)
 (princ
  (format nil 
   "#Cl-start ~10A ~
   #Cl-end ~9A ~
   #Cl-step ~3A ~
   #Samples/point: ~4A ~
   #Var ~3A ~
   Random-seed ~%"
   "" "" "" "" "" "")
   *result-stream*)
 (princ
      (format nil 
              "~22A ~
              ~18A ~
              ~14A ~
              ~16A ~
              ~6A ~
              ~A ~%"
              num-cl-start 
              num-cl-end 
              step
              samples-per-point  
              *var_num*
              *random-state*)
      *result-stream*)
 (princ 
   (format nil 
   "<Sat result> ~3A ~
   <Number of States> ~3A ~
   <Time> ~3A ~%"
    "" 
    ""  
    "")
  *result-stream*)
)
 
(defun print-clauses-num (i) 
 (princ
  (format nil "#Clauses: ~D ~%" i)
  *result-stream*)
)  
 
;; print the proposition p
 
(defun print-wff (p)
 (print p *wff-stream*)
)

(defun print-KB (KB file)
 (print KB file)
)

(defun print-sat (result deltat)
 (progn
   (setq number-of-states (first result))
   (setq sat (second result))
   (if sat
       (setq val "S")
       (setq val "U")
   )
   (princ
      (format nil 
              "~10A ~
              ~14D ~
              ~19,2F ~%"
              val
              number-of-states
              deltat)
      *result-stream*)
  )
)


(defun print-model-info (ml dt)
 (progn
   (setq l (length ml))
   (setq s (reduce #'+ (mapcar #'length ml) :initial-value 0))
   (setq avg (and (not (zerop l)) (float (/ s l)))) 
   (princ
     (format nil 
       "#Models ~10A ~
        avg-length ~9A ~
        time ~%"
         "" "" "")
    *result-stream*)
    (princ
      (format nil 
              "~8A ~
              ~16,2F ~
              ~18,2F ~%"
              l 
              avg 
              dt)
      *result-stream*)
    (princ 
   (format nil 
   "<Sat result> ~3A ~
   <Number of States> ~3A ~
   <Time> ~3A ~%"
    "" 
    ""  
    "")
  *result-stream*)
 )
)

(defun print-header-ext (samples-per-point num-cl-start num-cl-end step)
 (princ
  (format nil 
   "#Cl-start ~10A ~
   #Cl-end ~9A ~
   #Cl-step ~3A ~
   #Samples/point: ~4A ~
   #Var ~3A ~
   Random-seed ~%"
   "" "" "" "" "" "")
   *result-stream*)
 (princ
      (format nil 
              "~22A ~
              ~18A ~
              ~14A ~
              ~16A ~
              ~6A ~
              ~A ~%"
              num-cl-start 
              num-cl-end 
              step
              samples-per-point  
              *var_num*
              *random-state*)
      *result-stream*)
)
;-----------------------------------------------------------------------
