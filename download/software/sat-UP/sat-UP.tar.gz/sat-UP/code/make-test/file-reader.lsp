;;-----------------------------------------------------
;; getfiles (pathstring)
;;
;; Input :a string which is the path of a directory
;;        (the string must end with a /)
;; Return: the list of all files onto that directory
;;-----------------------------------------------------

(defun getfiles (pathstring)
 (progn
   (setq dirstr (directory-namestring pathstring))
   (setq files-into (cddr (directory dirstr)))
   (setq fnames (mapcar #'file-namestring files-into))
   (setq files (mapcar #'(lambda (fn) 
                           (concatenate 'string dirstr fn)) fnames))
   files
 )
)