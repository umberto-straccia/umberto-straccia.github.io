;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Syntax Checker for propositional language L                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This is a Syntax Checker for the Propositional Language L.

;;The language contains letters (denoted by P) 
;;and propositions denoted by (A,B) which are built 
;;according to the following rule:
;;
;;A,B -> P              ;letter
;;     | *top*          ;true
;;     | *bot*          ;false
;;     | (not A)        ;negation
;;     | (and A B ...)  ;conjunction
;;     | (or A B ...)   ;disjunction


;; load macro functions
;;(load "language-macros-L.lsp")

;; Check the syntax of an L propositions
;; *************************************

;;--------------------------------------------------------------------------- 
;;check-proposition(p):
;;INPUT:   p = expression
;;RETURN:  p, if p is L-proposition
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-proposition (p)
  (cond 
    ((p-isletter p) p) 
	((and (p-isnot p)
	      (check-proposition (p-get-argument p))) 
	  p) 
	((and (or (p-isand p) (p-isor p) (p-isif p) (p-isiff p))
	      (check-propositions (p-get-arguments p))) 
	 p)
	(t (format *standard-output* "==> Illegal L proposition expression ~S~%" p) 
	   nil)))

;;--------------------------------------------------------------------------- 
;;check-propositions (plist):
;;INPUT:   plist = list of expressions
;;RETURN:  plist, if p is alist of  L-propositions
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-propositions(plist)
  (cond ((null plist) t)
        (t (and (check-proposition (first plist))
		        (check-propositions (rest plist))))))
