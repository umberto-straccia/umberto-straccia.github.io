;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This file contains the function in order to execute about sat problems

;;--------------------------------------------------------------------------- 
;; p-sat (p)
;; Input: proposition 
;; Return: result = true if SAT p
;;--------------------------------------------------------------------------- 


(defun p-sat (p) 
 (progn
       (setq result (p-sat-exec (list p)))
       (second result) ;; return result
 )
)


;;--------------------------------------------------------------------------- 
;; p-sat-KB (p-list)
;; Input: list of propositions, i.e. a KB 
;; Return: result = true if SAT p-list
;;--------------------------------------------------------------------------- 

(defun p-sat-KB (p-list) 
 (progn
       (setq result (p-sat-exec p-list))
       (second result) ;; return result
 )
)

;;--------------------------------------------------------------------------- 
;; p-logically-implies (kb p)
;; Input: kb = list of propositions, i.e. a KB 
;;        p  = a proposition
;; Return: result = true if KB |= p
;;--------------------------------------------------------------------------- 

(defun p-logically-implies (kb p)
 (progn
       (setq s (append (list (p-mknot p)) kb))
       (not (p-sat-KB s))
 )
)

;;--------------------------------------------------------------------------- 
;; p-tautology (p)
;; Input: p  = a proposition
;; Return: result = true if |= p
;;--------------------------------------------------------------------------- 

(defun p-tautology (p)
  (not (p-sat (p-mknot p)))
)

;;--------------------------------------------------------------------------- 
;; p-get-a-model (p)
;; Input: proposition 
;; Return: a list of letters = a Herbrand model of p, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-get-a-model (p) 
 (progn
       (setq result (p-sat-exec (list p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; p-KB-get-a-model (p-list)
;; Input: a list of propositions 
;; Return: a list of letters = a Herbrand model of p-list, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-KB-get-a-model (p-list) 
 (progn
       (setq result (p-sat-exec p-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; p-get-all-models (p)
;; Input: proposition 
;; Return: a list of letters = a Herbrand model of p, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-get-all-models (p) 
 (progn
       (setq result (p-all-models-exec (list p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; p-KB-get-all-models (p-list)
;; Input: a list of propositions 
;; Return: a list of letters = a Herbrand model of p-list, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-KB-get-all-models (p-list) 
 (progn
       (setq result (p-all-models-exec p-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;---------------------------------------------------------------------------


