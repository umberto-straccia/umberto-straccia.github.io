;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% load random gemerator procedure                                                   %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; parameter values
(load "code/random-generator/3sat-random-gen-vars.lsp")

;; generator
(load "code/random-generator/3sat-random-gen.lsp")

;; KB generator
(load "code/random-generator/kb-random-gen.lsp")