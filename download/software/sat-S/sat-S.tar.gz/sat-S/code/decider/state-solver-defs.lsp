;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Definitions and functions related to the Search Space algorithm         %                                         
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             % 
;%%%                                                                         %                    
;%%%                                                                         %
;%%% Modified, in order to implement calculus for signed proposition,        %
;%%% by Antonio Lopreiato                                                    %
;%%%                                                                         %
;%%% February, 20th 1998                                                     %
;%%%                                                                         %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;;---------------------------------------------------------------------------- 
;; number of states
;;--------------------------------------------------------------------------- 

(defvar *number-of-states* 0)

(defun init-number-of-states ()
   (setq *number-of-states* 0)
)

;;---------------------------------------------------------------------------- 
;; Sat state type definition

            
(defstruct sat-state
    id                            ; the key id for the state
    pred                          ; predecessor states
    succ                          ; succesor states
    (info nil :type sat-state-info)  ; our data information 
)

(defstruct sat-state-info
    andl                        ; list of ANDs
    orl                         ; list of ORs
    posl                        ; list of positive letters
    negl                        ; list of negative  letters
    not-posl                    ; list of positive not's, i.e. (TT (not A))
    not-negl                    ; list of negative not's, i.e. (NT (not A))
    posl-modified               ; boolean = true iff posl modified
    negl-modified               ; boolean = true iff negl modified
    not-posl-modified           ; boolean = true iff not-posl modified
    not-negl-modified           ; boolean = true iff not-negl modified
)




(defun sat-state-make (state info-arg)
 (progn
    (setq newid (incf *number-of-states*))
    (setf (sat-state-succ state) (push newid (sat-state-succ state)))
    (setq result (make-sat-state 
                    :id newid 
                    :pred (sat-state-id state)
                    :succ ()
                    :info info-arg))
    result ; returned value
                    
 )
)

(defun sat-initial-state-make (argl)
 (progn
    (setq result nil)
    (setq newid (incf *number-of-states*))
    (setq sat-state-info-tmp
            (sat-state-info-make-from-choice argl () () () () () () nil nil nil nil))        
     
    (setq result (make-sat-state :id newid
                                 :pred ()
                                 :succ ()
                                 :info sat-state-info-tmp))
     result   ; returned result
 )
)

(defun sat-state-info-make 
    (andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)
 (make-sat-state-info  :andl andl-arg 
                       :orl  orl-arg 
                       :posl posl-arg 
                       :negl negl-arg 
                       :not-posl not-posl-arg
                       :not-negl not-negl-arg
                       :posl-modified posl-modified-arg  
                       :negl-modified negl-modified-arg
                       :not-posl-modified not-posl-modified-arg  
                       :not-negl-modified not-negl-modified-arg)
                                                   
)


;;--------------------------------------------------------------------------- 
;;
;; get-reduced-s-prop (argl positivel negativel)
;;
;; input : argl which is a formula, other arguments are 
;;         informations on actual state 
;;
;; output: a new signed formula getted by deleting letter
;;         which lie in bother formula and positive or negative
;;         (if formula is an AND or an OR), or NIL if there is
;;         no intersection
;;
;;--------------------------------------------------------------------------- 


(defun get-reduced-s-prop (argl positivel negativel)
  (progn
    (setq p-result nil)
    (setq argl-lit (get-literals-from-prop argl))
    (if (p-isand argl)
	(progn
	  (setq sign NT)
	  (setq inter-set (intersection argl-lit positivel :test #'equal))
	)
        (progn
	  (setq sign TT)
	  (setq inter-set (intersection argl-lit negativel :test #'equal))
	)   
    )
    (if (not (null inter-set))
       	  (progn
       	    (setq diff-set (set-difference (p-get-arguments argl) inter-set :test #'equal))
	    (if (null diff-set)
		  (setq p-result (s-p-mkTT bot))  ;; restituisco contraddizione
		  (if (equal sign NT)		     
		        (setq p-result (s-p-mkNT (p-simplify (p-mkand (pushnew TOP diff-set)))))
		        (setq p-result (s-p-mkTT (p-simplify (p-mkor (pushnew BOT diff-set)))))      
		  )
	    )
	  )
    )
    p-result
  )
)


;;--------------------------------------------------------------------------- 
;;
;; 2V-get-reduced-s-prop-from-if (argl posl-arg negl-arg andl-arg orl-arg)
;;
;; input : argl which is a if-formula, other arguments are 
;;         informations on actual state 
;;
;; output: signed TT first argument of if-formula or
;;         signed NT second argument of if-formula or NIL
;;
;;--------------------------------------------------------------------------- 

(defun 2V-get-reduced-s-prop-from-if (argl posl-arg negl-arg andl-arg orl-arg) 
  (progn
    (setq p-result nil)
    (setq primo (first (p-get-arguments argl)))
    (setq secondo (second (p-get-arguments argl)))
    (cond ((or (and (p-isletter primo)
	            (member primo posl-arg :test #'equal)
	       )
	       (and (p-isnot primo)
       	            (member primo negl-arg :test #'equal)
	       )
	       (and (p-isand primo)
		    (member primo andl-arg :test #'equal)
	       )
	       (and (p-isor primo)
		    (member primo orl-arg :test #'equal)
	       )
	   )
	   (setq p-result (s-p-mkTT secondo))
	  )
	  ((or (and (p-isletter secondo)
	            (member secondo negl-arg :test #'equal)
	       )
	       (and (p-isnot secondo)
       	            (member secondo posl-arg :test #'equal)
	       )
	       (and (p-isand secondo)
		    (member secondo orl-arg :test #'equal)
	       )
	       (and (p-isor secondo)
		    (member secondo andl-arg :test #'equal)
	       )
	   )
	   (setq p-result (s-p-mkNT primo))
	  )
    )
    p-result
 )
)
	       
;;--------------------------------------------------------------------------- 
;;
;; 4V-get-reduced-s-prop-from-if (argl posl-arg negl-arg andl-arg orl-arg)
;;
;; input : argl which is a if-formula, other arguments are 
;;         informations on actual state 
;;
;; output: signed TT first argument of if-formula or
;;         signed NT second argument of if-formula or NIL
;;
;;--------------------------------------------------------------------------- 

(defun 4V-get-reduced-s-prop-from-if (argl posl-arg negl-arg andl-arg orl-arg) 
  (progn
    (setq p-result nil)
    (setq primo (first (p-get-arguments argl)))
    (setq secondo (second (p-get-arguments argl)))
    (cond ((or (and (or (p-isletter primo)
			(p-isnot primo)
		     )
	             (member primo posl-arg :test #'equal)
	       )
	       (and (p-isand primo)
		    (member primo andl-arg :test #'equal)
	       )
	       (and (p-isor primo)
		    (member primo orl-arg :test #'equal)
	       )
	   )
	   (setq p-result (s-p-mkTT secondo))
	  )
	  ((or (and (or (p-isletter secondo)
	  		(p-isnot secondo)
		    )
	            (member secondo negl-arg :test #'equal)
	       )
	       (and (p-isand secondo)
		    (member secondo orl-arg :test #'equal)
	       )
	       (and (p-isor secondo)
		    (member secondo andl-arg :test #'equal)
	       )
	   )
	   (setq p-result (s-p-mkNT primo))
	  )
    )
    p-result
 )
)
	     

;;--------------------------------------------------------------------------- 
;;
;; sat-state-info-from-choice
;; (arg-list andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg 
;;  posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)  
;;
;; input : arg-list which is a sub-signed-formula, other arguments are 
;;         informations on previous state 
;;
;; output: information field for new state
;;
;;--------------------------------------------------------------------------- 

(defun sat-state-info-make-from-choice 
  (arg-list andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)  
   (progn 
     (dolist (arg arg-list)        
     	(setq propos (s-p-getpropos arg))
	(cond ((s-p-isTT arg)
		(cond ((or (p-isletter propos)
		           (p-isbot propos)
		       )
		       (pushnew propos posl-arg)
		       (setq posl-modified-arg t)		       
		      )
		      ((p-isnot propos)
		       (pushnew propos not-posl-arg)
		       (setq not-posl-modified-arg t)
		      )
		      ((p-isand propos)
		       (pushnew propos andl-arg)
		      )
		      ((p-isor propos)
		       (pushnew propos orl-arg)
		      )
		      ((p-isif propos)
		       (pushnew propos orl-arg)
		      )
		)
	       )			
	      ((s-p-isNT arg)
	        (cond ((or (p-isletter propos)
		           (p-istop propos)
		       )
		       (pushnew propos negl-arg)
		       (setq negl-modified-arg t)		       
		      )
		      ((p-isnot propos)
		       (pushnew propos not-negl-arg)
		       (setq not-negl-modified-arg t)
		      )
		       ((p-isand propos)
			(pushnew propos orl-arg)
		       )
		       ((p-isor propos)
			(pushnew propos andl-arg)
		       )
		       ((p-isif propos)
		       (pushnew propos andl-arg)
		       )
		 )
	        )
	 )
      )
        (setq result (sat-state-info-make 
                       andl-arg                               ; andl
                       orl-arg                                ; orl
                       posl-arg                               ; posl
                       negl-arg                               ; negl
                       not-posl-arg                           ; not-posl
                       not-negl-arg                           ; not-negl
                       posl-modified-arg                      ; posl-modified
                       negl-modified-arg                      ; negl-modified
                       not-posl-modified-arg                  ; not-posl-modified
                       not-negl-modified-arg                  ; not-negl-modified
                     )
	      )                  
        result
  )
)


;;--------------------------------------------------------------------------- 
;; sat-closed-state (state)
;; Input  : state = a state
;; Return : true iff state is closed
;;          a state is closed whenever either
;;          1. BOT is in posl
;;          2. TOP is in negl
;;          3. there is A in both posl and negl
;;
;;--------------------------------------------------------------------------- 
            
(defun 2V-sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info))
          ; check return condition
          (setq result (2V-sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)))
          (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
) 

;; test for 2V-sat-closed-state 
;;

(defun 2V-sat-closed-state-test (pl nl)
 (or (member BOT pl)  ; false test
     (member TOP nl)  ; true test
     ; check if there is complementary pair
     (some #'(lambda (x) (some #'(lambda (y) (equal x y)) nl)) pl)
 )
)


(defun 4V-sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info)            
              (sat-state-info-not-posl-modified sat-info) 
              (sat-state-info-not-negl-modified sat-info))
            ; check return condition
            (setq result (4V-sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)
                              (sat-state-info-not-posl sat-info)
                              (sat-state-info-not-negl sat-info)))            
            (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
)



;; test for 4V-sat-closed-state 
;;

(defun 4V-sat-closed-state-test (pl nl npl nnl) 
 (or (member BOT pl)  ; false test
     (member TOP nl)  ; true test
     ; check if there is complementary pair
     (some #'(lambda (x) (some #'(lambda (y) (equal x y)) nl)) pl)
     (some #'(lambda (x) (some #'(lambda (y) (equal x y)) nnl)) npl)
 )
) 


;;--------------------------------------------------------------------------- 
;; 2V-sat-get-new-states (state) and 4V-sat-get-new-states (state)
;;
;; warning : this functions are mutually exclusive !
;;
;; Input  : a state
;; Return : list of new states to be solved, generated from current-state
;;          applying the following simple rules. 
;;          Remember that the initial proposition should be in NNF.
;;
;;                T(and A1 ... An)                    
;;         (A)   ---------------------         
;;                T(A1), ... , T(An)                 
;;
;;
;;                 NT(or A1 ... An) 
;;         (A)   ---------------------    
;;                NT(A1), ... , NT(An)
;;     
;;
;;                NT(if A B)
;;         (A)   -------------
;;                T(A),NT(B)    
;;
;;
;;                        T(or A1 A2... An)
;;         (PB)  -------------------------------------           
;;               T(A1)     |    NT(A1), T(or A2 ... An)
;;
;;
;;
;;                        NT(and A1 A2... An)
;;         (PB)  ----------------------------------------           
;;               NT(A1)    |    T(A1), NT(and A2 ... An)
;;
;;
;;                 T(if A B)
;;         (PB)  ------------------------
;;                 NT(A)   |  T(A),T(B)
;;
;;
;;                T(not A)              NT(not A)          ;used only in
;;         (~T)  -----------    (~NT)  ------------        ;two-value logic
;;                NT(A)                  T(A)              ;calculus
;;
;;
;;
;;               T(or A1 ... An)   NT(B1), ... , NT(Bk)    ;where {C1, ..., Cm} 
;;         (B)  -----------------------------------------  ;is the difference set 
;;                        T(or C1 ... Cm)                  ;{A1,...,An} \ I
;;                                                         ; I = intersection between
;;                                                         ;{A1,...,An} and {B1,...,Bk}
;; 
;;
;;               NT(and A1 ... An)   T(B1), ... , T(Bk)    ;where {C1, ..., Cm} 
;;         (B)  -----------------------------------------  ;is the difference set 
;;                        NT(and C1 ... Cm)                ;{A1,...,An} \ I
;;                                                         ; I = intersection between
;;                                                         ;{A1,...,An} and {B1,...,Bk}
;; 
;;
;;               T(if A B), T(A)          T(if A B), NT(B)
;;         (B)  ------------------       -------------------
;;                    NT(A)                     NT(A)
;;
;;
;;
;;
;;          the only branching rule is (PB).
;;          the priority between rules is  [(~T),(~NT)] > (A) > (B) > (PB)
;;
;;--------------------------------------------------------------------------- 
               
;; fast version of 2V-sat-get-new-states (without rules of type B (commented in the code))

(defun 2V-sat-get-new-states (state)
  (progn
    (setq result nil)
    (setq sat-info (sat-state-info state))
    (cond ((or (not (null (sat-state-info-not-posl-modified sat-info)))
	       (not (null (sat-state-info-not-negl-modified sat-info)))
	   )	   
	   (setq result (sat-not-get-new-states state))
	  )
	  ((not (null (sat-state-info-andl sat-info)))
	   (setq result (sat-and-get-new-states state))
	  )
	  ((not (null (sat-state-info-orl sat-info)))
           ;(setq result-tmp (2V-sat-b1b2-get-new-states state)) ; applying rules B1,B2
	   ;(if (null result-tmp)                                ; if not applied B1 or B2 then
	        (setq result (sat-or-get-new-states state))     ; apply PB
	        ;(setq result (list result-tmp))
	   ;)
	  )
	  (t (setq result ()))
	  )
    result
    )
)


(defun 2V-sat-b1b2-get-new-states (state)
  (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-not-posl info-tmp))
    (setq not-negl-tmp  (sat-state-info-not-negl info-tmp))
    (setq posl-modified-tmp nil)
    (setq negl-modified-tmp nil)
    (setq not-posl-modified-tmp nil)
    (setq not-negl-modified-tmp nil)
    (setq argl nil)
    (dolist (arg orl-tmp)
	     (if (p-isif arg)
		 (setq s-p-garbless (2V-get-reduced-s-prop-from-if arg posl-tmp negl-tmp andl-tmp orl-tmp))
	         (setq s-p-garbless (get-reduced-s-prop arg posl-tmp negl-tmp))
	     )
	     (if (not (null s-p-garbless))
		  (progn
		    (setq argl (list s-p-garbless))
		    (setq orl-tmp (remove arg orl-tmp))
		    (return)
		  )
	     )
    )
    (if (not (null argl))
	  (progn 
            (setq sat-state-info-tmp
	              (sat-state-info-make-from-choice
	                               argl
	                               andl-tmp                               ; andl
                                       orl-tmp                                ; orl
 				       posl-tmp                               ; posl
 				       negl-tmp                               ; negl
				       not-posl-tmp                           ; not-posl
				       not-negl-tmp                           ; not-negl
				       posl-modified-tmp                      ; posl-modified
				       negl-modified-tmp                      ; negl-modified
				       not-posl-modified-tmp                  ; not-posl-modified
				       not-negl-modified-tmp                  ; not-negl-modified
	              )
	    )
            (setq result (sat-state-make state sat-state-info-tmp))
	  )
    )
    result
  )
)


(defun 4V-sat-get-new-states (state)
  (progn
    (setq result nil)
    (setq sat-info (sat-state-info state))
    (cond ((not (null (sat-state-info-andl sat-info)))
	   (setq result (sat-and-get-new-states state))
	  )
	  ((not (null (sat-state-info-orl sat-info)))
	   (setq result-tmp (4V-sat-b1b2-get-new-states state))
	   (if (null result-tmp)
	         (setq result (sat-or-get-new-states state))
	         (setq result (list result-tmp))
	   )
	  )
	  (t (setq result ()))
	  )
    result
    )
)


(defun 4V-sat-b1b2-get-new-states (state)
  (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))
    (setq orl-tmp   (sat-state-info-orl  info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq posl-modified-tmp  nil)
    (setq negl-modified-tmp  nil)
    (setq argl nil)
    (dolist (arg orl-tmp)
	     (if (p-isif arg)
		 (setq s-p-garbless (4V-get-reduced-s-prop-from-if arg posl-tmp negl-tmp andl-tmp orl-tmp))
	         (setq s-p-garbless (get-reduced-s-prop arg posl-tmp negl-tmp))
	     )
	     (if (not (null s-p-garbless))
		  (progn
		    (setq argl (list s-p-garbless))
		    (setq orl-tmp (remove arg orl-tmp))
		    (return)
		  )
	     )
    )
    (if (not (null argl))
	  (progn 
            (setq sat-state-info-tmp
	    (sat-state-info-make-from-choice
	        argl
	        andl-tmp
	        orl-tmp
	        posl-tmp
	        negl-tmp
	        posl-modified-tmp
	        negl-modified-tmp)
	    )
            (setq result (sat-state-make state sat-state-info-tmp))
	  )
    )
    result
  )
)



(defun sat-not-get-new-states (state)
  (progn      
      (setq result nil)
      (setq info-tmp  (sat-state-info state))
      (setq andl-tmp  (sat-state-info-andl info-tmp))   
      (setq orl-tmp   (sat-state-info-orl info-tmp))
      (setq posl-tmp  (sat-state-info-posl info-tmp))
      (setq negl-tmp  (sat-state-info-negl info-tmp))
      (setq not-posl-tmp  (sat-state-info-not-posl info-tmp))
      (setq not-negl-tmp  (sat-state-info-not-negl info-tmp))
      (setq posl-modified-tmp nil)
      (setq negl-modified-tmp nil)
      (setq not-posl-modified-tmp nil)
      (setq not-negl-modified-tmp nil)               
      (dolist (p-arg not-posl-tmp 
                     (if (not (null not-posl-tmp))
                           (progn
                              (setq negl-modified-tmp t)
                              (setq not-posl-tmp ())
                            )
                      )
                                  
               )	   
	       (pushnew (p-get-argument p-arg) negl-tmp)	           	
      )
      (dolist (p-arg not-negl-tmp 
                     (if (not (null not-negl-tmp))
                           (progn
                              (setq posl-modified-tmp t)
                              (setq not-negl-tmp ())
                            )
                      )
                                  
               )	   
	       (pushnew (p-get-argument p-arg) posl-tmp)	           	
      )   	      	       
      (setq sat-state-info-tmp
	  (sat-state-info-make
	          andl-tmp                               ; andl
                  orl-tmp                                ; orl
                  posl-tmp                               ; posl
                  negl-tmp                               ; negl
                  not-posl-tmp                           ; not-posl
                  not-negl-tmp                           ; not-negl
                  posl-modified-tmp                      ; posl-modified
                  negl-modified-tmp                      ; negl-modified
                  not-posl-modified-tmp                  ; not-posl-modified
                  not-negl-modified-tmp                  ; not-negl-modified
	  )
      )
      (setq result (sat-state-make state sat-state-info-tmp))
      (list result)
   )
 )


(defun sat-and-get-new-states (state)
  (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-not-posl info-tmp))
    (setq not-negl-tmp  (sat-state-info-not-negl info-tmp))
    (setq posl-modified-tmp nil)
    (setq negl-modified-tmp nil)
    (setq not-posl-modified-tmp nil)
    (setq not-negl-modified-tmp nil)
    (setq and-args ())
    (dolist (arg andl-tmp (setq andl-tmp ()))        
        (cond ((p-isand arg)
	       (setq and-args (concatenate 'list and-args (make-TT-p-list (p-get-arguments arg))))
	      )
	      ((p-isor arg)
               (setq and-args (concatenate 'list and-args (make-NT-p-list (p-get-arguments arg))))
	      )
	      ((p-isif arg)
	       (setq primo (s-p-mkTT (first (p-get-arguments arg))))
	       (setq resto (s-p-mkNT (second (p-get-arguments arg)))) 
	       (setq and-args (concatenate 'list and-args (list primo resto)))
	      )
         )
    )
    (setq sat-state-info-tmp
	  (sat-state-info-make-from-choice
	   and-args
	   andl-tmp                               ; andl
           orl-tmp                                ; orl
           posl-tmp                               ; posl
           negl-tmp                               ; negl
           not-posl-tmp                           ; not-posl
           not-negl-tmp                           ; not-negl
           posl-modified-tmp                      ; posl-modified
           negl-modified-tmp                      ; negl-modified
           not-posl-modified-tmp                  ; not-posl-modified
           not-negl-modified-tmp                  ; not-negl-modified
	  )
    )
    (setq result (sat-state-make state sat-state-info-tmp))
    (list result)
    )
  )



(defun sat-or-get-new-states (state)
 (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-not-posl info-tmp))
    (setq not-negl-tmp  (sat-state-info-not-negl info-tmp))
    (setq posl-modified-tmp nil)
    (setq negl-modified-tmp nil)
    (setq not-posl-modified-tmp nil)
    (setq not-negl-modified-tmp nil)       
    (setq p (first orl-tmp))
    (setq orl-tmp (rest orl-tmp))
    (cond ((p-isor p)
              (progn
	         (setq primo (first (p-get-arguments p)))
	         (setq resto (rest (p-get-arguments p)))
	         (setq arg (s-p-mkTT primo))
	         (setq notA1 (s-p-mkNT primo))
	         (setq orA (p-mkor (push BOT resto)))   
                 (setq orA (p-simplify orA))   
	         (setq orA1 (s-p-mkTT orA))
	       )
	   )
	   ((p-isand p)
	       (progn
	          (setq primo (first (p-get-arguments p)))
	          (setq resto (rest (p-get-arguments p)))
	          (setq arg (s-p-mkNT primo))
	          (setq notA1 (s-p-mkTT primo))
	          (setq orA (p-mkand (push TOP resto)))   
                  (setq orA (p-simplify orA))	    
	          (setq orA1 (s-p-mkNT orA))
	       )
	   )
	   ((p-isif p)
	       (progn
	          (setq primo (first (p-get-arguments p)))
	          (setq resto (second (p-get-arguments p)))
	          (setq arg (s-p-mkNT primo))
	          (setq notA1 (s-p-mkTT primo))
	          (setq orA1 (s-p-mkTT resto))
	       )
	   )
      )
      (setq sat-state-info-tmp1
            (sat-state-info-make-from-choice
                (list arg) 
                andl-tmp                               ; andl
                orl-tmp                                ; orl
	        posl-tmp                               ; posl
        	negl-tmp                               ; negl
	        not-posl-tmp                           ; not-posl
        	not-negl-tmp                           ; not-negl
	        posl-modified-tmp                      ; posl-modified
                negl-modified-tmp                      ; negl-modified
                not-posl-modified-tmp                  ; not-posl-modified
                not-negl-modified-tmp                  ; not-negl-modified                    
            )
      )
      (setq sat-state-info-tmp2
            (sat-state-info-make-from-choice
                (list notA1 orA1) 
                andl-tmp                               ; andl
                orl-tmp                                ; orl
                posl-tmp                               ; posl
                negl-tmp                               ; negl
                not-posl-tmp                           ; not-posl
                not-negl-tmp                           ; not-negl
                posl-modified-tmp                      ; posl-modified
                negl-modified-tmp                      ; negl-modified
                not-posl-modified-tmp                  ; not-posl-modified
                not-negl-modified-tmp                  ; not-negl-modified                    
            )
      )
      (setq newstate1 (sat-state-make state sat-state-info-tmp1))
      (setq newstate2 (sat-state-make state sat-state-info-tmp2))
      (list newstate1 newstate2) 
 )
)




;;--------------------------------------------------------------------------- 
;; sat-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun sat-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (or (null lopen-states)   ; no more states to be processed
                       (not (null lcompleted-states))))   ; there is a not closed completed branch
      result
 )
)  

;;--------------------------------------------------------------------------- 
;; sat-get-result (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a succesful search
;;--------------------------------------------------------------------------- 

(defun sat-get-result (lopen-states lclosed-states lcompleted-states)
 (progn
      ;; return true if there is a not closed and completed state S, i.e. 
      ;; S encodes a model 
      ;; 
      (setq result (not (null lcompleted-states)))
      result
 )
)

;;--------------------------------------------------------------------------- 
;; model-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun model-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (null lopen-states)) ; no more states to be processed
      result
 )
)  


;;--------------------------------------------------------------------------- 
;; sat-build-models (lcompleted-states)
;; Input  :  lists of completed states
;; Return : list of Herbrand models
;;--------------------------------------------------------------------------- 

(defun sat-build-models (lcompleted-states)
 (progn
      (cond ((null lcompleted-states) nil)
            (t (cons (sat-state-info-posl (sat-state-info (first lcompleted-states)))
                     (sat-build-models (rest lcompleted-states)))
            )     
      
      )
 )
)
;;---------------------------------------------------------------------------


