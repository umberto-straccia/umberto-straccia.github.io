;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% April, 1st 1998                                                         %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;-----------------------------------------------------------------------------
; Begin of definitions added by Antonio Lopreiato
;-----------------------------------------------------------------------------

;; (defvar set-calculus 2)
;; use set-calculus variable to set type of calculus
;; which can be two-valued (default) or four-valued

(defvar set-calculus 2)

;;--------------------------------------------------------------------------- 
;; p-sat-exec (p-list)
;; Input: list of  propositions, i.e. a KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	              6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT s-p-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun p-sat-exec (p-list)
   (progn
        (setq s-p-list (make-TT-p-list p-list))
        (s-p-sat-exec s-p-list)
   )
)


;;--------------------------------------------------------------------------- 
;; p-all-models-exec (p-list)
;; Input: list of  propositions, i.e. a KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT sp-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun p-all-models-exec (p-list)
   (progn
        (setq s-p-list (make-TT-p-list p-list))
        (s-p-all-models-exec s-p-list)
   )
)


;;--------------------------------------------------------------------------- 
;; p-state-solver (p-list 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of propositions, i.e. a KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun p-state-solver (p-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
   (progn
        (setq s-p-list (make-TT-p-list p-list))
        (s-p-state-solver s-p-list 
                          get-new-states-fn
                          closed-state-fn
                          termination-fn
                          get-result-fn)
   )
)


;;--------------------------------------------------------------------------- 
;; s-p-sat-exec (s-p-list)
;; Input: list of signed propositions, i.e. a KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	          6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT s-p-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun s-p-sat-exec (s-p-list)
   (if (equal set-calculus 2)
          (s-p-state-solver s-p-list                    ; initial state
                              #'2V-sat-get-new-states   ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (s-p-state-solver s-p-list                    ; initial state
                              #'4V-sat-get-new-states   ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)


;;--------------------------------------------------------------------------- 
;; s-p-all-models-exec (sp-list)
;; Input: list of signed  propositions, i.e. a KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT sp-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun s-p-all-models-exec (s-p-list)
   (if (equal set-calculus 2)
          (s-p-state-solver s-p-list                    ; initial state
                              #'2V-sat-get-new-states   ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (s-p-state-solver s-p-list                    ; initial state
                              #'4V-sat-get-new-states   ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)


;;--------------------------------------------------------------------------- 
;; s-p-state-solver (s-p-list 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of signed propositions, i.e. a KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun s-p-state-solver (s-p-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       ;(setq s-p-list (mapcar #'s-p-simplify-iff s-p-list))  ; replace IF and IFF
       (setq s-p-list (mapcar #'s-p-simplify s-p-list))  ; reduce every proposition in p-list in NNF
       ; build first state, the case of multiple initial states is similar
       (setq newstate (sat-initial-state-make s-p-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver (list newstate)        ; initial state
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

