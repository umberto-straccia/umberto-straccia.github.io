;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% April, 1st 1998                                                         %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This file contains the function in order to execute about sat problems

;;--------------------------------------------------------------------------- 
;; p-sat (p)
;; Input: proposition 
;; Return: result = true if SAT p
;;--------------------------------------------------------------------------- 


(defun p-sat (p) 
    (s-p-sat (s-p-mkTT p))
)


;;--------------------------------------------------------------------------- 
;; p-sat-KB (p-list)
;; Input: list of propositions, i.e. a KB 
;; Return: result = true if SAT p-list
;;--------------------------------------------------------------------------- 

(defun p-sat-KB (p-list) 
     (s-p-sat-KB (make-TT-p-list p-list))
)


;;--------------------------------------------------------------------------- 
;; p-logically-implies (kb p)
;; Input: kb = list of propositions, i.e. a KB 
;;        p  = a proposition
;; Return: result = true if KB |= p
;;--------------------------------------------------------------------------- 

(defun p-logically-implies (kb p)
   (s-p-logically-implies (make-TT-p-list kb) (s-p-mkTT p))
)


;;--------------------------------------------------------------------------- 
;; p-tautology (p)
;; Input: p  = a proposition
;; Return: result = true if |= p
;;--------------------------------------------------------------------------- 

(defun p-tautology (p)
  (s-p-tautology (s-p-mkTT p))
)


;;--------------------------------------------------------------------------- 
;; p-get-a-model (p)
;; Input: proposition 
;; Return: a list of letters = a Herbrand model of p, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-get-a-model (p) 
   (s-p-get-a-model (s-p-mkTT p))
)


;;--------------------------------------------------------------------------- 
;; p-KB-get-a-model (p-list)
;; Input: a list of propositions 
;; Return: a list of letters = a Herbrand model of p-list, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-KB-get-a-model (p-list)
  (s-p-KB-get-a-model (make-TT-p-list p-list))
)


;;--------------------------------------------------------------------------- 
;; p-get-all-models (p)
;; Input: proposition 
;; Return: a list of letters = a Herbrand model of p, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-get-all-models (p) 
  (s-p-get-all-models (s-p-mkTT p)) 
)


;;--------------------------------------------------------------------------- 
;; p-KB-get-all-models (p-list)
;; Input: a list of propositions 
;; Return: a list of letters = a Herbrand model of p-list, nil otherwise
;;--------------------------------------------------------------------------- 


(defun p-KB-get-all-models (p-list) 
   (s-p-KB-get-all-models (make-TT-p-list p-list))
)


;----------------------------------------------------------------------------
; Begin of definitions added by Antonio Lopreiato
;----------------------------------------------------------------------------


;;--------------------------------------------------------------------------- 
;; s-p-sat (s-p)
;; Input: a signed proposition 
;; Return: result = true if SAT s-p
;;
;; aggiunta
;;--------------------------------------------------------------------------- 

(defun s-p-sat (s-p) 
 (progn
       (setq result (s-p-sat-exec (list s-p)))
       (second result) ;; return result
 )
)


;;--------------------------------------------------------------------------- 
;; s-p-sat-KB (s-p-list)
;; Input: list of signed propositions, i.e. a KB 
;; Return: result = true if SAT s-p-list
;;
;;  aggiunta
;;--------------------------------------------------------------------------- 

(defun s-p-sat-KB (s-p-list) 
 (progn
       (setq result (s-p-sat-exec s-p-list))
       (second result) ;; return result
 )
)


;;--------------------------------------------------------------------------- 
;; s-p-logically-implies (s-kb s-p)
;; Input: s-kb = list of signed propositions, i.e. a KB 
;;        s-p  = a signed proposition
;; Return: result = true if s-KB |= s-p
;;
;;  aggiunta
;;--------------------------------------------------------------------------- 

(defun s-p-logically-implies (s-kb s-p)
 (progn
   (setq p (s-p-getpropos s-p))
   (if (s-p-isTT s-p) 
         (not (s-p-sat-KB (append (list (s-p-mkNT p)) s-kb)))
         (not (s-p-sat-KB (append (list (s-p-mkTT p)) s-kb)))
   )
 )
)


;;--------------------------------------------------------------------------- 
;; s-p-tautology (s-p)
;; Input: s-p  = a signed proposition
;; Return: result = true if |= s-p
;;
;;  aggiunta
;;--------------------------------------------------------------------------- 

(defun s-p-tautology (s-p)
  (progn
    (setq p (s-p-getpropos s-p))
    (if (s-p-isTT s-p)
	  (not (s-p-sat (s-p-mkNT p)))
          (not (s-p-sat (s-p-mkTT p)))
    )
  )
)

;;--------------------------------------------------------------------------- 
;; s-p-get-a-model (s-p)
;; Input: a signed proposition 
;; Return: a list of letters = a Herbrand model of s-p, nil otherwise
;;---------------------------------------------------------------------------
 
(defun s-p-get-a-model (s-p) 
 (progn
       (setq result (s-p-sat-exec (list s-p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; s-p-KB-get-a-model (s-p-list)
;; Input: a list of signed propositions 
;; Return: a list of letters = a Herbrand model of s-p-list, nil otherwise
;;--------------------------------------------------------------------------- 

(defun s-p-KB-get-a-model (s-p-list) 
 (progn
       (setq result (s-p-sat-exec s-p-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; s-p-get-all-models (s-p)
;; Input: a signed proposition 
;; Return: a list of letters = a Herbrand model of s-p, nil otherwise
;;--------------------------------------------------------------------------- 

(defun s-p-get-all-models (s-p) 
 (progn
       (setq result (s-p-all-models-exec (list s-p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; s-p-KB-get-all-models (s-p-list)
;; Input: a list of signed propositions 
;; Return: a list of letters = a Herbrand model of s-p-list, nil otherwise
;;--------------------------------------------------------------------------- 

(defun s-p-KB-get-all-models (s-p-list) 
 (progn
       (setq result (s-p-all-models-exec s-p-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;---------------------------------------------------------------------------
