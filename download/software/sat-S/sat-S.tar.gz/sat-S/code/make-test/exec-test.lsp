;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Executes test                                                           %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; execute test with
;; (exec-test 100 4 120 4 4) 
; (exec-test 3 4 8 4 4) ; test

;;--------------------------------------------------------------------------- 
;; exec-test (samples-per-point num-cl-start num-cl-end step nvar)
;; Input: 
;;       samples-per-point            ;; number of samples/point
;;       num-cl-start                 ;; number of clauses : start
;;       num-cl-end                   ;; number of clauses : end
;;       step                         ;; number of clauses : step
;;       nvar                         ;; number of variables
;;
;; Return: prints in *wff-file* the test propositions
;;         prints in *result-file* the test results, in he form
;;         <sat-value> <number-of-states> <time>
;;
;;         where <sat-value> is S (satisfiable), U (not satisfiable)
;;               <number-of-states> is the number of states created
;;               <time> is the time required
;;
;;---------------------------------------------------------------------------



(defun exec-test (samples-per-point num-cl-start num-cl-end step nvar)
 (progn
   (setq *var_num* nvar)
   (setq *result-stream* (open *result-file* :direction :output))
   (setq *wff-stream* (open *wff-file* :direction :output))
   (print-header samples-per-point num-cl-start num-cl-end step)
   (do ((n_cl num-cl-start (+ n_cl step))) ; for each number of clauses
       ((>= n_cl (+ step num-cl-end)))
       (print-clauses-num n_cl)
       (setq *and_br* n_cl)   ; new number of and operants 
       (do ((j 0 (+ j 1))) 
           ((= j samples-per-point))
           (generate_and_test)
       )
   )
   (close  *result-stream*) 
   (close  *wff-stream*) 
 )
)


(defun generate_and_test ()
 (let ((p (get-3sat-random-proposition)))
  (progn
   (print-wff p)
   (if *execute_test* 
      (if (null *timeout*)
          (test_sat p)
          (bounded_test_sat p)
      )
   )
  )
 )
)


(defun test_sat (p) 
 (progn
  (setq *number-of-states* 0)
  (gc t)                    ; GARBAGE COLLECTING
  (setq t1 (get-internal-run-time))
  (setq result (p-sat-exec (list p)))
  (setq t2 (get-internal-run-time))
  (setq deltat (float (/ (- t2 t1) 
                         internal-time-units-per-second
                      )
               )
  )
  (print-sat result deltat)
  )
)

;-------------------------------------------------------------------------------------------
; Begin of definitions added by Antonio Lopreiato
;-------------------------------------------------------------------------------------------
    
;-------------------------------------------------------------------------------------------
;
; KB-sat-exec-test 
;  (KB-samples KB-p-start KB-p-end KB-p-step Lp-start Lp-end Lp-step query-start query-end 
;     query-step num-var p sigma-KB sigma-f lengths-array-constr bin)
;     
; input : test parameters :
;               KB-samples    ;means the sample of KB's on which you test
;               KB-p-start    ;  "   initial number of propositions in KB
;               KB-p-end      ;  "   final number of propositions in KB
;               KB-step       ;  "   # of added propositions at any step
;               Lp-start      ;  "   initial length of proposition generated
;               Lp-end        ;  "   final length of proposition generated
;               Lp-step       ;  "   length increment
;               query-start   ;  "   initial length of queries 
;               query-end     ;  "   final length of queries
;               query-step    ;  "   increment of query's length 
;               num-var       ;  "   number of propositional variables
;               p             ;  "   probality used in distribution functions
;               sigma-KB      ; is the distribution function for the number of proposition on KB
;               sigma-f       ; is the distribution function for the lenght of proposition
;        lengths-array-constr ; is the function for building lengths proposition's array
;               bin           ; boolean : T if you are using binomial distribution, NIL otherwise
;
; output: prints test results on *result-file* and KB-formulas on *wff-file*  
; 
; require loading of tartaglia.lsp file when you use binomial distribution
;-------------------------------------------------------------------------------------------

(defun KB-exec-test 
  (KB-samples KB-p-start KB-p-end KB-p-step Lp-start Lp-end Lp-step query-start query-end 
     query-step num-var p sigma-KB sigma-f lengths-array-constr bin)
    (progn
      (setq num-iter-KB (+ 1 (/ (- KB-p-end KB-p-start) KB-p-step)))  
      (setq num-iter-len (+ 1 (/ (- Lp-end Lp-start) Lp-step)))	
      (setq *var_num* num-var)  ; sets number of variables for KB propoositions
      ; sets number of variables for queries
      (setq *query_var_num* (floor (/ *var_num* *var_query_in_KB_prob*)))
      (setq *result-stream* (open *result-file* :direction :output))
      (setq *wff-stream* (open *wff-file* :direction :output))
      (KB-print-header KB-samples KB-p-start KB-p-end KB-p-step Lp-start Lp-end Lp-step p) ; prints the header
      (query-print-header query-start query-end query-step *query_var_num*)
      (do ((i 1 (+ i 1)))      ; for each KB
	  ((> i num-iter-KB))
	  (setq LKB (funcall sigma-KB i KB-p-start KB-p-step))  ; computes the number of formulas into KB
	  (KB-print-dim LKB)
	  (do ((j 1 (+ j 1)))   ; for each length considered 
	      ((> j num-iter-len))
	      (setq Lv (funcall lengths-array-constr j Lp-start Lp-end Lp-step)) ; builts array of lengths	   
	      (if (not (null Lv))
	        (progn
                  (setq Lv-limit (- (array-dimension Lv 0) 1))
                  (print-KB-info sigma-f Lv lv-limit LKB Lp-start Lp-end Lp-step p)
                  (if (and (>= Lv-limit 40) bin) (make-Tartaglia (+ Lv-limit 1))) 
	          (do ((k 1 (+ k 1)))   ; KB sampling
		      ((> k KB-samples))
		      (setq KB ())
		      (do ((m 0 (+ m 1)))  
		          ((> m Lv-limit))
		          (setq num-prop (funcall sigma-f m Lv-limit LKB Lp-start Lp-end Lp-step p))   
		          (setq Lp (svref Lv m))
		          (do ((n 1 (+ n 1)))
		    	      ((> n num-prop))
		   	      (setq KB (append KB (list (gen-rand-s-prop Lp))))  ; KB construction
		          )
		      )   
		      (if bin (fill-KB LKB (length KB) Lv p)) 		   		                     		                     		          
		      ;executes test and prints results
		      (if (= (- query-end query-start) 0)
		          (progn
		             (KB-print KB)      ;prints KB propositions in *wff-stream*  
		             (test_sat_KB KB)   ; test with no query on KB 
		           )		      
		          (do ((ql query-start (+ ql query-step)))  ; test with query on KB 
		              ((> ql query-end))
		              (setq KB&Q (append KB (list (gen-rand-query ql)))) 
		              (KB-print KB&Q)     ;prints KB propositions in *wff-stream*
        	              (test_sat_KB KB&Q)  ; test with one query on KB
		          ) 
		       )
		   )
	        ) 
	      ) 
          )
      )
      (close  *result-stream*) 
      (close  *wff-stream*)
   )
)


;--------------------------------------------------------------------------
; fill-KB (lkb p-in Lv p)
;
; input : number of propositions which must be builted, lkb
;         number of propositions builted so far, p-in
;         the vector of lengths, Lv
;         probality used in distribution function, p
;
; output: the KB filled with propositions missing 
;
;--------------------------------------------------------------------------


(defun fill-KB (lkb p-in Lv p)
  (progn
    (setq missing-f (- lkb p-in))
    (setq Lv-dim (array-dimension Lv 0))
    (if (not (zerop missing-f))
	(progn
	   (cond ((<= p 0.3)
	          (setq index 0)
                 )
	         ((< p 0.7)  ;remember that p > 0.3 holds here
	          (setq index (floor (/ (- Lv-dim missing-f) 2)))
	         )
	         (t (setq index (- Lv-dim missing-f)))  ;remember that p >= 0.7 holds here
           )
	   (do ((n 0 (+ n 1)))
	       ((> n (- missing-f 1)))
	       (setq lp (svref Lv (+ index n)))
	       (setq KB (append KB (list (gen-rand-s-prop Lp))))
	   )
	)
    )
  )
)


;--------------------------------------------------------------------------
;
; test_sat_KB (p-list)
;
; execute SAT on a KB and captures initial and final times
;
;--------------------------------------------------------------------------
	
(defun test_sat_KB (s-p-list) 
 (progn
  (setq *number-of-states* 0)
  (gc t)                    ; GARBAGE COLLECTING
  (setq t1 (get-internal-run-time))
  (setq result (s-p-sat-exec s-p-list))
  (setq t2 (get-internal-run-time))
  (setq deltat (float (/ (- t2 t1) 
                         internal-time-units-per-second
                      )
               )
  )
  (KB-3sat-print result deltat)
  )
)

;------------------------------------------------------------------------




