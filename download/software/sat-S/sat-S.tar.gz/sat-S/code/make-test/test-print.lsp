;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% print functions for test                                                %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; prints the header
(defun print-header (samples-per-point num-cl-start num-cl-end step)
 (princ
  (format nil 
   "#Cl-start ~10A ~
   #Cl-end ~9A ~
   #Cl-step ~3A ~
   #Samples/point: ~4A ~
   #Var ~3A ~
   Random-seed ~%"
   "" "" "" "" "" "")
   *result-stream*)
 (princ
      (format nil 
              "~22A ~
              ~18A ~
              ~14A ~
              ~16A ~
              ~6A ~
              ~A ~%"
              num-cl-start 
              num-cl-end 
              step
              samples-per-point  
              *var_num*
              *random-state*)
      *result-stream*)
 (princ 
   (format nil 
   "<Sat result> ~3A ~
   <Number of States> ~3A ~
   <Time> ~3A ~%"
    "" 
    ""  
    "")
  *result-stream*)
)
 
(defun print-clauses-num (i) 
 (princ
  (format nil "#Clauses: ~D ~%" i)
  *result-stream*)
)  
 
;; print the proposition p
 
(defun print-wff (p)
 (print p *wff-stream*)
)


(defun print-sat (result deltat)
 (progn
   (setq number-of-states (first result))
   (setq sat (second result))
   (if sat
       (setq val "S")
       (setq val "U")
   )
   (princ
      (format nil 
              "~10A ~
              ~14D ~
              ~19,2F ~%"
              val
              number-of-states
              deltat)
      *result-stream*)
  )
)

;-----------------------------------------------------------------------
; Begin of definitions added by Antonio Lopreiato
;-----------------------------------------------------------------------

(defun KB-print-header
  (KB-samples KB-p-start KB-p-end KB-step Lp-start Lp-end Lp-step prob) 
 (princ
  (format nil 
   "#KB-p-start ~1A ~
   #KB-p-end ~1A ~
   #KB-step ~1A ~
   #KB-samples ~1A ~
   Lp-start ~1A ~
   Lp-end ~1A ~
   Lp-step ~1A ~
   prob ~1A ~
   #num-var ~1A ~
   Random-seed ~%"
   "" "" "" "" "" "" "" "" "" "")
   *result-stream*)
   (princ
      (format nil 
              "~4A ~
              ~11A ~
              ~11A ~
              ~12A ~
              ~12A ~
              ~8A ~
              ~9A ~
              ~6A ~
              ~9A ~
              ~7A ~
              ~A ~%"
              ""
              KB-p-start 
              KB-p-end 
              KB-step
              KB-samples  
              Lp-start 
              Lp-end 
              Lp-step
              prob
              *var_num*
              *random-state*)
      *result-stream*)
)

; prints parameters for query in the header

(defun query-print-header
  (query-start query-end query-step query-num-var) 
 (princ
  (format nil 
   "#query-len-start ~6A ~
   #query-len-end ~6A ~
   #query-len-step ~6A ~
   #query-num-var ~6A ~%"
   "" "" "" "")
   *result-stream*)
   (princ
      (format nil 
              "~7A ~
              ~21A ~
              ~22A ~
              ~22A ~
              ~12A ~%"
              ""
              query-start 
              query-end 
              query-step
              query-num-var)
      *result-stream*)
 (princ 
   (format nil 
   "<Sat result> ~3A ~
   <Number of States> ~3A ~
   <Time> ~3A ~%"
    "" 
    ""  
    "")
  *result-stream*)
)

;------------------------------------------------------------------------------------
; print-KB-info (sigma-f Lv lv-dim lkb Lp-start Lp-end Lp-step prob)
;
; input : the distribution function for formulas, sigma-f
;         the vector of lengths, Lv and its size, lv-dim
;         the total number of propositions into KB
;         initial length of propositions generated, Lp-start
;         final length of propositions generated, Lp-end
;         length increment, Lp-step
;         probality used in distribution function, prob         
;
; output: prints the lists of lengths and corresponding number of
;         proposition in the *result-stream*
;------------------------------------------------------------------------------------
 
(defun print-KB-info (sigma-f Lv lv-dim lkb Lp-start Lp-end Lp-step prob)
   (progn
      (setq n-prop 0)
      (setq plist ())
      (setq llist ())
      (do ((i 0 (+ i 1)))
      	   ((> i lv-dim))
      	   (setq llist (append llist (list (svref Lv i))))
      	   (setq p-n (funcall sigma-f i lv-dim lkb Lp-start Lp-end Lp-step prob))
      	   (setq plist (append plist (list p-n)))
      	   (setq n-prop (+ n-prop p-n))
      )
      (if (< n-prop lkb)
          (progn
             (setq missing-f (- lkb n-prop))
             (cond ((<= prob 0.3)
                    (setq index 0)
                   )
                   ((< prob 0.7)  ;remember that p > 0.3 holds here
	             (setq index (floor (/ (- Lv-dim missing-f) 2)))
	            )
	            (t (setq index (- Lv-dim missing-f)))  ;remember that p >= 0.7 holds here
              )
              (do ((n 0 (+ n 1)))
	          ((> n (- missing-f 1)))	
                  (setf (nth (+ index n) plist) (+ (nth (+ index n) plist) 1))
              ) 
            )
        )
       (princ (format nil "Lenghts     : ~A ~%" llist) *result-stream*)
       (princ (format nil "Propositions: ~A ~%" plist) *result-stream*)
     )
 )
 
(defun KB-print-dim (d)
  (princ 
    (format nil "#KB-Propositions: ~D ~%" d)
    *result-stream*
  )
)

(defun KB-print (kb-list)
   (print kb-list *wff-stream*)
)


(defun KB-3sat-print (result deltat)
 (progn
   (setq number-of-states (first result))
   (setq sat (second result))
   (if sat
       (setq val "S")
       (setq val "U")
   )
   (princ
      (format nil 
              "~10A ~
              ~14D ~
              ~19,2F ~%"
              val
              number-of-states
              deltat)
      *result-stream*)
  )
)

;------------------------------------------------------

