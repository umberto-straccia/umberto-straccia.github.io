;--------------------------------------------------------------------------
; sigmaKB (i init step)
; input : iteration, i
;         init number of propositions, init
;         increment of number of proposition at any iteration, step
; output: init+i*step
;--------------------------------------------------------------------------

(defun sigmaKB (i init step)
 (+ init (* (- i 1) step))  ; returns init+i*step
)

;--------------------------------------------------------------------------
; len-array-constr (j Lp-start Lp-end Lp-step)
;
; input: iteration, j
;        initial length of proposition generated, Lp-start
;        final length of proposition generated, Lp-end
;        length increment, Lp-step
;
; output: a vector of integers or NIL
;
;--------------------------------------------------------------------------

; version 0
(defun len-array-constr (j Lp-start Lp-end Lp-step)
  (if (equal j 1)
      (progn
         (setq dim (+ 1 (/ (- Lp-end Lp-start) Lp-step)))
         (make-array dim 
  	             :initial-contents 
  	              (do ((i 0 (+ i 1)) (seq ())) 
       	                  ((>= i dim) seq) 
  		          (setq seq (append seq `(,(+ Lp-start (* i Lp-step)))))
  	              )
         )
       )
       NIL
   )
)

; version 1
(defun len-array-constr-1 (j Lp-init Lp-end Lp-step)
  ;Lp-end parameter not used here
  (vector (+ Lp-init (* (- j 1) Lp-step)))
)

;--------------------------------------------------------------------------

;--------------------------------------------------------------------------
; sigmaf (k n lkb Lp-start Lp-end Lp-step prob)
;
; input : index of Lv, the vector of lengths, k
;         size of Lv, n
;         number of propositions which must be builted, lkb
;         initial length of proposition generated, Lp-start
;         final length of proposition generated, Lp-end
;         length increment, Lp-step
;         probality used in distribution function, prob
;
; output: an integer representing the number of propositions
;         to be builted for a given length
;   
;--------------------------------------------------------------------------

;to be used along with version 0 of lengths-array-constr and fill-KB function 
(defun sigmaf (k n lkb Lp-start Lp-end Lp-step prob)
  (progn
    (setq bin-coeff (get-n-k *tr_tar* (+ n 1) k))
    (setq first-t (expt prob k))
    (setq second-t (expt (- 1 prob) (- (+ n 1) k)))
    (floor (* lkb bin-coeff first-t second-t))
  )
)

; to be used along with version 0 of lengths-array-constr
(defun sigmaf1 (k n lkb Lp-start Lp-end Lp-step prob)
  ;k,prob parameters not used here
  (setq lgths (+ 1 (/ (- Lp-end Lp-start) Lp-step)))
  (/ lkb lgths)
)

; to be used along with version 1 of lengths-array-constr
(defun sigmaf2 (k n lkb Lp-start Lp-end Lp-step prob)
  ;Lp-start,Lp-end,Lp-step,k,prob parameters not used here
  lkb
)

;--------------------------------------------------------------------------
