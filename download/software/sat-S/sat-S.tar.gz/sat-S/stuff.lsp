;-------------------------------------------------------------------------------------------
;
; KB-sat-exec-test (KB-samples KB-p-start KB-p-end KB-step Lp-start Lp-end Lp-step num-var)
;
; input : test parameters :
;               KB-samples    ;means the sample on which you test
;               KB-p-start    ;  "   initial number of propositions in KB
;               KB-p-end      ;  "   final number of propositions in KB
;               KB-step       ;  "   # of added propositions at any step
;               Lp-start      ;  "   initial length of proposition generated
;               Lp-end        ;  "   final length of proposition generated
;               Lp-step       ;  "   length increment
;               num-var       ;  "   number of propositional variables
;
; output: prints test results on *result-file* and KB-formulas on *wff-file*  
; 
; Warning :
; if you test for KB containing variable-length formulas, you need to set
; parameters prefixed with "KB-" (excepting KB-samples) as multiples of 
; number 1+(Lp-end-Lp-start)/Lp-step.Otherwise, you are executing a test
; for KB containing fixed-length formulas and you need to set Lp-start 
; equal to Lp-end. 
;
;-------------------------------------------------------------------------------------------


(defun KB-exec-test
  (KB-samples KB-p-start KB-p-end KB-step Lp-start Lp-end Lp-step num-var)
  (progn
     (setq *var_num* num-var)
     (setq *result-stream* (open *result-file* :direction :output))
     (setq *wff-stream* (open *wff-file* :direction :output))
     (KB-print-header KB-samples KB-p-start KB-p-end KB-step Lp-start Lp-end Lp-step)
     (do ((num-prop KB-p-start (+ num-prop KB-step)))
	((>= num-prop (+ KB-p-end KB-step)))
	(KB-print-dim num-prop)	 
	(setq prop-per-length (/ num-prop (+ (/ (- Lp-end Lp-start) Lp-step) 1)))
	(do ((kb-num 1 (+ kb-num 1)))
	    ((>= kb-num (+ KB-samples 1)))
	    (setq KB ())
	    ;generates random KB
            (do ((len-prop Lp-start (+ len-prop Lp-step)))
	        ((>= len-prop (+ Lp-end Lp-step)))
	        ;(print-p-length len-prop)
                (do ((j 1 (+ j 1)))
		    ((>= j (+ prop-per-length 1)))
	            (setq KB (append KB (gen-rand-s-prop len-prop)))  ;generates random KB
                )
            )
            (KB-print KB)       ;prints KB propositions
            (test_sat_KB KB)    ;executes test and prints results
	)
     )
     (close  *result-stream*) 
     (close  *wff-stream*)
  )
)

;;-------------------- Versione funzionante -----------------------------------

(defun KB-exec-test
  (KB-samples KB-p-start KB-p-end KB-step Lp-start Lp-end Lp-step num-var)
  (progn
     (setq *var_num* num-var)
     (setq *result-stream* (open *result-file* :direction :output))
     (setq *wff-stream* (open *wff-file* :direction :output))
     (KB-print-header KB-samples KB-p-start KB-p-end KB-step Lp-start Lp-end Lp-step)
     (do ((num-prop KB-p-start (+ num-prop KB-step)))
	((>= num-prop (+ KB-p-end KB-step)))
	(KB-print-dim num-prop)	
	(do ((len-prop Lp-start (+ len-prop Lp-step)))
	        ((>= len-prop (+ Lp-end Lp-step)))
	        (print-p-length len-prop)
	        (do ((kb-num 1 (+ kb-num 1)))
	            ((>= kb-num (+ KB-samples 1)))
	            (setq KB ())
	            ;generates random KB
	            (do ((j 1 (+ j 1)))
		        ((>= j (+ num-prop 1)))
	                (setq KB (append KB (list (gen-rand-s-prop len-prop))))  ;generates random KB
                    )
                    (KB-print KB)       ;prints KB propositions
                    (test_sat_KB KB)    ;executes test and prints results
	        )
        )
     )
     (close  *result-stream*) 
     (close  *wff-stream*)
  )
)
                            




