;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Tests design for SAT                                                    %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Antonio Lopreiato                                                       %                                                
;%%% antonio@iei.pi.cnr.it                                                   %                                                
;%%%                                                                         % 
;%%% March, 11th 1998                                                        %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; Executing test with 2-values calculus
;; Note that parameters setted to zero are'nt used

; template for satisfactibility test (no query admitted) 
; case 2v1 : varying values of *sign_TT_prob* (0.2,0.5,0.8,1)
;            and values of *var_num* (6,12,18)
;
; values of *sign_TT_prob* <= 0.4 --> the majority of formulas are signed NotTrue 
; 0.4 < *sign_TT_prob* < 0.6 --> formulas are almost equally signed True and NotTrue 
; values of *sign_TT_prob* >= 0.6 --> the majority of formulas are signed True 
; values of *sign_TT_prob* = 1 --> all formulas are signed True 

(setq *sign_TT_prob* TT-value) 
(setq p-var-num p-var-value)  ; setting number of propositional variables

;; case 2v1.1 :
;; uniform distribution and no query

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0 #'sigmaKB #'sigmaf1 #'len-array-constr nil)

;; case 2v1.2 :
;; one-length formulas and no query

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0 #'sigmaKB #'sigmaf2 #'len-array-constr-1 nil)


;; case 2v1.3.1 :
;; binomial distribution and no query
;; p = 0.1 --> the majority of formulas are short

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0.25 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 2v1.3.2 :
;; binomial distribution and no query
;; p = 0.5 --> the majority of formulas have medium length

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0.5 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 2v1.3.3 :
;; binomial distribution and no query
;; p = 0.9 --> the majority of formulas are long

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0.75 #'sigmaKB #'sigmaf #'len-array-constr t)


;--------------------------------------------------------------------------------------------------


; template for logic-implication test (query needed)
; case 2v2 :

(setq *sign_TT_prob* 1) ; all formulas on KB are signed True
(setq p-var-num p-var-value)  ; setting number of propositional variables
(setq *var_query_in_KB_prob* q-var-percent)  ; setting percentage of variabled used to build 
                                             ; both query and propositions on KB (try with
                                             ; values (0.2,0.6,0.9,1)

;; case 2v2.1 :
;; uniform distribution 

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL  p-var-num 0 #'sigmaKB #'sigmaf1 #'len-array-constr nil)

;; case 2v2.2 :
;; one-length formulas 

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0 #'sigmaKB #'sigmaf2 #'len-array-constr-1 nil)


;; case 2v2.3.1 :
;; binomial distribution 
;; p = 0.1 --> the majority of formulas are short

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0.25 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 2v2.3.2 :
;; binomial distribution 
;; p = 0.5 --> the majority of formulas have medium length

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0.5 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 2v2.3.3 :
;; binomial distribution
;; p = 0.9 --> the majority of formulas are long

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0.75 #'sigmaKB #'sigmaf #'len-array-constr t)


; notable cases :
; repeat tests designed above as follows :
; case 2v2.4.1 :

(setq *or_br* 0) ; propositions on KB without OR clauses

; case 2v2.4.2 :

(setq *neg_prob* 0) ; propositions on KB without negative letter 


;---------------------------------------------------------------------------------------------------------


;; Executing test with 4-values calculus
;; Note that parameters setted to zero are'nt used

; template for satisfactibility test (no query admitted) 
; case 4v1 : varying values of *sign_TT_prob* (0.2,0.5,0.8)
;            and values of *var_num* (6,12,18)
; 
; values of *sign_TT_prob* <= 0.4 --> the majority of formulas are signed NotTrue 
; 0.4 < *sign_TT_prob* < 0.6 --> formulas are almost equally signed True and NotTrue 
; values of *sign_TT_prob* >= 0.6 --> the majority of formulas are signed True  
; make no sense to execute a test with *sign_TT_prob* = 1
 
(setq *sign_TT_prob* TT-value) 
(setq p-var-num p-var-value)  ; setting number of propositional variables

;; case 4v1.1 :
;; uniform distribution and no query

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0 #'sigmaKB #'sigmaf1 #'len-array-constr nil)

;; case 4v1.2 :
;; one-length formulas and no query

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0 #'sigmaKB #'sigmaf2 #'len-array-constr-1 nil)


;; case 4v1.3.1 :
;; binomial distribution and no query
;; p = 0.1 --> the majority of formulas are short

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0.25 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 4v1.3.2 :
;; binomial distribution and no query
;; p = 0.5 --> the majority of formulas have medium length

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0.5 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 4v1.3.3 :
;; binomial distribution and no query
;; p = 0.9 --> the majority of formulas are long

(KB-exec-test 100 iKB eKB sKB iL eL sL 0 0 0 p-var-num 0.75 #'sigmaKB #'sigmaf #'len-array-constr t)


;--------------------------------------------------------------------------------------------------


; template for logic-implication test (query needed)
; case 4v2 :

(setq *sign_TT_prob* 1) ; all formulas on KB are signed True
(setq p-var-num p-var-value)  ; setting number of propositional variables
(setq *var_query_in_KB_prob* q-var-percent)  ; setting percentage of variabled used to build 
                                             ; both query and propositions on KB (try with
                                             ; values (0.2,0.6,0.9,1)

;; case 4v2.1 :
;; uniform distribution 

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL  p-var-num 0 #'sigmaKB #'sigmaf1 #'len-array-constr nil)

;; case 4v2.2 :
;; one-length formulas

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0 #'sigmaKB #'sigmaf2 #'len-array-constr-1 nil)


;; case 4v2.3.1 :
;; binomial distribution
;; p = 0.1 --> the majority of formulas are short

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0.25 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 4v2.3.2 :
;; binomial distribution 
;; p = 0.5 --> the majority of formulas have medium length

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0.5 #'sigmaKB #'sigmaf #'len-array-constr t)

;; case 4v2.3.3 :
;; binomial distribution
;; p = 0.9 --> the majority of formulas are long

(KB-exec-test 100 iKB eKB sKB iL eL sL iQL eQL sQL p-var-num 0.75 #'sigmaKB #'sigmaf #'len-array-constr t)


; notable cases :
; repeat tests designed above as follows :
; case 4v2.4.1 :

(setq *or_br* 0) ; propositions on KB without OR clauses

; case 4v2.4.2 :

(setq *neg_prob* 0) ; propositions on KB without negative letter 


;-------------------------------------------------------------------------------------------------------------

; Values proposed for KB : KB-init = 200, KB-end = 400, KB-step = 20
  
; Values proposed for Lp : Lp-init = 4, Lp-end = 120, Lp-step = 4

; Values proposed for Lq : Lq-init = 4, Lq-end = 40, Lq-step = 4

; The total of tests which can be executed is 465
