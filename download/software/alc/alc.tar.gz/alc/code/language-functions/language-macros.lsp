;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% macro definitions for propositional language L                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %                                                                       
;%%% Adapted by Antonio Lopreiato                                            %
;%%% May 5th 1998                                                            %                                                      
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 

(defconstant TOP '*top*)
(defconstant BOT '*bot*)
(defconstant ISC '*isc*)
(defconstant ISR '*isr*)
(defconstant AXM '*axm*)

;;--------------------------------------------------------------------------- 

(defmacro p-get-operant (p)   `(car ,p))   ;get the operant of p
(defmacro p-get-argument (p)  `(cadr ,p))  ;get the argument of unary operant
(defmacro p-get-arguments (p) `(rest ,p))  ;get the arguments of n-ary operant
(defmacro p-get-role-from-quant (p) `(second ,p)) ;get R from (all/csome R.C)
(defmacro p-get-prop-from-quant (p) `(third ,p))  ;get C from (all/csome R.C)

;;--------------------------------------------------------------------------- 

(defmacro p-istop (p)       `(equal ,p TOP))
(defmacro p-isbot (p)       `(equal ,p BOT))

(defmacro conc-istop (p)    `(equal (get-concept ,p) TOP))
(defmacro conc-isbot (p)    `(equal (get-concept ,p) BOT))


(defun p-isletter (p) 
  (and (symbolp p)
	(not (equal p 'not))
	(not (equal p 'and))
	(not (equal p 'or))
	(not (equal p 'all))
	(not (equal p 'csome))
	(not (equal p 'isc))
	(not (equal p 'isr)))
)

(defmacro p-isnot (p)       `(and (listp ,p)
                                  (= (length ,p) 2) 
                                  (equal (p-get-operant ,p) 'not)))
(defmacro p-isand (p)       `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'and)))
(defmacro p-isemptyand (p)  `(equal p '(and)))
(defmacro p-isor (p)        `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'or)))
(defmacro p-isemptyor (p)   `(equal p '(or)))

(defmacro p-isif (p)        `(and (listp ,p)
                                  (= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'if)))
(defmacro p-isiff (p)        `(and (listp ,p)
                                   (= (length ,p) 3) 
                                   (equal (p-get-operant ,p) 'iff)))

(defmacro p-isonlyif (p)     `(and (listp ,p)
                                   (= (length ,p) 3) 
                                   (equal (p-get-operant ,p) 'onlyif)))
                                  
(defmacro p-isall (p)
  `(and (listp ,p)
	(= (length ,p) 3)
	(equal (p-get-operant ,p) 'all))
)

(defmacro p-iscsome (p)
  `(and (listp ,p)
	(= (length ,p) 3)
	(equal (p-get-operant ,p) 'csome))
)

;;--------------------------------------------------------------------------- 

(defmacro p-mktop ()       'TOP)
(defmacro p-mkbot ()       'BOT)
(defmacro p-mknot (p)      `(list 'not ,p))
(defmacro p-mkand (land)   `(cons 'and ,land))
(defmacro p-mkor  (lor)    `(cons 'or  ,lor))
(defmacro p-mkif  (lif)       `(cons 'if  ,lif))
(defmacro p-mkiff  (liff)     `(cons 'iff  ,liff))
(defmacro p-mkonlyif  (loif)  `(cons 'onlyif  ,loif))
(defmacro p-mkall (r c) `(list 'all ,r ,c))
(defmacro p-mksome (r c) `(list 'csome ,r ,c))

(defun mknot-conc-ass (c-ass)
  (mk-concept-ass (second c-ass) (p-mknot (third c-ass)))
)

(defun p-mknumletter (num) (intern (concatenate 'string "p" (write-to-string num))))

(defun mk-sys-gen-indname (num) (intern (concatenate 'string "b" (write-to-string num))))

(defun mk-indname (num) (intern (concatenate 'string "a" (write-to-string num))))

(defun mk-rolename (num) (intern (concatenate 'string "r" (write-to-string num))))

(defmacro is-a-concept-ass (ass)
  `(and (listp ,ass)
	(= (length ,ass) 3)
	(equal (first ,ass) ISC))
)

(defmacro is-a-role-ass (ass)
  `(and (listp ,ass)
	(= (length ,ass) 3)
	(equal (first ,ass) ISR))
)

(defmacro is-an-axiom (ass)
  `(and (listp ,ass)
	(= (length ,ass) 2)
	(equal (first ,ass) AXM))
)

(defmacro mk-concept-ass (ind p)
  `(list isc ,ind ,p)
)

(defmacro mk-axiom (cond-ex)
 `(list axm ,cond-ex)
)

(defmacro mk-role-ass (ind1 ind2 c)
  `(list isr (list ,ind1 ,ind2) ,c)
)

(defun get-concept (c-ass)
  (third c-ass)
)
 
(defmacro get-axiom (ass)
 `(second ,ass)
)

(defun get-role-name (r-ass)
  (third r-ass)
)

(defun get-individuals (ass)
  (second ass)
)
;;---------------------------------------------------------------------------

