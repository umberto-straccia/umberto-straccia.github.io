;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Syntax Checker for language ALC                                         %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %                                                                       
;%%% Adapted by Antonio Lopreiato                                            %
;%%% May 5th 1998                                                            % 
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This is a Syntax Checker for the Language ALC.

;;The language contains letters (denoted by P,Q) 
;;and propositions denoted by (C,D) which are built 
;;according to the following rule:
;;
;;C,D -> P              ;letter
;;     | *top*          ;true
;;     | *bot*          ;false
;;     | (not A)        ;negation
;;     | (and A B ...)  ;conjunction
;;     | (or A B ...)   ;disjunction
;;     | (all R C)      ;universal quantifier
;;     | (csome R C)    ;existential quantifier
;;
;;  R -> Q
;;
;; AX -> (if P C)       ;primitive concept P implies C
;;     | (onlyif P C)   ;concept C implies P
;;     | (iff P C)      ;it's equivalent to the set {(if P C),(onlyif P C)}
;;
;;R,C,a,b -> (*isc* a C)      ;concept assertion
;;         | (*isr* (a b) R)  ;role assertion
;;         | (*axm* AX)       ;axiom 
           
;; load macro functions
;;(load "language-macros-L.lsp")

;; Check the syntax of an ALC assertions
;; *************************************

;;--------------------------------------------------------------------------- 
;;check-proposition(p):
;;INPUT:   p = expression
;;RETURN:  p, if p is L-proposition
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-proposition (p)
  (cond 
    ((p-isletter p) p) 
	((and (p-isnot p)
	      (check-proposition (p-get-argument p))) 
	  p) 
	((and (or (p-isand p) (p-isor p) (p-isif p) (p-isiff p))
	      (check-propositions (p-get-arguments p))) 
	 p)
	((and (or (p-isall p) (p-iscsome p))
	      (check-quant p)) 
	  p)
	(t (format *standard-output* "==> Illegal L proposition expression ~S~%" p) 
	   nil)))

;;--------------------------------------------------------------------------- 
;;check-propositions (plist):
;;INPUT:   plist = list of expressions
;;RETURN:  plist, if p is alist of  L-propositions
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-propositions(plist)
  (cond ((null plist) t)
        (t (and (check-proposition (first plist))
		        (check-propositions (rest plist))))))

;check a quantified proposition e.g. (all/csome R.C)
(defun check-quant (p)
  (and (p-isletter (second p))
       (check-proposition (third p))
   )
)

;check an ALC assertion
(defun check-assertion (ass)
  (or (and (is-a-role-ass ass) 
           (check-role-arg ass)
	    ass)
      (and (is-a-concept-ass ass)
	   (check-concept-arg ass)
            ass)
      (and (is-an-axiom ass)
	   (check-axiom-arg ass)
            ass)   
  )
)

(defun check-axiom-arg (ax)
 (let* ((p (get-axiom ax))
        (args (p-get-arguments p)))
    (and (or (p-isif p) (p-isonlyif p)
                 (p-isiff p))
         (p-isletter (first args))
         (check-proposition (second args)))
 )
)

;check a concept assertion e.g (*ISC* ind concept)
(defun check-concept-arg (ass)
   (and	(p-isletter (second ass))
	(check-proposition (third ass)))
)

;check a role assertion e.g (*ISR* (ind1 ind2) R)
(defun check-role-arg (ass)
  (let ((sec (second ass)))
        (and (listp sec) 
             (= (length sec) 2)
	     (every #'p-isletter sec)
             (p-isletter (third ass)))
   )
)

;check a list of ALC assertion
(defun check-assertions (assl)
   (if (null assl)
       t
       (and (check-assertion (first assl))
	    (check-assertions (rest assl)))
   )
)
