; values for 3sat-random-gen.lsp

(defvar *neg_prob*)        ; ratio negative literals
(defvar *var_num*)         ; variable number
(defvar *and_br*)          ; and branching
(defvar *or_br*)           ; or branching
(defvar *literal_prob*)    ; ratio literals/propositions


(defvar *MAX_NUM*)
(setq *MAX_NUM* 1000000)

; You have to set the parameters before calling 
; (get-random-proposition)
; to generate a random propositional formula. 
;
; According to the guidelines of Hustadt and Schmidt (IJCAI-97) 
; the parameters *or_br* and *literal_prob*
; should be set as follows:

(setq *or_br* 3)
;(setq *literal_prob* 0)   ; not used

; *neg_prob* should be 0.5
(setq *neg_prob* 0.5)

; The only parameters remaining are the number of propositional variables
; and the number of conjunctions in the formula.

(setq *var_num* 4)
(setq *and_br*  4)

;(setq *random-state* (make-random-state t))




