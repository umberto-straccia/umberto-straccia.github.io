;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Search Space algorithm                                                  %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This is a Search algorithm in a Space of States. 
;; Each state encodes a  problem to be solved.
;; It starts with a set of states to be solved
;; and returns true if all of them can be solved.


;;--------------------------------------------------------------------------- 
;; state-solver(lstates get-new-states-fn closed-state-fn termination-case-fn get-result-fn)
;; Input: 
;;   lstates = list of states to be solved
;;   get-new-states-fn = function: State --> 2^S, list of new states
;;   closed-state-fn   = function: State --> {true,false}, is state closed ?
;;   termination-case-fn  = function returning --> {true,false}, should search stop ?
;;   get-result-fn      = function returning --> {true,false}, what is the result of search stop ?
;;  Return: 
;;     (result lopen-states lclosed-states l-completed-states current-state lintermediate-states)
;;    1.      result = true if lstates are solved
;;    2.      lopen-states         ; list of to be solved states
;;    3.      lclosed-states       ; list of solved states
;;    4.      lcompleted-states    ; list of completed states, but not solved
;;    5.      current-state        ; current state in which the search has been stopped
;;    6.      lintermediate-states ; list of all other states processed

;;--------------------------------------------------------------------------- 

;; load defintion of STATE and functions working on it.
;(load "state-solver-defs.lsp")

(defun state-solver (lstates get-new-states-fn closed-state-fn termination-case-fn get-result-fn)
	(progn 
	     ; result                ; initialize result value
	     ; lresult-tmp           ; temporary result list
	     ; lopen-states          ; list of to be solved states
	     ; lclosed-states        ; list of solved states
	     ; lcompleted-states     ; list of completed states, but not solved
	     ; current-state         ; current state
         ; lintermediate-states  ; list of all other states processed
	      
	     (setq result nil)
	     (setq current-state nil)
	     (setq lcompleted-states ())
         (setq lintermediate-states ())
	     (setq lresult-tmp (get-open-closed-states lstates closed-state-fn))
	     (setq lopen-states (first lresult-tmp))
	     (setq lclosed-states (second lresult-tmp))
	     ;
          (loop 
              (if (funcall termination-case-fn lopen-states lclosed-states lcompleted-states)
	          (return))    ; stop search 
	         ;                   
	         (setq lresult-tmp (get-next-state lopen-states))
	         (setq current-state (first lresult-tmp))  ; new current state
	         (setq lopen-states (second lresult-tmp))  ; rest of states
	         (if (eq nil current-state)
	             (return))    ; stop search 
	         ; 
                 (setq lintermediate-states (add-intermediate-states current-state lintermediate-states))
                 ;       	         
	         (setq lnew-states (funcall get-new-states-fn current-state)) ; get list of new states
                                                                              ; from the current one
                 (if (null lnew-states)  ; there is no new state
	             (setq lcompleted-states (add-completed-states current-state lcompleted-states)) ; 
	             (progn ; else                           
	                 (setq lresult-tmp (get-open-closed-states lnew-states closed-state-fn))
	                 (setq lnewopen-states (first lresult-tmp))  ; new open states
	                 (setq lnewclosed-states (second lresult-tmp))  ; new closed states                                        
	                 (setq lclosed-states (add-closed-states lnewclosed-states lclosed-states))
	                 (setq lopen-states (add-open-states lnewopen-states lopen-states))
	             ) ; endelse
	         ); endif
	     ) ;endloop
	     (setq result (funcall get-result-fn lopen-states lclosed-states lcompleted-states))
	     (list result 
	           lopen-states
	           lclosed-states 
	           lcompleted-states
	           current-state
               lintermediate-states
	     ) ; returned values of the function
	 )
)
