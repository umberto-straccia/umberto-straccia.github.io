;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         %
;%%% October, 6th 1997                                                       %
;%%%                                                                         %                                                                       % 
;%%% Adapted by Antonio Lopreiato                                            %
;%%% May 5th 1998                                                            %   
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This file contains the function in order to execute about sat problems

;;--------------------------------------------------------------------------- 
;; alc-sat (p)
;; Input: ALC assertion 
;; Return: result = true if SAT p
;;--------------------------------------------------------------------------- 


(defun alc-sat (p) 
 (progn
       (setq result (alc-sat-exec (list p)))
       (second result) ;; return result
 )
)


;;--------------------------------------------------------------------------- 
;; alc-sat-KB (alc-list)
;; Input: list of ALC assertions, i.e. a KB 
;; Return: result = true if SAT alc-list
;;--------------------------------------------------------------------------- 

(defun alc-sat-KB (alc-list) 
 (progn
       (setq result (alc-sat-exec alc-list))
       (second result) ;; return result
 )
)

;;--------------------------------------------------------------------------- 
;; alc-logically-implies (kb p)
;; Input: kb = list of ALC assertions, i.e. a KB 
;;        p  = an ALC assertion (the query)
;; Return: result = true if KB |= p
;;--------------------------------------------------------------------------- 

(defun alc-logically-implies (kb p)
 (progn
       (setq s (append (list (mknot-conc-ass p)) kb))
       (not (alc-sat-KB s))
 )
)

;;--------------------------------------------------------------------------- 
;; alc-logically-implies-ext (ext-KB q)
;; Input: ext-KB = list of completions (see below for more info)
;;        q  = an ALC assertion (the query)
;; Return: result = true if ext-KB |= q
;;---------------------------------------------------------------------------

(defun alc-logically-implies-ext (ext-KB q)
 (let* ((nq (mknot-conc-ass q))
        (ml ext-KB)
        (qml (mapcar #'(lambda (m) (push nq m)) ml)))
     (not (second (multistates-alc-sat-exec qml))))
)      

;;--------------------------------------------------------------------------- 
;; alc-tautology (p)
;; Input: p  = an ALC assertion
;; Return: result = true if |= p
;;--------------------------------------------------------------------------- 

(defun alc-tautology (p)
  (not (alc-sat (mknot-conc-ass p)))
)

;;--------------------------------------------------------------------------- 
;; alc-get-a-model (p)
;; Input: an ALC proposition 
;; Return: both a list of ALC primitive (positive) concepts and roles 
;;         i.e. an Herbrand model of p, or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun alc-get-a-model (p) 
 (progn
       (setq result (alc-sat-exec (list p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-KB-get-a-model (KB)
;; Input: a list of ALC propositions 
;; Return: both a list of ALC primitive (positive) concepts and roles
;;         i.e. an Herbrand model of KB, or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun alc-KB-get-a-model (alc-list) 
 (progn
       (setq result (alc-sat-exec alc-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-get-all-models (fp)
;; Input: an ALC proposition 
;; Return: both a list of ALC primitive (positive) concepts and roles
;;         i.e. an Herbrand model of fp, or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun alc-get-all-models (p) 
 (progn
       (setq result (alc-all-models-exec (list p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-KB-get-all-models (KB)
;; Input: a list of ALC propositions 
;; Return: both a list of ALC primitive (positive) concepts and roles
;;         i.e. an Herbrand model of KB, or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;---------------------------------------------------------------------------

(defun alc-KB-get-all-models (alc-list) 
 (progn
       (setq result (alc-all-models-exec alc-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-get-a-completion (p)
;; Input: an ALC proposition 
;; Return: both a list of ALC primitive (positive) concepts, roles, 
;;         'ALL' concepts and axioms, i.e. an Herbrand model of p,
;;         or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun alc-get-a-completion (p) 
 (progn
       (setq result (alc-sat-exec (list p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-completions lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-KB-get-a-completion (KB)
;; Input: a list of ALC propositions 
;; Return: both a list of ALC primitive (positive) concepts, roles, 
;;         'ALL' concepts and axioms, i.e. an Herbrand model of p,
;;         or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun alc-KB-get-a-completion (alc-list) 
 (progn
       (setq result (alc-sat-exec alc-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-completions lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-get-all-completions (fp)
;; Input: an ALC proposition 
;; Return: both a list of ALC primitive (positive) concepts, roles, 
;;         'ALL' concepts and axioms, i.e. an Herbrand model of p,
;;         or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun alc-get-all-completions (p) 
 (progn
       (setq result (alc-all-models-exec (list p)))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-completions lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; alc-KB-get-all-completions (KB)
;; Input: a list of ALC propositions 
;; Return: both a list of ALC primitive (positive) concepts, roles, 
;;         'ALL' concepts and axioms, i.e. an Herbrand model of p,
;;         or (NIL) that is the empty model.
;;         Return nil if no models are avalaible
;;---------------------------------------------------------------------------

(defun alc-KB-get-all-completions (alc-list) 
 (progn
       (setq result (alc-all-models-exec alc-list))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-completions lcompleted-states)) ;; return all models
       )         
 )
)

;;---------------------------------------------------------------------------


