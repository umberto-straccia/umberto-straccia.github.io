;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Definitions and functions related to the Search Space algorithm         %
;%%% Contains functions which typically need not to be modified              %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



;;---------------------------------------------------------------------------- 
;; get-open-closed-states (lstates closed-fn)
;; Input  : lstates = list of states
;;          closed-fn = function determining whether a state is closed
;; Return : (lopen-states lclosed-states)
;;          lopen-states = list of open states and not being closed
;;          lclosed-states = list of closed states
;;--------------------------------------------------------------------------- 
            
(defun get-open-closed-states (lstates closed-fn)
 ;(let (
 ;     (lclosed-st ())
 ;     (lopen-st ())
 ;     )
 (progn
      (setq lclosed-st ())
      (setq lopen-st ())
      (dolist (curr-state lstates)
          (if (funcall closed-fn curr-state)
              (setq lclosed-st (add-closed-states (list curr-state) lclosed-st))
              (setq lopen-st (add-open-states (list curr-state) lopen-st))
          )
      )
      (list lopen-st
            lclosed-st
      )  ;; returned values
 )
)


;;--------------------------------------------------------------------------- 
;; get-next-state (lstates)
;; Input  : lstates = list of states
;; Return : (s ls) = 
;;          s a state, 
;;          ls is lstates without s 
;;--------------------------------------------------------------------------- 
            
(defun get-next-state (lstates)
 (progn
      (setq result (pop lstates))
      (list result lstates)
 )
)  


;;--------------------------------------------------------------------------- 
;; add-open-states (lstates1 lstates2)
;; Input  : 2 lists of states
;; Return : add states of lstates1 to lstates2
;;--------------------------------------------------------------------------- 

(defun add-open-states (lstates1 lstates2)
 (progn
      (setq result (append lstates1 lstates2))
      result
 )
) 

;;--------------------------------------------------------------------------- 
;; add-closed-states (lstates1 lstates2)
;; Input  : 2 lists of states
;; Return : add states of lstates1 to lstates2
;;--------------------------------------------------------------------------- 

(defun add-closed-states (lstates1 lstates2)
 (progn
      (setq result (append lstates1 lstates2))
      result
 )
) 

;;--------------------------------------------------------------------------- 
;; add-completed-states (state lstates)
;; Input  : a state and a list of states
;; Return : add state to lstates
;;--------------------------------------------------------------------------- 

(defun add-completed-states (state lstates)
 (progn
      (setq result (push state lstates))
      result
 )
) 

;;--------------------------------------------------------------------------- 
;; add-intermediate-states (state lstates)
;; Input  : a state and a list of states
;; Return : add state to lstates
;;--------------------------------------------------------------------------- 

(defun add-intermediate-states (state lstates)
 (progn
      (setq result (push state lstates))
      result
 )
)

;;---------------------------------------------------------------------------



