;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;;--------------------------------------------------------------------------- 
;; alc-sat-exec (alc-list)  (resp. multistates-alc-sat-exec (KB-list))
;; Input: list of ALC assertions, i.e. a KB  (resp. list of KB) 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	              6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT alc-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun alc-sat-exec (alc-list)
   (alc-state-solver alc-list                ; initial state
                   #'sat-get-new-states      ; new states generation function
                   #'sat-closed-state        ; determines whether a state is closed
                   #'sat-termination         ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

(defun multistates-alc-sat-exec (KB-list)
   (multistates-alc-state-solver KB-list     ; initial state
                   #'sat-get-new-states      ; new states generation function
                   #'sat-closed-state        ; determines whether a state is closed
                   #'sat-termination         ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

;;--------------------------------------------------------------------------- 
;; alc-all-models-exec (alc-list)  (resp. multistates-alc-sat-exec (KB-list))
;; Input: list of ALC assertions, i.e. a KB   (resp. list of KB) 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT alc-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun alc-all-models-exec (alc-list)
   (alc-state-solver alc-list                ; initial state
                   #'sat-get-new-states      ; new states generation function
                   #'sat-closed-state        ; determines whether a state is closed
                   #'model-termination       ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

(defun multistates-alc-all-models-exec (KB-list)
   (multistates-alc-state-solver KB-list     ; initial state
                   #'sat-get-new-states      ; new states generation function
                   #'sat-closed-state        ; determines whether a state is closed
                   #'model-termination       ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

;;--------------------------------------------------------------------------- 
;; alc-state-solver (alc-list     (resp. multistates-alc-sat-exec (KB-list))
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of ALC assertions, i.e. a KB     (resp. list of KB)
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun alc-state-solver (alc-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       (setq *number-of-states* 0)
       (setq *new-ind-counter* 0)
       (setq *axioms* (make-hash-table :test #'equal))
       (setq *models_axioms* nil)
       (setq alc-list (simplify-ass-list alc-list))  ; reduce every proposition in alc-list in NNF
       ; build first state, the case of multiple initial states is similar
       (setq newstate (sat-initial-state-make alc-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver (list newstate)        ; initial state
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

(defun multistates-alc-state-solver (KB-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       (setq *number-of-states* 0)
       (setq *new-ind-counter* 0)
       (setq *axioms* (make-hash-table :test #'equal))
       (setq *models_axioms* nil)
       (setq KB-list (mapcar #'simplify-ass-list KB-list))  ; reduce every proposition in KB-list in NNF
       ; build multiple initial states 
       (setq newstates (mapcar #'sat-initial-state-make KB-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver newstates              ; initial states
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)
;;---------------------------------------------------------------------------

