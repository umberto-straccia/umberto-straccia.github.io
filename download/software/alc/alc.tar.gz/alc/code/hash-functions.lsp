;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Antonio Lopreiato                                                       %                                                
;%%% antonio@iei.pi.cnr.it                                                   %                                                
;%%%                                                                         % 
;%%% May, 5th 1998                                                           %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;-----------------------------------------------------------------------------
; Hash tables utilities
;-----------------------------------------------------------------------------

;clones an hash table (start-table) into a target hash table (end-table)
 
(defun clone-hash-table (start-table end-table)
  (maphash #'(lambda (k v) (in-hash k v end-table))
			start-table)
) 

;insert an element onto an hash table

(defun in-hash (key value hash-table)
  (setf (gethash key hash-table) value)
)
