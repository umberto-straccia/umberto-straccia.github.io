;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% compile language specific functions procedure                                                   %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; syntax checker
(compile-file "code/language-functions/syntax-checker.lsp")

;; compile macro functions about L syntax
(compile-file "code/language-functions/language-macros.lsp")

;; compile propositional expression simplifier
(compile-file "code/language-functions/simplify-macros.lsp")
