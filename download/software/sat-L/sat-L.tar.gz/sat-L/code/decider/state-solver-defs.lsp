;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Definitions and functions related to the Search Space algorithm         %                                         %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;;---------------------------------------------------------------------------- 
;; number of states
;;--------------------------------------------------------------------------- 

(defvar *number-of-states* 0)

(defun init-number-of-states ()
   (setq *number-of-states* 0)
)

;;---------------------------------------------------------------------------- 
;; Sat state type definition
;;--------------------------------------------------------------------------- 
            
(defstruct sat-state
    id                            ; the key id for the state
    pred                          ; predecessor states
    succ                          ; succesor states
    (info nil :type sat-state-info)  ; our data information 
)

(defstruct sat-state-info
    andl                        ; list of ANDs
    orl                         ; list of ORs
    posl                        ; list of positive letters
    negl                        ; list of negative  letters
    posl-modified               ; boolean = true iff posl modified
    negl-modified               ; boolean = true iff negl modified
)

(defun sat-state-make (state info-arg)
 (progn
    (setq newid (incf *number-of-states*))
    (setf (sat-state-succ state) (push newid (sat-state-succ state)))
    (setq result (make-sat-state 
                    :id newid 
                    :pred (sat-state-id state)
                    :succ ()
                    :info info-arg))
    result ; returned value
                    
 )
)

(defun sat-initial-state-make (argl)
 (progn
    (setq result nil)
    (setq newid (incf *number-of-states*))
    (setq sat-state-info-tmp
            (sat-state-info-make-from-choice argl () () () () nil nil))        
     
    (setq result (make-sat-state :id newid
                                 :pred ()
                                 :succ ()
                                 :info sat-state-info-tmp))
     result   ; returned result
 )
)

(defun sat-state-info-make 
    (andl-arg orl-arg posl-arg negl-arg  posl-modified-arg negl-modified-arg)
 (make-sat-state-info  :andl andl-arg 
                       :orl  orl-arg 
                       :posl posl-arg 
                       :negl negl-arg 
                       :posl-modified posl-modified-arg  
                       :negl-modified negl-modified-arg)
                                                   
)

(defun sat-state-info-make-from-choice 
   (arg-list andl-arg orl-arg posl-arg negl-arg posl-modified-arg negl-modified-arg) 
  (progn 
     (dolist (arg arg-list)                                     
          (cond ((or (p-isletter arg)
                     (p-isbot arg))
                 (pushnew arg posl-arg)
                 (setq posl-modified-arg t)
                )
                ((p-isnot arg)
                 (pushnew (p-get-argument arg) negl-arg)
                 (setq negl-modified-arg t)
                )
                ((p-isand arg) ; are is AND
                 (pushnew arg andl-arg)
                )
                ((p-isor arg) ; arg is OR
                 (pushnew arg orl-arg)
                )
          )
     ) ; enddolist
     (setq result (sat-state-info-make 
                       andl-arg                               ; andl
                       orl-arg                                ; orl
                       posl-arg                               ; posl
                       negl-arg                               ; negl
                       posl-modified-arg                      ; posl-modified
                       negl-modified-arg                      ; negl-modified
                  ))
                  
    result
  )                                                                   
)

;;--------------------------------------------------------------------------- 
;; sat-closed-state (state)
;; Input  : state = a state
;; Return : true iff state is closed
;;          a state is closed whenever either
;;          1. BOT is in posl
;;          2. TOP is in negl
;;          3. there is A in both posl and negl
;;
;;--------------------------------------------------------------------------- 
            
(defun sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info))
          ; check return condition
          (setq result (sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)))
          (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
) 

;; test for sat-closed-state 
(defun sat-closed-state-test (pl nl)
 (or (member BOT pl)  ; false test
     ;(member TOP nl)  ; true test
     ; check if there is complementary pair
     (some #'(lambda (x) (some #'(lambda (y) (equal x y)) nl)) pl)
 )
)


;;--------------------------------------------------------------------------- 
;; sat-get-new-states (state)
;; Input  : a state
;; Return : list of new states to be solved, generated from current-state
;;          applying the following simple rules. 
;;          Remember that the initial proposition should be in NNF.
;;
;;              (and A1 ... An)
;;         (A)  ---------------
;;               A1, ... , An
;;
;;     
;;
;;                        (or A1 A2... An)
;;         (PB)  -------------------------------------
;;               A1     |    (not A1), (or A2 ... An)
;;
;;
;;
;;          the only branching rule is (PB).
;;          the priority between rules is (A) > (PB)
;;
;;--------------------------------------------------------------------------- 

(defun sat-get-new-states (state)
 (progn
      (setq result nil) 
      (setq sat-info (sat-state-info state))
      (cond ((not (null (sat-state-info-andl sat-info)))   ; there is an AND
             (setq result (sat-and-get-new-states state))
            )
            ((not (null (sat-state-info-orl sat-info)))   ; there is an OR proposition
             (setq result (sat-or-get-new-states state))
            )
            (t (setq result ())) ; no new states
      )
      result   ; returned result
 )
)

;; get new states from an AND proposition
(defun sat-and-get-new-states (state)
 (progn
      (setq result nil)
      (setq info-tmp  (sat-state-info state))
      (setq andl-tmp  (sat-state-info-andl info-tmp))
      (setq orl-tmp   (sat-state-info-orl  info-tmp))
      (setq posl-tmp  (sat-state-info-posl info-tmp))
      (setq negl-tmp  (sat-state-info-negl info-tmp))
      (setq posl-modified-tmp  nil)
      (setq negl-modified-tmp  nil)
      (setq p (first andl-tmp))
      (setq andl-tmp (rest andl-tmp))
      ; p is an (and A1 ... An), where A1 ... An are neither ANDs, TOP, and BOT 
      (setq and-args (p-get-arguments p))
      (setq sat-state-info-tmp
            (sat-state-info-make-from-choice
                and-args
                andl-tmp                               
                orl-tmp                                
                posl-tmp                               
                negl-tmp                               
                posl-modified-tmp                      
                negl-modified-tmp                      
            ))
      (setq result (sat-state-make state sat-state-info-tmp))        
      (list result)   ; returned list as result
 )
)

;; get new states from an OR proposition
(defun sat-or-get-new-states (state)
 (progn
      (setq result nil)
      (setq info-tmp  (sat-state-info state))
      ;(setq andl-tmp  (sat-state-info-andl info-tmp))    ;(equal andl-tmp  ())  by definition
      (setq andl-tmp  ())                                ;(equal andl-tmp  ())  by definition
      (setq orl-tmp   (sat-state-info-orl info-tmp))
      (setq posl-tmp  (sat-state-info-posl info-tmp))
      (setq negl-tmp  (sat-state-info-negl info-tmp))
      (setq posl-modified-tmp  nil)
      (setq negl-modified-tmp  nil)
      (setq p (first orl-tmp))
      (setq orl-tmp (rest orl-tmp))
      ; p is an (or A1 ... An), where A1 ... An are neither ORs, TOP, and BOT 
      (setq or-args (p-get-arguments p))
      (setq arg (first or-args))                        ; A1
      (setq notA1 (p-mknot arg))                        ; (not A1)
      (setq notA1 (p-simplify notA1))                   ; transform into NNF
      (setq orA (p-mkor (push BOT (rest or-args))))   ; (or BOT A2 ... An), 
                                                        ; this ensures that the OR has at least two arguments
      (setq orA (p-simplify orA))                       ; transform into NNF    
      (setq sat-state-info-tmp1
            (sat-state-info-make-from-choice
                (list arg) 
                andl-tmp                               
                orl-tmp                                
                posl-tmp                               
                negl-tmp                               
                posl-modified-tmp                      
                negl-modified-tmp                      
            ))
      (setq sat-state-info-tmp2
            (sat-state-info-make-from-choice
                (list notA1 orA) 
                andl-tmp                               
                orl-tmp                                
                posl-tmp                               
                negl-tmp                               
                posl-modified-tmp                      
                negl-modified-tmp                      
            ))
      (setq newstate1 (sat-state-make state sat-state-info-tmp1))
      (setq newstate2 (sat-state-make state sat-state-info-tmp2))
      (list newstate1 newstate2) ; return result which is  list of new states
 )
)
                 


;;--------------------------------------------------------------------------- 
;; sat-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun sat-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (or (null lopen-states)   ; no more states to be processed
                       (not (null lcompleted-states))))   ; there is a not closed completed branch
      result
 )
)  

;;--------------------------------------------------------------------------- 
;; sat-get-result (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a succesful search
;;--------------------------------------------------------------------------- 

(defun sat-get-result (lopen-states lclosed-states lcompleted-states)
 (progn
      ;; return true if there is a not closed and completed state S, i.e. 
      ;; S encodes a model 
      ;; 
      (setq result (not (null lcompleted-states)))
      result
 )
)

;;--------------------------------------------------------------------------- 
;; model-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun model-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (null lopen-states)) ; no more states to be processed
      result
 )
)  


;;--------------------------------------------------------------------------- 
;; sat-build-models (lcompleted-states)
;; Input  :  lists of completed states
;; Return : list of Herbrand models
;;--------------------------------------------------------------------------- 

(defun sat-build-models (lcompleted-states)
 (progn
      (cond ((null lcompleted-states) nil)
            (t (cons (sat-state-info-posl (sat-state-info (first lcompleted-states)))
                     (sat-build-models (rest lcompleted-states)))
            )     
      
      )
 )
)
;;---------------------------------------------------------------------------


