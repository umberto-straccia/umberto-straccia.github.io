;;; stuff
(cond ((or (p-isbot p)
                 (p-isletter p))
             (setq sat-state-info-tmp 
                   (sat-state-info-make 
                      andl-rest                               ; andl
                      (sat-info-orl sat-info)                 ; orl
                      (append p (sat-info-posl sat-info))     ; posl
                      (sat-info-negl sat-info)                ; negl
                      t                                       ; posl-modified
                      nil                                     ; negl-modified
                   )
             )
            )
            
            
            
            
                          
      
      (setq result 
           (sat-state-make (state-id state)             ; id
                           (state-pred state)           ; pred
                           (state-succ state)           ; succ
                           sat-state-info-tmp))         ; info 
            
            