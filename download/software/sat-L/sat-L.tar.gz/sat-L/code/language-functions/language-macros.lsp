;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% macro definitions for propositional language L                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 

(defconstant TOP '*top*)
(defconstant BOT '*bot*)

;;--------------------------------------------------------------------------- 

(defmacro p-get-operant (p)   `(car ,p))   ;get the operant of p
(defmacro p-get-argument (p)  `(cadr ,p))  ;get the argument of unary operant
(defmacro p-get-arguments (p) `(rest ,p))  ;get the arguments of n-ary operant

;;--------------------------------------------------------------------------- 

(defmacro p-istop (p)       `(equal ,p TOP))
(defmacro p-isbot (p)       `(equal ,p BOT))
(defmacro p-isletter (p)    `(and (symbolp ,p) 
                                  (not (equal ,p 'not))
                                  (not (equal ,p 'and))
                                  (not (equal ,p 'or))   
                             ))
(defmacro p-isnot (p)       `(and (listp ,p)
                                  (= (length ,p) 2) 
                                  (equal (p-get-operant ,p) 'not)))
(defmacro p-isand (p)       `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'and)))
(defmacro p-isemptyand (p)  `(equal p '(and)))
(defmacro p-isor (p)        `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'or)))
(defmacro p-isemptyor (p)   `(equal p '(or)))

(defmacro p-isif (p)        `(and (listp ,p)
                                  (= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'if)))
(defmacro p-isiff (p)        `(and (listp ,p)
                                   (= (length ,p) 3) 
                                   (equal (p-get-operant ,p) 'iff)))
                                  

;;--------------------------------------------------------------------------- 

(defmacro p-mktop ()       'TOP)
(defmacro p-mkbot ()       'BOT)
(defmacro p-mknot (p)      `(list 'not ,p))
(defmacro p-mkand (land)   `(cons 'and ,land))
(defmacro p-mkor  (lor)    `(cons 'or  ,lor))
(defmacro p-mkif  (lif)    `(cons 'if  ,lif))
(defmacro p-mkiff  (liff)  `(cons 'iff  ,liff))

(defun p-mknumletter (num) (intern (concatenate 'string "p" (write-to-string num))))


;;---------------------------------------------------------------------------

