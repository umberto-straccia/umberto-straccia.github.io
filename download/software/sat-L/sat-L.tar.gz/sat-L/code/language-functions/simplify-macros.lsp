;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% simplify functions  for propositional language L                        %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 
;;p-simplify(p):
;;INPUT:   p = propositional expression
;;RETURN:  an equivalent expression simplified as follows. 
;;         (p-NNF p)               ; transform into NNF
;;         (p-remove-taut-ctd p)   ; then, handle TOP and BOT
;;
;;--------------------------------------------------------------------------- 

(defun p-simplify (p)
  (p-remove-taut-ctd (p-NNF p))
)

;;--------------------------------------------------------------------------- 
;;p-NNF(p):
;;INPUT:   p = propositional expression
;;RETURN:  an equivalent expression in Negation Normal Form. Moreover, 
;;         it simplifies p according to
;;  
;;         (and ..A1 ... A2 ...) |- (and ... A1 ...) 
;;               if p-structural-subs (A2, A1) and Ai are ANDs
;;          
;;         (or ..A1 ... A2 ...) |- (or ... A1 ...) 
;;               if p-structural-subs (A2, A1) and Ai are ORs
;;--------------------------------------------------------------------------- 


(defun p-NNF (p)
  (cond 
    ((p-isletter p) p)
    ((p-isemptyand p) TOP)
    ((p-isemptyor p)  BOT)
    ((p-isnot p)      (p-neg-NNF (p-get-argument p)))
    ((p-isand p)      (p-and-NNF (p-get-arguments p)))
    ((p-isor p)       (p-or-NNF  (p-get-arguments p)))
  )
)

(defun p-and-NNF (p)   ; NNF of a list of arguments of an AND
  (progn
    (setq land-tmp (delete TOP 
                           (p-remove-double (p-remove-ands (mapcar #'p-NNF p))
		                                    nil
		                   )
		          )
    )
    (cond ((>= (length land-tmp) 2)
           (p-mkand land-tmp))  ; there are at least two arguments, make an AND
          ((= (length land-tmp) 1)
           (car land-tmp))      ; one argument, no AND and return arg
          ((= (length land-tmp) 0)
            TOP)      ; zero argument, no AND and return TOP 
    )
  )
)

;;; simplyfies ( ... A (and  ...) ...) to (... A ...)

(defun p-remove-ands (and-list) 
  (if (null and-list) 
      nil
      (if (p-isand (first and-list)) ; nested AND  
	      (append (p-get-arguments (first and-list)) (p-remove-ands (rest and-list)))
          (cons (first and-list) (p-remove-ands (rest and-list)))          
      )
  )
)

;;; simplyfies ( ... F1 ... F1 ...) to (...F1 ...)

(defun p-remove-double (p lp-tmp) 
;  (if (null p) 
;      nil
;      (if (member (first p) lp-tmp) ; check if there are doubles 
;          ;(member (first p) lp-tmp :test #'equal) ; check if there are doubles 
;          ;(member (first p) lp-tmp :test #'p-structural-equiv) ; check if there are doubles
;	      (p-remove-double (rest p) lp-tmp)
;          (cons (first p) (p-remove-double (rest p) (cons (first p) lp-tmp)))
;      )
;  )
  (if (null p) 
      nil
      (if ;(member (first p) lp-tmp) ; check if there are doubles 
          (member (first p) lp-tmp :test #'equal) ; check if there are doubles 
          ;(member (first p) (union (rest p) lp-tmp) :test #'p-structural-subs) ; check if there are doubles
	      (p-remove-double (rest p) lp-tmp)
          (cons (first p) (p-remove-double (rest p) (cons (first p) lp-tmp)))
      )
  )
  
)


(defun p-or-NNF (p)  ; NNF of a list of arguments of an OR
  (progn
    (setq lor-tmp (delete BOT 
                           (p-remove-double (p-remove-ors (mapcar #'p-NNF p))
		                                    nil
		                   )
		          )
    )
    (cond ((>= (length lor-tmp) 2)
           (p-mkor lor-tmp))  ; there are at least two arguments, make an OR
          ((= (length lor-tmp) 1)
           (car lor-tmp))      ; one argument, no OR and return arg
          ((= (length lor-tmp) 0)
            BOT)      ; zero argument, no AND and return BOT 
    )
  )
)

;;; simplyfies ( ... A (or  ...) ...) to (... A ...)

(defun p-remove-ors (or-list) 
  (if (null or-list) nil
    (if (p-isor (first or-list)) ; nested OR
        (append (p-get-arguments (first or-list)) (p-remove-ors (rest or-list))) 
        (cons (first or-list) (p-remove-ors (rest or-list)))
    )
  )
)

(defun p-neg-NNF (p) ; transforms (and A B) into (or -A -B), similary for "or" and "not"
  (cond ((p-isbot p) TOP)
	    ((p-istop p) BOT)
	    ((p-isemptyand p) BOT)
	    ((p-isemptyor p) TOP)
	    ((p-isletter p) (p-mknot p))
	    (t (case (first p)
	             (not  (p-NNF (p-get-argument p)))
	             (and  (p-or-NNF  (mapcar #'p-neg-NNF (p-get-arguments p))))
	             (or   (p-and-NNF (mapcar #'p-neg-NNF (p-get-arguments p)))) 
	       )
	    )
   )
)


;;--------------------------------------------------------------------------- 
;;p-structural-equiv(p1 p2):
;;INPUT:   pi = two propositional expressions
;;RETURN:  true iff p1 is structurally equivalent to p2 according the 
;;         following inductive definition of equiv
;;
;;         letter1 equiv letter2 if letter1 = letter2
;;         (not A1) equiv (not A2) iff A1 equiv A2
;;         (and A1 ... An) equiv (and B1 ... Bm) 
;;             iff n=m and (for all Ai there is Bj such that Ai equiv Bj)
;;         (or A1 ... An) subs (or B1 ... Bm) 
;;             iff n=m and (for all Ai there is Bj such that Ai equiv Bj)
;;
;;--------------------------------------------------------------------------- 


(defun p-structural-equiv (p1 p2)
  (progn
     (cond ((and (p-isletter p1) 
                 (p-isletter p2))
            (equal p1 p2)
           ) 
           ((and (p-isnot p1) 
                 (p-isnot p2))
            (p-structural-equiv (p-get-argument p1) (p-get-argument p2))
           )
           ((or (and (p-isand p1)
                     (p-isand p2)
                     (= (length p1) (length p2))
                )
                (and (p-isor p1)
                     (p-isor p2)
                     (= (length p1) (length p2))
                )
            ) 
            ;;; for all ... there is ..
            (every     
                #'(lambda (x) 
                      (some #'(lambda (y) (p-structural-equiv x y)) 
                            (p-get-arguments p2)
                      ))
                (p-get-arguments p1)
            )
           )     
           (t nil)
     )          
  )
)

;;--------------------------------------------------------------------------- 
;;p-structural-subs(p1 p2):
;;INPUT:   pi = two propositional expressions
;;RETURN:  true iff p1 is subsumed by p2, p1 <= p2 according the 
;;         following inductive definition of <=
;;
;;         letter1 <= letter2 if letter1 = letter2
;;         (not A1) <= (not A2) iff A1 <= A2
;;         (and A1 ... An) <= (and B1 ... Bm) 
;;             iff (for all Bi there is Aj such that Aj <= Bi)
;;         (or A1 ... An) <= (or B1 ... Bm) 
;;             iff (for all Bi there is Aj such that Aj <= Bi)
;;
;;--------------------------------------------------------------------------- 


(defun p-structural-subs (p1 p2)
  (progn
     (cond ((and (p-isletter p1) 
                 (p-isletter p2))
            (equal p1 p2)
           ) 
           ((and (p-isnot p1) 
                 (p-isnot p2))
            (p-structural-equiv (p-get-argument p1) (p-get-argument p2))
           )
           ((or (and (p-isand p1)
                     (p-isand p2)
                )
                (and (p-isor p1)
                     (p-isor p2)
                )
            ) 
            ;;;; for all ... there is ..
            (every     
                #'(lambda (x) 
                      (some #'(lambda (y) (p-structural-subs y x)) 
                            (p-get-arguments p1)
                      ))
                (p-get-arguments p2)
            )
           )     
           (t nil)
     )          
  )
)

;;--------------------------------------------------------------------------- 
;;p-remove-taut-ctd (p):
;;INPUT:   p = propositional expression in NNF from p-NNF(p)
;;RETURN:  simplifies p according to
;;  
;;         (and ..BOT...) |- BOT 
;;         (and ... A ... (not A) ...) |- BOT
;;              
;;         (or ..TOP...) |- TOP 
;;         (or ... A ... (not A) ...) |- TOP
;;              
;;--------------------------------------------------------------------------- 

(defun p-remove-taut-ctd (p)
  (cond 
    ((or (p-isletter p) 
         (p-isnot p))    
     p)
    ((p-isand p) (p-and-remove-taut-ctd (p-get-arguments p)))
    ((p-isor p)  (p-or-remove-taut-ctd  (p-get-arguments p)))
  )
)

(defun p-and-remove-taut-ctd (p)   ; handles list of arguments of an AND
  (progn
    (setq land-tmp (delete TOP (mapcar #'p-remove-taut-ctd p)))
    (if land-tmp  ; not nil list
        (if (member BOT land-tmp)   ; there is a BOT in the AND
            BOT ; otherwise look for conjugated pairs
            (if (>= (length land-tmp) 2)
                (if (p-there-is-conjugated-pair land-tmp)   ; there is A and (not A) in AND
                    BOT
                    (p-mkand land-tmp)
                )    
                (car land-tmp)
            ) 
        )
        TOP    ; all TOP has been eliminated.
     )   
  )
)

(defun p-there-is-conjugated-pair (lp)   ; checks whether A and (not A) are in lp
  (cond ((null lp) nil)
        ((p-isletter (first lp))
         (or (member (p-mknot (first lp)) (rest lp) :test #'equal)
             (p-there-is-conjugated-pair (rest lp))
         ))
        
      ((p-isnot (first lp))
       (or (member (p-get-argument (first lp)) (rest lp))
           (p-there-is-conjugated-pair (rest lp))
       ))
      (t (p-there-is-conjugated-pair (rest lp)))  
  )
)

(defun p-or-remove-taut-ctd (p)   ; handles list of arguments of an OR
  (progn
    (setq lor-tmp (delete BOT (mapcar #'p-remove-taut-ctd p)))
    (if lor-tmp  ; not nil list
        (if (member TOP lor-tmp)   ; there is a TOP in the OR
            TOP ; otherwise look for conjugated pairs
            (if (>= (length lor-tmp) 2)
                (if (p-there-is-conjugated-pair lor-tmp)   ; there is A and (not A) in OR
                    TOP
                    (p-mkor lor-tmp)
                )    
                (car lor-tmp)
            ) 
        )
        BOT    ; all BOT has been eliminated
    )
  )
)

;;--------------------------------------------------------------------------- 
;; p-simplify-iff (p)
;; Input: p  = a proposition
;; Return: result = reduce (if A B) and (iff A B) according the rule
;;         (iff A B) => (and (if A B) (if B A))
;;         (if A B)  => (or (not A) B)
;;---------------------------------------------------------------------------

(defun p-simplify-iff (p)
 (cond ((null p) nil)
       ((p-isif p)   ; is an if
        (p-mkor (list
                     (p-simplify-iff (p-mknot (first (p-get-arguments p))))
                     (p-simplify-iff (second  (p-get-arguments p)))))
       )
       ((p-isiff p)    ; is an iff
        (p-mkand (list
                      (p-simplify-iff 
                        (p-mkif (list (first  (p-get-arguments p))
                                      (second (p-get-arguments p)))))
                      (p-simplify-iff 
                        (p-mkif (list (second (p-get-arguments p))
                                      (first  (p-get-arguments p)))))))
       )
       ((p-isletter p) p)
       ((p-isnot p) (p-mknot (p-simplify-iff (p-get-argument p))))
       (t (cons (p-get-operant p) (mapcar #'p-simplify-iff (p-get-arguments p))))   
 )
)

;;--------------------------------------------------------------------------- 
