#+ALLEGRO 
(defmacro time-bound (seconds expression)
  `(mp:with-timeout 
     (,seconds . ((format t "B ~9,2F  100000  1000000 ~9,2F",
                   *timeout*,*timeout*))) ,expression))


#+ALLEGRO 
(defun bounded_test_sat (p) 
 (progn
  (setq %effective-time% 0.0)
  (terpri)
;  (gbc t)                    ; GARBAGE COLLECTING
  (let ((t1 (get-internal-run-time)))
   (let ((ris  (time-bound *timeout* (sat-result (ksat-con p *rule_num*)))))
    (let ((deltat (float (/ (- (get-internal-run-time) t1) 
                            internal-time-units-per-second))))
     (if (null ris)
      nil
      (progn 
       (princ ris)
       (princ (format NIL " ~9,2F"  deltat ))
       (princ (format NIL "~8D ~8D ~9,2F" ;"~8D ~8D"  
                          %ass-cnt% 
                          (+ %h_dp-cnt% %l_dp-cnt%)
                          %effective-time%)) 
)))))))