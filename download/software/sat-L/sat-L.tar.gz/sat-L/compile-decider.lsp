;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% compile decide procedure                                                   %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; sat-functions
(compile-file "code/decider/sat-functions.lsp")

;; compile state-solver
(compile-file "code/decider/state-solver.lsp")

;; compile state-solver defs, user modified
(compile-file "code/decider/state-solver-defs.lsp")

;; compile state-solver fixed functions
(compile-file "code/decider/state-solver-fixed.lsp")

;; compile exec-state-solver
(compile-file "code/decider/exec-state-solver.lsp")

