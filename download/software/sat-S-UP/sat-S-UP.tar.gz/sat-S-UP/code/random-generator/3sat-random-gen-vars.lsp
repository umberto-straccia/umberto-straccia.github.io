; values for 3sat-random-gen.lsp

(defvar *neg_prob*)        ; ratio negative literals
(defvar *var_num*)         ; variable number
(defvar *and_br*)          ; and branching
(defvar *or_br*)           ; or branching
(defvar *literal_prob*)    ; ratio literals/propositions
(defvar *query_var_num*)   ; variable number for building queries
(defvar *sign_TT_prob*)    ; ratio signed TT formulas/signed NT formulas
(defvar *var_query_in_KB_prob*) ; probability that a variable used for
                                ; building a KB formula is also used
                                ; for building the query
(defvar *query_and_br*)    ; query and branching
(defvar *query_neg_prob*)  ; ratio negative query literals 
(defvar *query_or_br*)     ; query or branching

(defvar *MAX_NUM*)
(setq *MAX_NUM* 1000000)

; You have to set the parameters before calling 
; (get-random-proposition)
; to generate a random propositional formula. 
;
; According to the guidelines of Hustadt and Schmidt (IJCAI-97) 
; the parameters *or_br* and *literal_prob*
; should be set as follows:

(setq *or_br* 3)
;(setq *literal_prob* 0)   ; not used

; *neg_prob* should be 0.5
(setq *neg_prob* 0.5)

; The only parameters remaining are the number of propositional variables
; and the number of conjunctions in the formula.

(setq *var_num* 4)
(setq *and_br*  4)

;(setq *random-state* (make-random-state t))

; Setting ratio of TT signed formulas
(setq *sign_TT_prob* 0.5)

; Setting parameters for queries
(setq *var_query_in_KB_prob* 0.8)
(setq *query_var_num* 4) 
(setq *query_and_br*  4)
(setq *query_or_br* 3)

; *query_neg_prob* should be 0.5
(setq *query_neg_prob* 0.5)