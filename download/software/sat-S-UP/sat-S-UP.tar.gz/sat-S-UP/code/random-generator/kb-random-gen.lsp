;;--------------------------------------------------------------------------------------------
;; generate-n-random-KB  (howmany num-prop Lp-start Lp-end Lp-step numvar clause-len neg-prob
;;                   sign-prob sigma-f lengths-array-constr bin prob folder-name filename-prefix)
;;
;; Input : howmany                  ; howmany random KBs you want generate
;;         num-prop 
;;         Lp-start Lp-end Lp-step  ; range of proposition's length
;;	   numvar  		    ; number of propositional variables
;;         clause-len    	    ; clause length
;;         neg-prob 		    ; probability of negating a letter
;;         sign-prob     	    ; probability by which a proposition is signed TT
;; 	   sigma-f 		    ; distribution function to be used (see at the bottom of file)
;;	   lengths-array-constr     ; function to build an array of lengths
;;	   bin 			    ; flag : if true binomial distribution is used
;;	   prob                     ; probability used with binomial distribution 
;;	   folder-name              ; path of directory where function must store KBs 
;;				      (path must be a string ending with /)
;;         filename-prefix	    ; prefix file's names 
;; Return : stores the KBs generate in the directory folder-name 
;;
;;--------------------------------------------------------------------------------------------

(defun generate-n-random-KB 
  (howmany num-prop Lp-start Lp-end Lp-step numvar clause-len neg-prob sign-prob sigma-f lengths-array-constr bin prob folder-name filename-prefix)
 (progn
   (setq *var_num* numvar) 
   (setq *or_br* clause-len)
   (setq *neg_prob* neg-prob)
   (setq *sign_TT_prob* sign-prob)
   (setq Lv (funcall lengths-array-constr Lp-start Lp-end Lp-step)) ; builts an array of lengths	   
   (setq PbyLv (prop-by-length-array-constr sigma-f Lv num-prop prob))
   (if bin (progn
	     (setq pnp (reduce #'+ PbyLv :initial-value 0)) 
             (update-np-array num-prop pnp PbyLv prob)
	   )
   )  
   (do ((i 1 (+ i 1)))
       ((> i howmany) 'DONE)
       (setq kb_file (open (concatenate 'string folder-name filename-prefix (write-to-string i) ".txt")
                              :direction :output))
       (print-KB (gen-one-random-KB Lv PbyLv) kb_file)
       (close kb_file)
   )
 )
)

(defun gen-one-random-KB 
  (Lv PbyLv)
 (progn  
   (setq KB ()) 
   (do ((j 0 (+ j 1)) (lvd (array-dimension Lv 0)))
       ((> j (- lvd 1)))
       (setq Lp (svref Lv j))
       (setq Np (svref PbyLv j))
       (do ((n 1 (+ n 1)))
	   ((> n Np))
	   (push (gen-rand-s-prop Lp) KB)
       )
   )
   KB  ;returned KB
 )
)

(defun len-array-constr (Lp-start Lp-end Lp-step)
  (progn
    (setq dim (+ 1 (/ (- Lp-end Lp-start) Lp-step)))
    (make-array dim 
  	    :initial-contents 
  	      (do ((i 0 (+ i 1)) (seq ())) 
       	          ((>= i dim) seq) 
  		  (setq seq (append seq `(,(+ Lp-start (* i Lp-step)))))
  	      )        
    )
   )
)    

(defun prop-by-length-array-constr (sigmaf lv np prob)
  (progn 
    (setq dim (array-dimension lv 0))
    (make-array dim 
  	        :initial-contents 
  	          (do ((i 0 (+ i 1)) (seq ())) 
       	              ((>= i dim) (reverse seq)) 
  		      (push (funcall sigmaf i np dim prob) seq)
  	          )
    )
  )
)

(defun update-np-array (lkb p-in pvec p)
  (progn
    (setq missing-f (- lkb p-in))
    (setq pvec-dim (array-dimension pvec 0))
    (if (and (not (zerop missing-f)) (<= missing-f pvec-dim))
	(progn
	   (cond ((<= p 0.3)
	          (setq index 0)
                 )
	         ((< p 0.7)  ;remember that p > 0.3 holds here
	          (setq index (floor (/ (- pvec-dim missing-f) 2)))
	         )
	         (t (setq index (- pvec-dim missing-f)))  ;remember that p >= 0.7 holds here
           )
	   (do ((n 0 (+ n 1)))
	       ((> n (- missing-f 1)))
	       (incf (svref pvec (+ index n)))	     
	   )
	)
    )
  )
)

;;require loading of "tartaglia.lsp" file
(defun sigmafbin (k lkb lvdim prob)
  (progn
    (setq bin-coeff (get-n-k *tr_tar* lvdim k))
    (setq first-t (expt prob k))
    (setq second-t (expt (- 1 prob) (- lvdim k)))
    (floor (* lkb bin-coeff first-t second-t))
  )
)

(defun sigmaf (k lkb lvdim prob)
  ;k,prob parameters not used here
  (/ lkb lvdim)
)

;(generate-n-random-KB 1 4 2 4 2 4 3 0.5 #'sigmaf #'len-array-constr nil 0 "/home/erato/antonio" "kbpr")

    
             
             
             
             
             
             
             
             
             
             
             
  
