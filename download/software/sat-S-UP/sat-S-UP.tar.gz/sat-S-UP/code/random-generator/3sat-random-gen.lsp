; ************************************************************
; Version:       1.0 (1997-02-26)
; Modifications: Ullrich Hustadt     1996-1997
;                Roberto Sebastiani
;                Enrico  Franconi
;                Umberto Straccia
; ************************************************************

; This is a propositional version of Hustadt's generator. 
; It generates random 3SAT propositions

; Declaration of parameters

;(load "3sat-random-gen-vars.lsp")

;--------------------------------------


;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% random propositional formulae generator
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;******************* general *************************************************

(defun get-3sat-random-proposition ()
  (let ((p (rand-conjunction-mak *and_br*)))
       (if (= 1 (length p))
           (car p)
           (p-mkand p)
       )
  )
)

;******************* make conjunction *********************************************

(defun rand-conjunction-mak (branch_rate)
 (cond
  ((equal branch_rate 0) NIL)
  ((equal branch_rate 1) (list (rand-disjunction-mak)))
  (T (cons (rand-disjunction-mak)
           (rand-conjunction-mak (- branch_rate 1))))))

;******************* make disjunction *********************************************

(defun rand-disjunction-mak ()
  (let ((p (rand-fixed-length-disjunction *or_br* NIL)))
       (if (= 1 (length p))
           (car p)
           (p-mkor p)
       )
  )
)

(defun rand-fixed-length-disjunction (branch_rate subterm-list)
 (cond
  ((equal branch_rate 0) NIL)
  ((equal branch_rate 1) (list (rand-literal-mak subterm-list)))
  (t (let ((subterm (rand-literal-mak subterm-list)))
       (cons subterm
	     (rand-fixed-length-disjunction (- branch_rate 1) 
					    		        (cons subterm subterm-list)))))))


;******************* literals *****************************************************

(defun rand-literal-mak (subterm-list)
  (let ((letter (p-mknumletter (+ 1 (random *var_num*)))))
    (if (or (member letter subterm-list :test #'equal)
	        (member (p-mknot letter) subterm-list :test #'equal))
	    (rand-literal-mak subterm-list)
        (if (rand-event *neg_prob*)
	        (p-mknot letter)
	        letter))))



;******************* random event ****************************************

;;returns T with probability prob, NIL with prbability 1-prob;
(defun rand-event (prob) (> (* prob *MAX_NUM*) (random *MAX_NUM*) ))

;***********************************************************


;-------------------------------------------------------------------------------------------
; Begin of definitions added by Antonio Lopreiato
;-------------------------------------------------------------------------------------------


;****************** make a signed formula **********************************


;; returns (TT p) with prob *sign_TT_prob*, (NT p) with prob (1-*sign_TT_prob*)
;; where p is an unsigned (random) proposition

(defun get-3sat-rand-signed-formula ()
     (if (rand-event *sign_TT_prob*) 
     	     (s-p-mkTT (get-3sat-random-proposition))
     	     (s-p-mkNT (get-3sat-random-proposition))
     )
)


(defun gen-rand-s-prop (num-clause)
   (progn
      (setq *and_br* num-clause)
      (get-3sat-rand-signed-formula)
    )
)


;****************** make a query *******************************************

(defun gen-rand-query (len)
  (progn
     ; saves parameters for generating random propositions
     (setq backup-var-num *var_num*)
     (setq backup-or-br *or_br*)
     (setq backup-neg-prob *neg_prob*) 
     ;sets parameters for generating random queries    
     (setq *var_num* *query_var_num*)
     (setq *or_br* *query_or_br*)
     (setq *neg_prob* *query_neg_prob*)
     (setq *query_and_br* len)
     ;builts random query
     (setq q (s-p-mkNT (p-mkand (rand-conjunction-mak *query_and_br*))))
     ;restores parameters for generating random propositions
     (setq *var_num* backup-var-num)
     (setq *or_br* backup-or-br)
     (setq *neg_prob* backup-neg-prob)
     q  ; returns query
   )
 )