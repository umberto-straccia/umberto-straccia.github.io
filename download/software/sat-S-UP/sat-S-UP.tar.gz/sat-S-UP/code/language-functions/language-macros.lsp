;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% macro definitions for propositional language L                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 

(defconstant TOP '*top*)
(defconstant BOT '*bot*)

;;--------------------------------------------------------------------------- 

(defmacro p-get-operant (p)   `(car ,p))   ;get the operant of p
(defmacro p-get-argument (p)  `(cadr ,p))  ;get the argument of unary operant
(defmacro p-get-arguments (p) `(rest ,p))  ;get the arguments of n-ary operant

;;--------------------------------------------------------------------------- 

(defmacro p-istop (p)       `(equal ,p TOP))
(defmacro p-isbot (p)       `(equal ,p BOT))
(defmacro p-isletter (p)    `(and (symbolp ,p) 
                                  (not (equal ,p 'not))
                                  (not (equal ,p 'and))
                                  (not (equal ,p 'or))   
                             ))
(defmacro p-isvar (p)       `(and (symbolp ,p) 
                                  (not (equal ,p 'not))
                                  (not (equal ,p 'and))
                                  (not (equal ,p 'or)) 
                                  (not (equal ,p BOT))
                                  (not (equal ,p TOP))  
                             ))                                  
(defmacro p-isnot (p)       `(and (listp ,p)
                                  (= (length ,p) 2) 
                                  (equal (p-get-operant ,p) 'not)))
(defmacro p-isand (p)       `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'and)))
(defmacro p-isemptyand (p)  `(equal p '(and)))
(defmacro p-isor (p)        `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'or)))
(defmacro p-isemptyor (p)   `(equal p '(or)))

(defmacro p-isif (p)        `(and (listp ,p)
                                  (= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'if)))
(defmacro p-isiff (p)        `(and (listp ,p)
                                   (= (length ,p) 3) 
                                   (equal (p-get-operant ,p) 'iff)))
                                  

;;--------------------------------------------------------------------------- 

(defmacro p-mktop ()       'TOP)
(defmacro p-mkbot ()       'BOT)
(defmacro p-mknot (p)      `(list 'not ,p))
(defmacro p-mkand (land)   `(cons 'and ,land))
(defmacro p-mkor  (lor)    `(cons 'or  ,lor))
(defmacro p-mkif  (lif)    `(cons 'if  ,lif))
(defmacro p-mkiff  (liff)  `(cons 'iff  ,liff))

(defun p-mknumletter (num) (intern (concatenate 'string "p" (write-to-string num))))


;;---------------------------------------------------------------------------
;; Begin of definitions added by Antonio Lopreiato
;;---------------------------------------------------------------------------

(defconstant TT '*TT*)   ; positive sign
(defconstant NT '*NT*)   ; negative sign


;; s-p-mkTT (p) macro
;;
;; input : a propositional formula, p
;;
;; output: a signed formula, (*TT* p)
;;
;; s-p-mkNT (p) macro do same thing returning (*NT* p)
;;

(defmacro s-p-mkTT (p) `(list TT ,p))
(defmacro s-p-mkNT (p) `(list NT ,p))

;; macro s-p-get-sign (s-p)
;;
;; input  : a signed formula s-p 
;;
;; output : TT if s-p is (*TT* p), NT if s-p is (*NT* p)
;;
;;---------------------------------------------------------------------------
;; macro s-p-getpropos (s-p)
;;
;; input : an s-p signed proposition e.g. (*TT* p) 
;;
;; output: the proposition p without sign


(defmacro s-p-getsign (s-p) `(car ,s-p))
(defmacro s-p-getpropos (s-p) `(cadr ,s-p))


(defmacro s-p-isTT (s-p) `(equal TT (s-p-getsign ,s-p)))
(defmacro s-p-isNT (s-p) `(equal NT (s-p-getsign ,s-p)))


;;--------------------------------------------------------------------------- 
;; make-TT-p-list (p-list)
;; 
;; input : p-list, a list of unsigned propositions 
;;
;; output: same list, where propositions have been signed with TT
;;
;;--------------------------------------------------------------------------- 


(defun make-TT-p-list (p-list)
  (progn
    (setq result ())
    (setq result-tmp ())
    (dolist (arg p-list)
	    (pushnew (s-p-mkTT arg) result-tmp)
	    )
    (setq result result-tmp)
    )
)


;;--------------------------------------------------------------------------- 
;; make-NT-p-list (p-list)
;; 
;; input : p-list, a list of unsigned propositions 
;;
;; output: same list, where propositions have been signed with NT
;;
;;--------------------------------------------------------------------------- 


(defun make-NT-p-list (p-list)
  (progn
    (setq result ())
    (setq result-tmp ())
    (dolist (arg p-list)
	    (pushnew (s-p-mkNT arg) result-tmp)
	    )
    (setq result result-tmp)
    )
)


(defun get-literals-from-prop (prop)
  (progn
    (setq prop-lit ())
    (setq clausel (p-get-arguments prop))
    (dolist (clause clausel)
	      (if (or (p-isletter clause) (and (p-isnot clause) (p-isletter (p-get-argument clause))))
		   (pushnew clause prop-lit)
	      )
    )
    prop-lit
  )
)
	 