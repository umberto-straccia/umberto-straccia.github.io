;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Executes test                                                           %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; execute test with
;; (exec-test 100 4 120 4 4) 
; (exec-test 3 4 8 4 4) ; test

;;--------------------------------------------------------------------------- 
;; exec-test (samples-per-point num-cl-start num-cl-end step nvar)
;; Input: 
;;       samples-per-point            ;; number of samples/point
;;       num-cl-start                 ;; number of clauses : start
;;       num-cl-end                   ;; number of clauses : end
;;       step                         ;; number of clauses : step
;;       nvar                         ;; number of variables
;;
;; Return: prints in *wff-file* the test propositions
;;         prints in *result-file* the test results, in he form
;;         <sat-value> <number-of-states> <time>
;;
;;         where <sat-value> is S (satisfiable), U (not satisfiable)
;;               <number-of-states> is the number of states created
;;               <time> is the time required
;;
;;---------------------------------------------------------------------------

(defun exec-test (samples-per-point num-cl-start num-cl-end step nvar)
 (progn
   (setq *var_num* nvar)
   (setq *result-stream* (open *result-file* :direction :output))
   (setq *wff-stream* (open *wff-file* :direction :output))
   (print-header samples-per-point num-cl-start num-cl-end step)
   (do ((n_cl num-cl-start (+ n_cl step))) ; for each number of clauses
       ((>= n_cl (+ step num-cl-end)))
       (print-clauses-num n_cl)
       (setq *and_br* n_cl)   ; new number of and operants 
       (do ((j 0 (+ j 1))) 
           ((= j samples-per-point))
           (generate_and_test)
       )
   )
   (close  *result-stream*) 
   (close  *wff-stream*) 
 )
)
;;--------------------------------------------------------------------------- 
;; exec-LI-test (kbs-dir ext num-query num-cl-start num-cl-end step nvar)
;; Input:
;;       kbs-dir          ;; the path of directory where lie KBs
;;       ext		  ;; flag : if true the test is maked with an extended kb
;;       num-query        ;; number of samples/point
;;       num-cl-start     ;; number of clauses : start
;;       num-cl-end       ;; number of clauses : end
;;       step             ;; number of clauses : step
;;       nvar             ;; number of variables
;;
;; Return: prints in *wff-file* the test queries
;;         prints in *result-file* the test results, in he form
;;         <sat-value> <number-of-states> <time>
;;
;;         where <sat-value> is S (satisfiable), U (not satisfiable)
;;               <number-of-states> is the number of states created
;;               <time> is the time required
;;
;;---------------------------------------------------------------------------

(defun exec-LI-test (kbs-dir exp num-query num-cl-start num-cl-end step nvar)
 (progn 
   (setq kb-files (getfiles kbs-dir))
   (setq *var_num* nvar)  
   (setq *result-stream* (open *result-file* :direction :output))
   (setq *wff-stream* (open *wff-file* :direction :output))
   (if exp 
       (and (print-header-ext num-query num-cl-start num-cl-end step)
            (setq test-fun #'test-LI-with-exp-KB)) 
       (and (print-header num-query num-cl-start num-cl-end step)
            (setq test-fun #'test-LI))
   )
   (dolist (file-arg kb-files)
        (setq str (open file-arg :direction :input))
        (funcall test-fun (read str nil 'eof) num-query num-cl-start num-cl-end step nvar)  
        (close str)
   )
   (close  *result-stream*) 
   (close  *wff-stream*)
 )
)

;;--------------------------------------------------------------------------- 
;; exec-KB-test (kbs-dir) 
;; Input: kbs-dir ;; the path of directory where lie KBs 
;;
;; Return: prints in *result-file* the test results, in he form
;;         <sat-value> <number-of-states> <time>
;;
;;         where <sat-value> is S (satisfiable), U (not satisfiable)
;;               <number-of-states> is the number of states created
;;               <time> is the time required
;;
;;---------------------------------------------------------------------------

(defun exec-KB-test (kbs-dir) 
 (progn
   (setq kb-files (getfiles kbs-dir))
   (setq *result-stream* (open *result-file* :direction :output))
   (setq *wff-stream* (open *wff-file* :direction :output))
   (princ 
     (format nil 
       "<Sat result> ~3A ~
        <Number of States> ~3A ~
        <Time> ~3A ~%"
        "" "" "")
      *result-stream*)
   )
   (dolist (file-arg kb-files)
        (setq str (open file-arg :direction :input))
        (test_sat_kb (read str nil 'eof))  
        (close str)
   )
   (close  *result-stream*) 
   (close  *wff-stream*)
 )
)

(defun generate_and_test ()
 (let ((p (get-3sat-rand-signed-formula)))
  (progn
   (print-wff p)
   (if *execute_test* 
      (if (null *timeout*)
          (test_sat p)
          (bounded_test_sat p)
      )
   )
  )
 )
)


(defun test_sat (s-p) 
 (progn
  (setq *number-of-states* 0)
  (gc t)                    ; GARBAGE COLLECTING
  (setq t1 (get-internal-run-time))
  (setq result (s-p-sat-exec (list s-p)))
  (setq t2 (get-internal-run-time))
  (setq deltat (float (/ (- t2 t1) 
                         internal-time-units-per-second
                      )
               )
  )
  (print-sat result deltat)
  )
)


(defun test_sat_kb (kb) 
 (progn
  (setq *number-of-states* 0)
  (gc t)                    ; GARBAGE COLLECTING
  (setq t1 (get-internal-run-time))
  (setq result (s-p-sat-exec kb))
  (setq t2 (get-internal-run-time))
  (setq deltat (float (/ (- t2 t1) 
                         internal-time-units-per-second
                      )
               )
  )
  (print-sat result deltat)
  )
)

(defun test-LI-with-exp-KB (kb num-query num-cl-start num-cl-end step nvar)
  (progn
   (gc t)                    ; GARBAGE COLLECTING
   (setq ti (get-internal-run-time))
   (setq ml (mapcar #'make-TT-p-list (s-p-kb-get-all-models kb))))
   (setq tf (get-internal-run-time))
   (setq deltatm (float (/ (- tf ti) 
                         internal-time-units-per-second
                      )
               )
   )
   (print-model-info ml deltatm)  
   (do ((n_cl num-cl-start (+ n_cl step))) ; for each number of clauses
       ((>= n_cl (+ step num-cl-end)))
       (print-clauses-num n_cl)
       (setq *and_br* n_cl)   ; new number of and operants 
       (do ((j 0 (+ j 1))) 
           ((= j num-query))
           (setq q (s-p-mkNT (get-3sat-random-proposition)))
           (print-wff q)
           (test-logic-impl ml q)
       )
   )  
 )
)

(defun test-logic-impl (ml q)
 (progn
   (setq *number-of-states* 0)
   (gc t)                    ; GARBAGE COLLECTING
   (setq t1 (get-internal-run-time))
   (setq result (s-logic-impl-exec ml q))
   (setq t2 (get-internal-run-time))
   (setq deltat (float (/ (- t2 t1) 
                         internal-time-units-per-second
                      )
               )
   )
   (print-sat result deltat)
 )
)

(defun test-LI (kb num-query num-cl-start num-cl-end step nvar)
  (progn   
   (do ((n_cl num-cl-start (+ n_cl step))) ; for each number of clauses
       ((>= n_cl (+ step num-cl-end)))
       (print-clauses-num n_cl)
       (setq *and_br* n_cl)   ; new number of and operants 
       (do ((j 0 (+ j 1))) 
           ((= j num-query))
           (setq q (s-p-mkNT (get-3sat-random-proposition)))
           (print-wff q)
           (setq kb&q (cons q kb))
           (test_sat_kb kb&q)
       )
   )
 )
)

;----------------------------------------------------------------------------










