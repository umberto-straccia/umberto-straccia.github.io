;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% My tests                                                                %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; execute test with
;; should be
;; (exec-test 100 *var_num* (* 40 *var_num*) *var_num* *var_num*) 
 (exec-test 100 4 120 4 4)     ; real test
 
; (exec-test 3 4 8 4 4) ; toy test

;; Examples of KB tests :

;; case of binomial distribution and no query
(KB-exec-test 50 12 80 4 8 16 4 0 0 0 0 *var_num* 0.5 #'sigmaKB #'sigmaf #'len-array-constr t *result-file* *wff-file*)

;; case of uniform distribution and no query
(KB-exec-test 50 12 80 4 8 16 4 0 0 0 0 *var_num* 0.5 #'sigmaKB #'sigmaf1 #'len-array-constr nil *result-file* *wff-file*)

;; case of one-length formulas and no query
(KB-exec-test 50 12 80 4 8 16 4 0 0 0 0 *var_num* 0.5 #'sigmaKB #'sigmaf2 #'len-array-constr-1 nil *result-file* *wff-file*)

; simple run (again with binomial distribution and no query)
;(KB-exec-test 3 3 6 3 2 6 2 0 0 0 0 *var_num* 0.5 #'sigmaKB #'sigmaf #'len-array-constr t *result-file* *wff-file*)
