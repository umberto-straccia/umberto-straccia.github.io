;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;;--------------------------------------------------------------------------- 
;; p-sat-exec (p-list)
;; Input: list of  propositions, i.e. a KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	          6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT s-p-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun p-sat-exec (p-list)
   (progn
        (setq s-p-list (make-TT-p-list p-list))
        (s-p-sat-exec s-p-list)
   )
)

;;--------------------------------------------------------------------------- 
;; p-all-models-exec (p-list)
;; Input: list of  propositions, i.e. a KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT sp-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun p-all-models-exec (p-list)
   (progn
        (setq s-p-list (make-TT-p-list p-list))
        (s-p-all-models-exec s-p-list)
   )
)

;;--------------------------------------------------------------------------- 
;; p-state-solver (p-list 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of propositions, i.e. a KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun p-state-solver (p-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
   (progn
        (setq s-p-list (make-TT-p-list p-list))
        (s-p-state-solver s-p-list 
                          get-new-states-fn
                          closed-state-fn
                          termination-fn
                          get-result-fn)
   )
)

;-----------------------------------------------------------------------------
; Begin of definitions added by Antonio Lopreiato
;-----------------------------------------------------------------------------

;; (defvar *set-calculus* 2)
;; you use *set-calculus* global variable to set the type of calculus 
;; which can be two-value (default) or four-value

(defvar *set-calculus* 2)

;;--------------------------------------------------------------------------- 
;; s-p-sat-exec (s-p-list)
;; Input: list of signed propositions, i.e. a KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	          6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT s-p-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun s-p-sat-exec (s-p-list)
   (if (= *set-calculus* 2)
          (s-p-state-solver   s-p-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (s-p-state-solver   s-p-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)

;;--------------------------------------------------------------------------- 
;; multistates-s-p-sat-exec (kbl)
;; Input: list of list of signed propositions, i.e. a list of KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	          6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT kbl.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 


(defun multistates-s-p-sat-exec (kbl)
  (if (= *set-calculus* 2)
          (multistates-s-p-state-solver kbl             ; initial states
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (multistates-s-p-state-solver kbl             ; initial states
                              #'sat-get-new-states      ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
  )
)

;;--------------------------------------------------------------------------- 
;; s-p-all-models-exec (s-p-list)
;; Input: list of signed  propositions, i.e. a KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT sp-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun s-p-all-models-exec (s-p-list)
   (if (= *set-calculus* 2)
          (s-p-state-solver   s-p-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (s-p-state-solver   s-p-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)

;;--------------------------------------------------------------------------- 
;; multistates-s-p-all-models-exec (kbl)
;; Input: list of list of signed  propositions, i.e. a list of KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT kbl.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun multistates-s-p-all-models-exec (kbl)
   (if (= *set-calculus* 2)
          (multistates-s-p-state-solver kbl             ; initial states
                              #'sat-get-new-states   ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (multistates-s-p-state-solver kbl             ; initial states
                              #'sat-get-new-states   ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)

;;--------------------------------------------------------------------------- 
;; s-p-state-solver (s-p-list 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of signed propositions, i.e. a KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun s-p-state-solver (s-p-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       ;(setq s-p-list (mapcar #'s-p-simplify-iff s-p-list))  ; replace IF and IFF
       (setq s-p-list (mapcar #'s-p-simplify s-p-list))  ; reduce every proposition in p-list in NNF
       ; build first state, the case of multiple initial states is similar
       (setq newstate (sat-initial-state-make s-p-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver (list newstate)        ; initial state
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

;;--------------------------------------------------------------------------- 
;; multistates-s-p-state-solver (kbl 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of list of signed propositions, i.e. a list of KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun multistates-s-p-state-solver (KB-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       ; reduce every proposition in p-list in NNF
       (setq KB-list (mapcar #'(lambda (kb) (mapcar #'s-p-simplify kb)) KB-list))  
       ; build first state, the case of multiple initial states is similar
       (setq newstates (mapcar #'sat-initial-state-make KB-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver newstates              ; initial states
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

;;---------------------------------------------------------------------------
;; s-logic-impl-exec (s-m-list s-p)
;;
;; Input : a list of signed Herbrand's models, s-m-list, 
;;         and a signed proposition, s-p
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	              6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT p-list.
;;         lcompleted-states = one completed state
;;---------------------------------------------------------------------------

(defun s-logic-impl-exec (s-m-list s-p)
  (if (null s-m-list)
      nil
      (multistates-s-p-sat-exec (mapcar #'(lambda (m) (cons s-p m)) s-m-list)) 
  )
)

;;---------------------------------------------------------------------------
;; s-models-logic-impl-exec (s-m-list s-p)
;;
;; Input : a list of signed Herbrand's models, m-list, 
;;         and a signed proposition, s-p
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT p-list.
;;         lcompleted-states = all completed states
;;---------------------------------------------------------------------------

(defun s-models-logic-impl-exec (s-m-list s-p)
 (if (null s-m-list)
      nil
      (multistates-p-all-models-exec (mapcar #'(lambda (m) (cons s-p m)) s-m-list)) 
  )
)




