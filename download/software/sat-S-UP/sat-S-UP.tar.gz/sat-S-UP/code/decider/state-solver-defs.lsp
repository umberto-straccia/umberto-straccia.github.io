;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Definitions and functions related to the Search Space algorithm         %                                         
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             % 
;%%%                                                                         %                    
;%%%                                                                         %
;%%% Modified, in order to implement calculus for signed proposition,        %
;%%% by Antonio Lopreiato                                                    %
;%%%                                                                         %
;%%% February, 20th 1998                                                     %
;%%%                                                                         %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;;---------------------------------------------------------------------------- 
;; number of states
;;--------------------------------------------------------------------------- 

(defvar *number-of-states* 0)

(defun init-number-of-states ()
   (setq *number-of-states* 0)
)

;;---------------------------------------------------------------------------- 
;; Sat state type definition

            
(defstruct sat-state
    id                            ; the key id for the state
    pred                          ; predecessor states
    succ                          ; succesor states
    (info nil :type sat-state-info)  ; our data information 
)

(defstruct sat-state-info
    andl                        ; list of ANDs
    orl                         ; list of ORs
    posl                        ; list of positive letters
    negl                        ; list of negative  letters
    nposl                       ; list of positive not's, i.e. (TT (not A))
    nnegl                       ; list of negative not's, i.e. (NT (not A))
    model                       ; model construction field
    modnposl                    ; model construction field
    modnnegl                    ; model construction field
    posl-modified               ; boolean = true iff posl modified
    negl-modified               ; boolean = true iff negl modified
    nposl-modified           ; boolean = true iff not-posl modified
    nnegl-modified           ; boolean = true iff not-negl modified
)




(defun sat-state-make (state info-arg)
 (progn
    (setq newid (incf *number-of-states*))
    (setf (sat-state-succ state) (push newid (sat-state-succ state)))
    (setq result (make-sat-state 
                    :id newid 
                    :pred (sat-state-id state)
                    :succ ()
                    :info info-arg))
    result ; returned value
                    
 )
)

(defun sat-initial-state-make (argl)
 (progn
    (setq result nil)
    (setq newid (incf *number-of-states*))
    (setq sat-state-info-tmp
            (sat-state-info-make-from-choice argl () () () () () () () () () nil nil nil nil))        
     
    (setq result (make-sat-state :id newid
                                 :pred ()
                                 :succ ()
                                 :info sat-state-info-tmp))
     result   ; returned result
 )
)

(defun sat-state-info-make 
 (andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg mod-arg modnposl-arg 
   modnnegl-arg posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)
 (make-sat-state-info  :andl andl-arg 
                       :orl  orl-arg 
                       :posl posl-arg 
                       :negl negl-arg 
                       :nposl not-posl-arg
                       :nnegl not-negl-arg
                       :model mod-arg
                       :modnposl modnposl-arg
                       :modnnegl modnnegl-arg
                       :posl-modified posl-modified-arg  
                       :negl-modified negl-modified-arg
                       :nposl-modified not-posl-modified-arg  
                       :nnegl-modified not-negl-modified-arg)
                                                   
)

;;--------------------------------------------------------------------------- 
;;
;; sat-state-info-from-choice
;; (arg-list andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg 
;;  posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)  
;;
;; input : arg-list which is a sub-signed-formula, other arguments are 
;;         informations on previous state 
;;
;; output: information field for new state
;;
;;--------------------------------------------------------------------------- 

(defun sat-state-info-make-from-choice 
  (arg-list andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg mod-arg modnposl-arg 
   modnnegl-arg posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)  
   (progn 
     (dolist (arg arg-list)        
     	(setq propos (s-p-getpropos arg))
	(if (s-p-isTT arg)
            (cond ((p-isvar propos)
	           (pushnew propos posl-arg)
		   (pushnew propos mod-arg)
		   (setq posl-modified-arg t)
		  )
		  ((p-isbot propos)
		   (pushnew propos posl-arg)
		   (setq posl-modified-arg t)		       
		  )
		  ((p-isnot propos)
		   (pushnew propos not-posl-arg)
		   (pushnew propos modnposl-arg)
		   (setq not-posl-modified-arg t)
		  )
		  ((p-isand propos)
		   (pushnew propos andl-arg)
		  )
		  ((p-isor propos)
		   (pushnew propos orl-arg)
		  )
	     )	
	     (cond ((or (p-isvar propos)
	                (p-istop propos))
	            (pushnew propos negl-arg)	               
	            (setq negl-modified-arg t)		       
		   )	        	        		           		
		   ((p-isnot propos)
		    (pushnew propos not-negl-arg)
		    (pushnew (p-get-argument propos) modnnegl-arg)
		    (setq not-negl-modified-arg t)
		   )
		   ((p-isand propos)
		    (pushnew propos orl-arg)
		   )
		   ((p-isor propos)
		    (pushnew propos andl-arg)
		   )
	     )
	 )
      )
        (setq result (sat-state-info-make 
                       andl-arg                               ; andl
                       orl-arg                                ; orl
                       posl-arg                               ; posl
                       negl-arg                               ; negl
                       not-posl-arg                           ; not-posl
                       not-negl-arg                           ; not-negl
                       mod-arg                                ; mod-arg
                       modnposl-arg
                       modnnegl-arg
                       posl-modified-arg                      ; posl-modified
                       negl-modified-arg                      ; negl-modified
                       not-posl-modified-arg                  ; not-posl-modified
                       not-negl-modified-arg                  ; not-negl-modified
                     )
	      )                  
        result
  )
)


;;--------------------------------------------------------------------------- 
;; sat-closed-state (state)
;; Input  : state = a state
;; Return : true iff state is closed
;;          a state is closed whenever either
;;          1. BOT is in posl
;;          2. TOP is in negl
;;          3. there is A in both posl and negl
;;
;;--------------------------------------------------------------------------- 
            
(defun 2V-sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info)            
              (sat-state-info-nposl-modified sat-info) 
              (sat-state-info-nnegl-modified sat-info))
            ; check return condition
            (setq result (2v-sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)
                              (sat-state-info-nposl sat-info)
                              (sat-state-info-nnegl sat-info)))            
            (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
)

(defun 4V-sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info)            
              (sat-state-info-nposl-modified sat-info) 
              (sat-state-info-nnegl-modified sat-info))
            ; check return condition
            (setq result (4v-sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)
                              (sat-state-info-nposl sat-info)
                              (sat-state-info-nnegl sat-info)))            
            (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
)

;; test for sat-closed-state 
;;

(defun 2V-sat-closed-state-test (pl nl npl nnl) 
 (let ((posl (concatenate 'list pl (mapcar #'(lambda (n) (p-get-argument n)) nnl)))
       (negl (concatenate 'list nl (mapcar #'(lambda (n) (p-get-argument n)) npl))))
      (or (member BOT posl)  ; false test
          (member TOP negl)  ; true test   
          ; check if there is complementary pair
          (some #'(lambda (x) (some #'(lambda (y) (equal x y)) negl)) posl)
      ) 
 )
) 

(defun 4V-sat-closed-state-test (pl nl npl nnl) 
 (or (member BOT pl)  ; false test
     (member TOP nl)  ; true test
     (member `(not ,TOP) npl)  ; false test
     (member `(not ,BOT) nnl)  ; true test
     ; check if there is complementary pair
     (some #'(lambda (x) (some #'(lambda (y) (equal x y)) nl)) pl)
     (some #'(lambda (x) (some #'(lambda (y) (equal x y)) nnl)) npl)
 )
) 

;;--------------------------------------------------------------------------- 
;; sat-get-new-states (state) 
;;
;; Input  : a state
;; Return : list of new states to be solved, generated from current-state
;;          applying the following simple rules. 
;;          Remember that the initial proposition should be in NNF.
;;
;;
;;                 T/NT (and/or A1 ... An)      by sustituting all Ai into positive
;;         (UP)  ----------------------------   letters list with TOP and all Ak into 
;;                T/NT (and/or Aj1 ... Ajm)     negative letters list with BOT and then
;;                                              simplifing the propoposition
;;
;;                T(and A1 ... An)                    
;;         (A)   ---------------------         
;;                T(A1), ... , T(An)                 
;;
;;
;;                 NT(or A1 ... An) 
;;         (A)   ---------------------    
;;                NT(A1), ... , NT(An)
;;     
;;
;;                        T(or A1 A2... An)
;;         (PB)  -------------------------------------           
;;               T(A1)     |    NT(A1), T(or A2 ... An)
;;
;;
;;
;;                        NT(and A1 A2... An)
;;         (PB)  ----------------------------------------           
;;               NT(A1)    |    T(A1), NT(and A2 ... An)
;;
;;
;;          the only branching rule is (PB).
;;          the priority between rules is  (UP) > (A) > (PB)
;;
;;--------------------------------------------------------------------------- 
               

(defun sat-get-new-states (state)
  (progn
    (setq result nil)
    (setq sat-info (sat-state-info state))
    (cond ((or (sat-state-info-posl-modified sat-info)
	       (sat-state-info-negl-modified sat-info)
	       (sat-state-info-nposl-modified sat-info)
	       (sat-state-info-nnegl-modified sat-info)
	   )	   
	   (setq result (unit-propagation state))
	  )
	  ((sat-state-info-andl sat-info)
	   (setq result (sat-and-get-new-states state))
	  )
	  ((sat-state-info-orl sat-info)       
	   (setq result (sat-or-get-new-states state))    
	  )
	  (t (setq result ()))
    )
    result
  )
)

(defun subst-sym (sym tosubstl plist)
  (let ((res plist))
       (mapcar #'(lambda (lit) (setq res (subst sym lit res :test #'equal))) tosubstl)
       res
  )
)

(defun unit-propagation (state)
 (progn
      (setq result nil)
      (setq info-tmp  (sat-state-info state))
      (setq andl-tmp  (sat-state-info-andl info-tmp))
      (setq orl-tmp   (sat-state-info-orl  info-tmp))
      (setq posl-tmp  (sat-state-info-posl info-tmp))
      (setq negl-tmp  (sat-state-info-negl info-tmp))
      (setq nposl-tmp  (sat-state-info-nposl info-tmp))
      (setq nnegl-tmp  (sat-state-info-nnegl info-tmp))
      (setq mod-tmp   (sat-state-info-model info-tmp))
      (setq modnposl-tmp   (sat-state-info-modnposl info-tmp))
      (setq modnnegl-tmp   (sat-state-info-modnnegl info-tmp))
      ;(setq posl-modified-tmp  nil)
      ;(setq negl-modified-tmp  nil)
      ;(setq nposl-modified-tmp  nil)
      ;(setq nnegl-modified-tmp  nil)
      (setq topl (concatenate 'list posl-tmp nposl-tmp))
      (setq botl (concatenate 'list nnegl-tmp negl-tmp))
      (setq and-args-tmp (subst-sym bot botl (subst-sym top topl andl-tmp)))
      (setq and-args (mapcar #'(lambda (p) 
                                  (if (p-isand p) 
                                     (s-p-mkTT (light-p-remove-taut-ctd p))
                                     (s-p-mkNT (light-p-remove-taut-ctd p))
                                  )) and-args-tmp))  
      (setq or-args-tmp (subst-sym bot botl (subst-sym top topl orl-tmp)))                             
      (setq or-args (mapcar #'(lambda (p) 
                                  (if (p-isand p) 
                                     (s-p-mkNT (light-p-remove-taut-ctd p))
                                     (s-p-mkTT (light-p-remove-taut-ctd p))
                                  )) or-args-tmp))
      (setq propl-args (concatenate 'list and-args or-args))     
      (setq sat-state-info-tmp
            (sat-state-info-make-from-choice
                propl-args
                ()                               
                ()                                
                ()                               
                ()
                ()
                ()  
                mod-tmp 
                modnposl-tmp
                modnnegl-tmp                            
                nil ;posl-modified-tmp                      
                nil ;negl-modified-tmp 
                nil ;nposl-modified-tmp                      
                nil ;nnegl-modified-tmp                     
            ))
      (setq result (sat-state-make state sat-state-info-tmp))        
      (list result)   ; returned list as result
 )
)

(defun sat-and-get-new-states (state)
  (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-nposl info-tmp))
    (setq not-negl-tmp  (sat-state-info-nnegl info-tmp))
    (setq mod-tmp   (sat-state-info-model info-tmp))
    (setq modnposl-tmp   (sat-state-info-modnposl info-tmp))
    (setq modnnegl-tmp   (sat-state-info-modnnegl info-tmp))
    ;(setq posl-modified-tmp nil)
    ;(setq negl-modified-tmp nil)
    ;(setq not-posl-modified-tmp nil)
    ;(setq not-negl-modified-tmp nil)
    (setq and-args ())
    (dolist (arg andl-tmp (setq andl-tmp ()))        
        (cond ((p-isand arg)
	       (setq and-args (concatenate 'list and-args (make-TT-p-list (p-get-arguments arg))))
	      )
	      ((p-isor arg)
               (setq and-args (concatenate 'list and-args (make-NT-p-list (p-get-arguments arg))))
	      )	     
        )
    )
    (setq sat-state-info-tmp
	  (sat-state-info-make-from-choice
	   and-args
	   andl-tmp                               ; andl
           orl-tmp                                ; orl
           posl-tmp                               ; posl
           negl-tmp                               ; negl
           not-posl-tmp                           ; not-posl
           not-negl-tmp                           ; not-negl
           mod-tmp                                ; model
           modnposl-tmp
           modnnegl-tmp
           nil ;posl-modified-tmp                      ; posl-modified
           nil ;negl-modified-tmp                      ; negl-modified
           nil ;not-posl-modified-tmp                  ; not-posl-modified
           nil ;not-negl-modified-tmp                  ; not-negl-modified
	  )
    )
    (setq result (sat-state-make state sat-state-info-tmp))
    (list result)
    )
  )


(defun sat-or-get-new-states (state)
 (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-nposl info-tmp))
    (setq not-negl-tmp  (sat-state-info-nnegl info-tmp))
    (setq mod-tmp   (sat-state-info-model info-tmp))
    (setq modnposl-tmp   (sat-state-info-modnposl info-tmp))
    (setq modnnegl-tmp   (sat-state-info-modnnegl info-tmp))
    ;(setq posl-modified-tmp nil)
    ;(setq negl-modified-tmp nil)
    ;(setq not-posl-modified-tmp nil)
    ;(setq not-negl-modified-tmp nil)       
    (setq p (first orl-tmp))
    (setq orl-tmp (rest orl-tmp))
    (cond ((p-isor p)
              (progn
	         (setq primo (first (p-get-arguments p)))
	         (setq resto (rest (p-get-arguments p)))
	         (setq arg (s-p-mkTT primo))
	         (setq notA1 (s-p-mkNT primo))	    
                 (if (= 1 (length resto))
                     (setq orA1 (s-p-mkTT (car resto)))                        
                     (setq orA1 (s-p-mkTT (p-mkor resto)))    
                 )  
	         ;(setq orA (p-mkor (push BOT resto)))   
                 ;(setq orA (p-simplify orA))   
	         ;(setq orA1 (s-p-mkTT orA))
	       )
	   )
	   ((p-isand p)
	       (progn
	          (setq primo (first (p-get-arguments p)))
	          (setq resto (rest (p-get-arguments p)))
	          (setq arg (s-p-mkNT primo))
	          (setq notA1 (s-p-mkTT primo))	        
                  (if (= 1 (length resto))
                      (setq orA1 (s-p-mkNT (car resto)))                        
                      (setq orA1 (s-p-mkNT (p-mkand resto)))    
                  )
	          ;(setq orA (p-mkand (push TOP resto)))   
                  ;(setq orA (p-simplify orA))	    
	          ;(setq orA1 (s-p-mkNT orA))
	       )
	   )
      )
      (setq sat-state-info-tmp1
            (sat-state-info-make-from-choice
                (list arg) 
                andl-tmp                               ; andl
                orl-tmp                                ; orl
	        posl-tmp                               ; posl
        	negl-tmp                               ; negl
	        not-posl-tmp                           ; not-posl
        	not-negl-tmp                           ; not-negl
        	mod-tmp
        	modnposl-tmp
                modnnegl-tmp
	        nil ;posl-modified-tmp                      ; posl-modified
                nil ;negl-modified-tmp                      ; negl-modified
                nil ;not-posl-modified-tmp                  ; not-posl-modified
                nil ;not-negl-modified-tmp                  ; not-negl-modified                    
            )
      )
      (setq sat-state-info-tmp2
            (sat-state-info-make-from-choice
                (list notA1 orA1) 
                andl-tmp                               ; andl
                orl-tmp                                ; orl
                posl-tmp                               ; posl
                negl-tmp                               ; negl
                not-posl-tmp                           ; not-posl
                not-negl-tmp                           ; not-negl
                mod-tmp
                modnposl-tmp
                modnnegl-tmp
                nil ;posl-modified-tmp                      ; posl-modified
                nil ;negl-modified-tmp                      ; negl-modified
                nil ;not-posl-modified-tmp                  ; not-posl-modified
                nil ;not-negl-modified-tmp                  ; not-negl-modified                    
            )
      )
      (setq newstate1 (sat-state-make state sat-state-info-tmp1))
      (setq newstate2 (sat-state-make state sat-state-info-tmp2))
      (list newstate1 newstate2) 
 )
)




;;--------------------------------------------------------------------------- 
;; sat-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun sat-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (or (null lopen-states)   ; no more states to be processed
                       (not (null lcompleted-states))))   ; there is a not closed completed branch
      result
 )
)  

;;--------------------------------------------------------------------------- 
;; sat-get-result (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a succesful search
;;--------------------------------------------------------------------------- 

(defun sat-get-result (lopen-states lclosed-states lcompleted-states)
 (progn
      ;; return true if there is a not closed and completed state S, i.e. 
      ;; S encodes a model 
      ;; 
      (setq result (not (null lcompleted-states)))
      result
 )
)

;;--------------------------------------------------------------------------- 
;; model-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun model-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (null lopen-states)) ; no more states to be processed
      result
 )
)  


;;--------------------------------------------------------------------------- 
;; sat-build-models (lcompleted-states)
;; Input  :  lists of completed states
;; Return : list of Herbrand models
;;---------------------------------------------------------------------------

(defun sat-build-models (lcompleted-states) 
  (if (= 2 *set-calculus*)
      (2V-sat-build-models lcompleted-states)
      (4V-sat-build-models lcompleted-states)
  )
)
  
(defun 2V-sat-build-models (lcompleted-states)
 (progn
      (cond ((null lcompleted-states) nil)
            (t (cons (concatenate 'list
                       (sat-state-info-model (sat-state-info (first lcompleted-states)))
                       (sat-state-info-modnnegl (sat-state-info (first lcompleted-states))))
                     (2V-sat-build-models (rest lcompleted-states)))
            )     
      
      )
 )
)
(defun 4V-sat-build-models (lcompleted-states)
 (progn
      (cond ((null lcompleted-states) nil)
            (t (cons (concatenate 'list
                        (sat-state-info-model (sat-state-info (first lcompleted-states)))
                        (sat-state-info-modnposl (sat-state-info (first lcompleted-states))))
                     (4V-sat-build-models (rest lcompleted-states)))
            )     
      
      )
 )
)


;;---------------------------------------------------------------------------

