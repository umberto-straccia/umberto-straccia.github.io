; ************************************************************
;hustadt_gen.lsp 

;variant "set" of the generator in "random_gen.lsp"

;written by Ullrich Hustadt     1996-1997

;modifications introduced by Roberto Sebastiani with respect to
;the file "genmodal.lsp":
;- added a prefix "UH_" to functions to distinguish them 
;  from the functions in "random_gen.lsp"
;- commented variables which are already defined elsewhere
;  (e.g. "*neg_prob*")
;- commented auxiliary functions which are already defined elsewhere
;  (e.g. "c-mknot")
; ************************************************************



; ************************************************************
; genmodal.lsp
; Version:       1.0 (1997-02-26)
; Modifications: Ullrich Hustadt     1996-1997
;                Roberto Sebastiani
;                Enrico  Franconi
;                Antonio Lopreiato
; ************************************************************

; Declaration of parameters

(defvar *neg_prob*)        ; ratio negative literals
(defvar *var_num*)         ; number of concept names 
(defvar *rule_num*)        ; number of distinct modalities (only for MK)
(defvar *and_br*)          ; and branching
(defvar *or_br*)           ; or branching
(defvar *prim_conc_prob*)  ; ratio primitive concepts/concepts
(defvar *mod_degree*)      ; modal depth
(defvar *num_individual*)  ; number of individuals )
(defvar *concept_ass_prob* 0.5) ;ratio concept/role assertions
(defvar *prob>=* 0.5)      ;ratio assertion of type (A <= n) / (A >= n)

; You have to set the parameters before calling 
; (UH_generate-rand-formula)
; to generate a random modal formula. 
;
; According to the guidelines of Hustadt and Schmidt (1997) 
; the parameters *rule_num*, *or_br*, *prim_conc_prob*, and *mod_degree*
; should be set as follows:

(setq *rule_num* 1)   ;number of role names 
(setq *or_br* 3)
(setq *prim_conc_prob* 0)
(setq *mod_degree* 1) 
(setq *num_individual* 4)

; *neg_prob* should be 0.5

(setq *neg_prob* 0.5)

; The only parameters remaining are the number of propositional variables
; and the number of conjunctions in the formula.

(setq *var_num* 4)
(setq *and_br*  4)

;(setq *random-state* (make-random-state t))

;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% random formulas ALC / K(n) generator
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;; Adapted from rseba@frege.mrg.dist.unige.it

;******************* general *************************************************

(defun get-fz-alc-random-assertion ()
 (let ((rel (if (UH_rand-event *prob>=*) '>= '<=)))
   (if (UH_rand-event *concept_ass_prob*)
       (list (rand-mk-concept-ass) rel (random 1.0))
       (list (rand-mk-role-ass) rel (random 1.0))
   )
 )
)

(defun rand-mk-individual ()
 (let ((num (1+ (random *num_individual*))))
    (mk-indname num))
)

(defun rand-mk-rolename ()
 (let ((num (1+ (random *rule_num*))))
    (mk-rolename num))
)

(defun rand-mk-role-ass ()
 (let ((role (rand-mk-rolename))
       (fst-ind (rand-mk-individual))
       (snd-ind (rand-mk-individual)))
       (mk-role-ass fst-ind snd-ind role))  
)

(defun rand-mk-concept-ass ()
 (let ((fst-ind (rand-mk-individual)))    
    (mk-concept-ass fst-ind (UH_generate-rand-formula)))
)


(defun UH_generate-rand-formula ()
  (let ((p (UH_rand-conj_clist-mak *and_br* *mod_degree*)))
       (if (= 1 (length p))
           (car p)
           (p-mkand p)
       )
  )
)

;******************* conjunction *********************************************

(defun UH_rand-conj_clist-mak (branch_rate grade)
 (cond
  ((equal branch_rate 0) NIL)
  ((equal branch_rate 1) (list (UH_rand-disj_conc-mak grade)))
  (T (cons (UH_rand-disj_conc-mak grade)
           (UH_rand-conj_clist-mak (- branch_rate 1) grade)))))

;******************* disjunction *********************************************

(defun UH_rand-disj_conc-mak (grade)
  (let ((p (UH_rand-fixed-length-disjunction *or_br* grade NIL)))
       (if (= 1 (length p))
           (car p)
           (p-mkor p)
       )
  )
)
     
(defun UH_rand-fixed-length-disjunction (branch_rate grade subterm_list)
 (cond
  ((equal branch_rate 0) NIL)
  ((equal branch_rate 1) (list (UH_rand-literal-mak grade subterm_list)))
  (T (let ((subterm (UH_rand-literal-mak grade subterm_list)))
       (cons subterm
	     (UH_rand-fixed-length-disjunction (- branch_rate 1) 
					    grade 
					    (cons subterm subterm_list)))))))


(defun HU_add-term (term list)
  (if (and term (listp term))
      list
    (cons term list)))

;******************* rules *****************************************************

(defun UH_rand-literal-mak (grade subterm_list)
 (if (equal grade 0)
  (UH_rand-prim_conc-mak subterm_list)
  (if (UH_rand-event *prim_conc_prob*)
    (UH_rand-prim_conc-mak subterm_list)
    (UH_rand-ruled_conc-mak grade))))

;grade must be > 0
(defun UH_rand-ruled_conc-mak (grade)
 (let ((c (UH_rand-disj_conc-mak (- grade 1)))
       (r (rand-mk-rolename)))
   (let ((modal_term (p-mkall r c))
	 (neg_event (UH_rand-event *neg_prob*)))
     (if neg_event
	 (p-mknot modal_term)
       modal_term))))
 
;******************* primitive **********************************************
   
(defun UH_rand-prim_conc-mak (subterm_list)
  (let ((atom (p-mknumletter (+ 1 (random *var_num*)))))
    (if (or (member atom subterm_list :test #'equal)
	    (member (p-mknot atom) subterm_list :test #'equal))
	(UH_rand-prim_conc-mak subterm_list)
      (if (UH_rand-event *neg_prob*)
	  (p-mknot atom)
	atom))))


;;returns T with probability prob, NIL with prbability 1-prob;
(defvar *MAX_NUM*)
(setq *MAX_NUM* 1000000)

(defun UH_rand-event (prob) (> (* prob *MAX_NUM*) (random *MAX_NUM*) ))

