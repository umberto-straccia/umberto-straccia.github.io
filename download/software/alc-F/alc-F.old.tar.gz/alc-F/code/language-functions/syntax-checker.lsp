;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Syntax Checker for language fuzzy ALC                                   %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %                                                                       
;%%% Adapted by Antonio Lopreiato                                            %
;%%% May 5th 1998                                                            % 
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This is a Syntax Checker for the Language fuzzy ALC.

;;The language contains letters (primitive concepts, denoted by P,Q) 
;;and propositions denoted by (C,D) which are built 
;;according to the following rule:
;;
;;C,D -> P              ;letter
;;     | *top*          ;true
;;     | *bot*          ;false
;;     | (not P)        ;negation
;;     | (and C D ...)  ;conjunction
;;     | (or C D ...)   ;disjunction
;;     | (all R C)      ;universal quantifier
;;     | (csome R C)    ;existential quantifier
;;
;;  R -> Q              ; role identifier
;;
;; AX -> (if P C)       ;primitive concept P implies C
;;     | (onlyif P C)   ;concept C implies P
;;     | (iff P C)      ;equivalent to the set {(if P C),(onlyif P C)}
;;
;;ASS -> (*isc* a C)      ;concept assertion
;;     | (*isr* (a b) R)  ;role assertion
;;   
;; AF -> (ASS RELOP n)        ;fuzzy (af-)assertion, 0<= n <=1
;;     | ((*axm* AX))         ;axiom assertion 
;;
;;RELOP -> >= | <=  

       
;; load macro functions
;;(load "language-macros-L.lsp")

;; Check the syntax of an ALC assertions
;; *************************************

;;--------------------------------------------------------------------------- 
;;check-af-assertion (af):
;;INPUT:   af = expression
;;RETURN:  af, if af is a fuzzy ALC-proposition
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-af-assertion (af)
 (let ((len (length af)))
   (cond ((= 1 len)
          (check-axiom (first af)) af)
         ((= 3 len)  
          (let ((deg (third af))
                (rel (second af)))
            (and (check-assertion (first af))
                 (>= deg 0) (<= deg 1) 
                 (or (equal rel '<=) (equal rel '>=)) 
                 af)))
         (t (format *standard-output* "==> Illegal L proposition expression ~S~%" af)) 
   )
 )
)           

;;--------------------------------------------------------------------------- 
;;check-af-assertions (af-list):
;;INPUT:   af-list = list of expression
;;RETURN:  T, if af-list is a list of fuzzy ALC-proposition
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-af-assertions (af-list)
 (if (null af-list)
     t
     (and (check-af-assertion (first af-list))
	  (check-af-assertions (rest af-list)))
 )
) 
                 
;;--------------------------------------------------------------------------- 
;;check-proposition(p):
;;INPUT:   p = expression
;;RETURN:  p, if p is L-proposition
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-proposition (p)
  (cond 
    ((p-isletter p) p) 
	((and (p-isnot p)
	      (check-proposition (p-get-argument p))) 
	  p) 
	((and (or (p-isand p) (p-isor p))
	      (check-propositions (p-get-arguments p))) 
	 p)
	((and (or (p-isall p) (p-iscsome p))
	      (check-quant p)) 
	  p)
	(t (format *standard-output* "==> Illegal L proposition expression ~S~%" p) 
	   nil)))

;;--------------------------------------------------------------------------- 
;;check-propositions (plist):
;;INPUT:   plist = list of expressions
;;RETURN:  plist, if plist is a list of  L-propositions
;;         nil, otherwise 
;;--------------------------------------------------------------------------- 

(defun check-propositions(plist)
  (cond ((null plist) t)
        (t (and (check-proposition (first plist))
		        (check-propositions (rest plist))))))


;check a quantified proposition e.g. (all/csome R.C)
(defun check-quant (p)
  (and (p-isletter (second p))
       (check-proposition (third p))
   )
)

;check an ALC assertion
(defun check-assertion (ass)
  (or (and (is-a-role-ass ass) 
           (check-role-ass ass)
	    ass)
      (and (is-a-concept-ass ass)
	   (check-concept-ass ass)
            ass)
  )
)

;check a concept assertion e.g (*ISC* ind concept)
(defun check-concept-ass (ass)
   (and	(p-isletter (second ass))
	(check-proposition (third ass)))
)

;check a role assertion e.g (*ISR* (ind1 ind2) R)
(defun check-role-ass (ass)
  (let ((sec (second ass)))
        (and (listp sec) 
             (= (length sec) 2)
	     (every #'p-isletter sec)
             (p-isletter (third ass)))
   )
)

(defun check-axiom (ass)
 (and (is-an-axiom ass)
      (let ((ax (second ass)))
           (and (or (p-isif ax)  
                    (p-isonlyif ax)
                    (p-isiff ax))
                (p-isletter (second ax))
                (check-proposition (third ax)))
      )
 )
)
