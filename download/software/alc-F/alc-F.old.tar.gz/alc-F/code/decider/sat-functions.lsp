;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         %
;%%% October, 6th 1997                                                       %
;%%%                                                                         %                                                                       % 
;%%% Adapted by Antonio Lopreiato                                            %
;%%% May 5th 1998                                                            %   
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This file contains the function in order to execute about sat problems

;;--------------------------------------------------------------------------- 
;; af-sat (af)
;; Input: ALC fuzzy assertion 
;; Return: result = true if SAT af
;;--------------------------------------------------------------------------- 

(defun af-sat (af) 
 (progn
       (setq result (saf-sat-exec (list (list (mk-af-ass af)))))
       (second result) ;; return result
 )
)

;;--------------------------------------------------------------------------- 
;; af-sat-KB (af-list)
;; Input: list of ALC fuzzy assertions, i.e. a KB 
;; Return: result = true if SAT af-list
;;--------------------------------------------------------------------------- 

(defun af-sat-KB (af-list) 
 (progn
       (setq result (saf-sat-exec (list (mk-af-list af-list))))
       (second result) ;; return result
 )
)

;;--------------------------------------------------------------------------- 
;; af-logically-implies (kb af)
;; Input: kb = list of ALC fuzzy assertions, i.e. a KB 
;;        af  = a fuzzy ALC assertion
;; Return: result = true if KB |= af
;;--------------------------------------------------------------------------- 

(defun af-logically-implies (kb af)
 (progn
   (setq kb (mk-af-list kb))
   (setq raf (second af))
   (if (is-a-role-ass (first af))
       (if (equal raf '>=)
           (role-entailment>= kb (mk-af-ass af))
           (role-entailment<= kb (mk-af-ass af))
       )  
       (progn
         (setq q (if (equal raf '>=)
                     (list (list '< (third af)) (first af)) 
		     (list (list '> (third af)) (first af))))
         (not (second (saf-sat-exec (list (push q kb)))))
       )
   )
 )
)

;;--------------------------------------------------------------------------- 
;; af-logically-implies-ext (ext-kb af)
;; Input: ext-kb = a list of af-completions
;;        af  = a fuzzy ALC assertion
;; Return: result = true if ext-kb |= af
;;--------------------------------------------------------------------------- 

(defun af-logically-implies-ext (ext-kb af)
 (progn
   (setq ml ext-kb)
   (setq raf (second af))
   (if (is-a-role-ass (first af))
       (if (equal raf '>=)
           (ext-role-entailment>= ml (mk-af-ass af))
           (ext-role-entailment<= ml (mk-af-ass af))
       )  
       (progn
         (setq nq (if (equal raf '>=)
                      (list (list '< (third af)) (first af)) 
		      (list (list '> (third af)) (first af))))
         (setq qml (mapcar #'(lambda (m) (push nq m)) ml))
         (not (second (saf-sat-exec qml)))
       )
   )
 )
)      

;;--------------------------------------------------------------------------- 
;; af-tautology (af)
;; Input: af  = a fuzzy ALC assertion
;; Return: result = true if |= af
;;--------------------------------------------------------------------------- 

(defun af-tautology (af)
  (af-logically-implies nil af)
)

;;--------------------------------------------------------------------------- 
;; af-get-a-completion (af)
;; Input: ALC fuzzy assertion 
;; Return: both a list of ALC primitive concepts, roles, 
;;         'ALL' concepts and axioms in the form of saf-assertions.
;;         The form (NIL) stands for the empty completion. 
;;         Return nil if no completions are avalaible
;;--------------------------------------------------------------------------- 

(defun af-get-a-completion (af) 
 (progn
       (setq result (saf-sat-exec (list (list (mk-af-ass af)))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-completions lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-KB-get-a-completion (af-list)
;; Input: a list of ALC fuzzy assertions
;; Return: both a list of ALC primitive concepts, roles, 
;;         'ALL' concepts and axioms in the form of saf-assertions.
;;         The form (NIL) stands for the empty completion. 
;;         Return nil if no completions are avalaible
;;--------------------------------------------------------------------------- 

(defun af-KB-get-a-completions (af-list) 
 (progn
       (setq result (saf-sat-exec (list (mk-af-list kb))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-completions lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-get-all-completion (af)
;; Input: ALC fuzzy assertion 
;; Return: both a list of ALC primitive (positive) concepts, roles, 
;;         'ALL' concepts and axioms in the form of saf-assertions.
;;         The form (NIL) stands for the empty completion. 
;;         Return nil if no completions are avalaible
;;--------------------------------------------------------------------------- 

(defun af-get-all-completions (af) 
 (progn
       (setq result (saf-all-models-exec (list (list (mk-af-ass af)))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-completions lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-KB-get-all-completions (af-list)
;; Input: a list of ALC fuzzy assertions 
;; Return: both a list of ALC primitive concepts, roles, 
;;         'ALL' concepts and axioms in the form of saf-assertions.
;;         The form (NIL) stands for the empty completion. 
;;         Return nil if no completions are avalaible
;;--------------------------------------------------------------------------- 


(defun af-KB-get-all-completions (af-list) 
 (progn
       (setq result (saf-all-models-exec (list (mk-af-list af-list))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-completions lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; cs-KB-get-all-completions (kb)
;; Input: a list of ALC fuzzy assertions 
;; Return: both a list of ALC primitive concepts, roles, 
;;         'ALL' concepts and axioms in the form of cs-assertions.
;;         The form (NIL) stands for the empty completion. 
;;         Return nil if no completions are avalaible
;;--------------------------------------------------------------------------- 

(defun cs-KB-get-all-completions (kb) 
 (let ((cstates (fifth (MD-all-models-exec 
                           (list (mk-cs-list tnum 1 kb))))))
   (if (null cstates)
       nil ; there are no completions
       (MD-build-completions cstates) ;; return all models
   )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-get-a-model (af)
;; Input: ALC fuzzy assertion 
;; Return: a list of weighted primitive concepts and roles,
;;         i.e. a fuzzy Herbrand model of fp.
;;         The form (NIL) stands for the empty model. 
;;         Return nil if no models are avalaible
;;---------------------------------------------------------------------------

(defun af-get-a-model (af) 
 (progn
       (setq result (saf-sat-exec (list (list (mk-af-ass af)))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-KB-get-a-model (af-list)
;; Input: a list of ALC fuzzy assertions
;; Return: a list of weighted primitive concepts and roles,
;;         i.e. a fuzzy Herbrand model of fp.
;;         The form (NIL) stands for the empty model. 
;;         Return nil if no models are avalaible
;;---------------------------------------------------------------------------

(defun af-KB-get-a-model (af-list) 
 (progn
       (setq result (saf-sat-exec (list (mk-af-list af-list))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (setq lmodels (sat-build-models lcompleted-states))
                (first lmodels)) ;; return first model
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-get-all-models (af)
;; Input: ALC fuzzy assertion 
;; Return: a list of weighted primitive concepts and roles,
;;         i.e. a fuzzy Herbrand model of fp.
;;         The form (NIL) stands for the empty model. 
;;         Return nil if no models are avalaible
;;---------------------------------------------------------------------------

(defun af-get-all-models (af) 
 (progn
       (setq result (saf-all-models-exec (list (list (mk-af-ass af)))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-KB-get-all-models (af-list)
;; Input: a list of ALC fuzzy assertions 
;; Return: a list of weighted primitive concepts and roles,
;;         i.e. a fuzzy Herbrand model of fp.
;;         The form (NIL) stands for the empty model. 
;;         Return nil if no models are avalaible
;;---------------------------------------------------------------------------

(defun af-KB-get-all-models (af-list) 
 (progn
       (setq result (saf-all-models-exec (list (mk-af-list af-list))))
       (setq lcompleted-states (fifth result)) 
       (cond ((null lcompleted-states)
               nil) ; no models
             (t (sat-build-models lcompleted-states)) ;; return all models
       )         
 )
)

;;--------------------------------------------------------------------------- 
;; af-glb (kb af)
;; Input: kb = list of fuzzy ALC assertions, i.e. a KB 
;;        af  = an ALC proposition
;; Return: af's greater lower bound given kb, that is
;;         {max n | n belongs to (0 1] and kb |= (p >= n)}; 
;;         return 0 if such n does'nt exist ;;--------------------------------------------------------------------------- 

(defun af-glb (kb af)
 (if (is-a-role-ass af)
     (role-bound kb af '>=)
     (progn 
       (setq kb (mk-cs-list tnum 1 kb))
       (setq result (MD-all-models-exec 
         (list (push (list (list '< 0 tlbd 1) af) kb))))
       (maxdegree (fifth result))
     )
 )
)

;;--------------------------------------------------------------------------- 
;; af-lub (kb af)
;; Input: kb = list of fuzzy ALC assertions, i.e. a KB 
;;        af  = an ALC proposition
;; Return: af's lower upper bound given kb, that is
;;         {min n | n belongs to [0 1) and kb |= (p <= n)}; 
;;         return 1 if such n does'nt exist ;;--------------------------------------------------------------------------- 

(defun af-lub (kb af)
 (if (is-a-role-ass af)
     (role-bound kb af '<=)
     (- 1 (af-glb kb (mknot-conc-ass af)))
 )
)

;;--------------------------------------------------------------------------- 
;; ext-af-glb (ext-kb af)
;; Input: ext-kb = list of cs-completions
;;        af  = an ALC proposition
;; Return: af's greater lower bound given ext-kb, that is
;;         {max n | n belongs to (0 1] and kb |= (p >= n),
;;                  for each kb in ext-kb}; 
;;         return 0 if such n does'nt exist ;;--------------------------------------------------------------------------- 

(defun ext-af-glb (ext-kb af)
 (if (is-a-role-ass af)
     (ext-role-bound ext-kb af '>=)
     (progn
       (setq q (list (list '< 0 tlbd 1) af))   
       (setq ekb ext-kb)                      
       (setq result (MD-all-models-exec 
         (mapcar #'(lambda (com) (push q com)) ekb)))
       (maxdegree (fifth result))
     )
 )
)

;;--------------------------------------------------------------------------- 
;; ext-af-lub (ext-kb af)
;; Input: ext-kb = list of cs-completions, i.e. a list of KBs 
;;        af  = an ALC proposition
;; Return: af's lower upper bound given ext-kb, that is
;;         {min n | n belongs to [0 1) and kb |= (p <= n),
;;                  for each kb in ext-kb}; 
;;         return 1 if such n does'nt exist  
;;--------------------------------------------------------------------------- 

(defun ext-af-lub (ext-kb af)
 (if (is-a-role-ass af)
     (ext-role-bound ext-kb af '<=)
     (- 1 (ext-af-glb ext-kb (mknot-conc-ass af)))
 )
)

;;---------------------------------------------------------------------------


