;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% simplify functions for fuzzy language ALC                               %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 
;;cs-simplify (cs):
;;INPUT:   cs = constrained relop-signed fuzzy ALC expression
;;RETURN:  a listed equivalent expression simplified and in NNF
;;--------------------------------------------------------------------------- 

(defun cs-simplify (cs)
 (cond ((cs-is-an-axiom cs)
        (axiom-simplify cs)
       )
       ((cs-is-a-concept-ass cs)
        (list (list (first cs) (concept-ass-simplify (second cs))))   
       )
       ((cs-is-a-role-ass cs) (list cs))       
 )
)      

;;--------------------------------------------------------------------------- 
;;simplify-cs-list (al):
;;INPUT:   al = a list of constrained relop-signed fuzzy ALC expressions
;;RETURN:  the list of their equivalent expressions simplified and in NNF
;;--------------------------------------------------------------------------- 

(defun simplify-cs-list (al)
 (if (null al)
     nil
     (concatenate 'list 
        (cs-simplify (first al))
        (simplify-cs-list (rest al)))
 )
)

;;--------------------------------------------------------------------------- 
;;p-simplify(p):
;;INPUT:   p = propositional expression
;;RETURN:  an equivalent expression simplified as follows. 
;;         (p-NNF p)               ; transform into NNF
;;         (p-remove-taut-ctd p)   ; then, handle TOP and BOT
;;
;;--------------------------------------------------------------------------- 

(defun p-simplify (p)
  (p-remove-taut-ctd (p-NNF p))
)

;simplifies a concept assertion
(defun concept-ass-simplify (ass)
  (mk-concept-ass (second ass) (p-simplify (third ass)))
) 

;simplifies an axiom
(defun axiom-simplify (ax-ass)
 (let* ((ax (cs-get-axiom ax-ass))
        (args (p-get-arguments ax))
        (f (first args))
        (c (p-simplify (second args))))
   (if (p-isiff ax)
       (list (list () (mk-axiom (list 'if f c))) 
             (list () (mk-axiom (list 'onlyif f c))))
       (list (list () (mk-axiom (list (p-get-operant ax) f c))))
   )
 )
)

;;--------------------------------------------------------------------------- 
;;p-NNF(p):
;;INPUT:   p = propositional expression
;;RETURN:  an equivalent expression in Negation Normal Form. Moreover, 
;;         it simplifies p according to
;;  
;;         (and ..A1 ... A2 ...) |- (and ... A1 ...) 
;;               if p-structural-subs (A2, A1) and Ai are ANDs
;;          
;;         (or ..A1 ... A2 ...) |- (or ... A1 ...) 
;;               if p-structural-subs (A2, A1) and Ai are ORs
;;--------------------------------------------------------------------------- 

(defun p-NNF (p)
  (cond 
    ((p-isletter p) p)
    ((p-isemptyand p) TOP)
    ((p-isemptyor p)  BOT)
    ((p-isnot p)      (p-neg-NNF (p-get-argument p)))
    ((p-isand p)      (p-and-NNF (p-get-arguments p)))
    ((p-isor p)       (p-or-NNF  (p-get-arguments p)))
    ((p-isall p)      (p-all-NNF p))
    ((p-iscsome p)    (p-csome-NNF p))
  )
)

(defun p-all-NNF (p)   ; NNF of an ALL
  (p-mkall (second p) (p-NNF (third p)))
)

(defun p-csome-NNF (p) ; NNF of a CSOME
  (p-mksome (second p) (p-NNF (third p)))
)

(defun p-and-NNF (p)   ; NNF of a list of arguments of an AND
  (progn
    (setq land-tmp (delete TOP 
                           (p-remove-double (p-remove-ands (mapcar #'p-NNF p))
		                                    nil
		                   )
		          )
    )
    (if (= (length land-tmp) 0)
        TOP                ; zero argument, no AND and return TOP
        (p-mkand land-tmp) ;there is at least one argument, make an AND or return arg
    )
  )
)
    
;;; simplyfies ( ... A (and  ...) ...) to (... A ...)

(defun p-remove-ands (and-list) 
  (if (null and-list) 
      nil
      (if (p-isand (first and-list)) ; nested AND  
	      (append (p-get-arguments (first and-list)) (p-remove-ands (rest and-list)))
          (cons (first and-list) (p-remove-ands (rest and-list)))          
      )
  )
)

;;; simplyfies ( ... F1 ... F1 ...) to (...F1 ...)

(defun p-remove-double (p lp-tmp) 
  (if (null p) 
      nil
      (if ;(member (first p) lp-tmp) ; check if there are doubles 
          (member (first p) lp-tmp :test #'equal) ; check if there are doubles 
          ;(member (first p) (union (rest p) lp-tmp) :test #'p-structural-subs) ; check if there are doubles
	      (p-remove-double (rest p) lp-tmp)
          (cons (first p) (p-remove-double (rest p) (cons (first p) lp-tmp)))
      )
  )
  
)

(defun p-or-NNF (p)  ; NNF of a list of arguments of an OR
  (progn
    (setq lor-tmp (delete BOT 
                           (p-remove-double (p-remove-ors (mapcar #'p-NNF p))
		                                    nil
		                   )
		          )
    )
    (if (= (length lor-tmp) 0)
        BOT             ; zero argument, no OR and return BOT
       (p-mkor lor-tmp) ; there is at least one argument, make an OR or return arg
    )
  )
)

;;; simplyfies ( ... A (or  ...) ...) to (... A ...)

(defun p-remove-ors (or-list) 
  (if (null or-list) nil
    (if (p-isor (first or-list)) ; nested OR
        (append (p-get-arguments (first or-list)) (p-remove-ors (rest or-list))) 
        (cons (first or-list) (p-remove-ors (rest or-list)))
    )
  )
)

(defun p-neg-NNF (p) ; transforms -(and A B) into (or -A -B), similary for "or" and "not"
  (cond ((p-isbot p) TOP)
	    ((p-istop p) BOT)
	    ((p-isemptyand p) BOT)
	    ((p-isemptyor p) TOP)
	    ((p-isletter p) (p-mknot p))
	    (t (case (first p)
	             (not    (p-NNF (p-get-argument p)))
	             (and    (p-or-NNF  (mapcar #'p-neg-NNF (p-get-arguments p))))
	             (or     (p-and-NNF (mapcar #'p-neg-NNF (p-get-arguments p))))
		     (all    (p-mksome (second p) (p-neg-NNF (third p))))
		     (csome  (p-mkall (second p) (p-neg-NNF (third p)))) 
	       )
	    )
   )
)


;;--------------------------------------------------------------------------- 
;;p-remove-taut-ctd (p):
;;INPUT:   p = propositional expression in NNF from p-NNF(p)
;;RETURN:  simplifies p according to
;;  
;;         (and ..BOT...) |- BOT 
;;         (and ... A ... (not A) ...) |- BOT
;;              
;;         (or ..TOP...) |- TOP 
;;         (or ... A ... (not A) ...) |- TOP
;;              
;;--------------------------------------------------------------------------- 

(defun p-remove-taut-ctd (p)
  (cond 
    ((or (p-isletter p) 
         (p-isnot p))    
     p)
    ((p-isand p)    (p-and-remove-taut-ctd (p-get-arguments p)))
    ((p-isor p)     (p-or-remove-taut-ctd  (p-get-arguments p)))
    ((p-isall p  )  (p-all-remove-taut-ctd  p))
    ((p-iscsome p)  (p-csome-remove-taut-ctd  p))
  )
)

(defun p-and-remove-taut-ctd (p)   ; handles list of arguments of an AND
  (progn
    (setq land-tmp (delete TOP (mapcar #'p-remove-taut-ctd p)))
    (if land-tmp  ; not nil list
        (if (member BOT land-tmp)   ; there is a BOT in the AND
            BOT 
            (p-mkand land-tmp)
        )   
        TOP    ; all TOP has been eliminated.
     )   
  )
)

(defun p-or-remove-taut-ctd (p)   ; handles list of arguments of an OR
  (progn
    (setq lor-tmp (delete BOT (mapcar #'p-remove-taut-ctd p)))
    (if lor-tmp  ; not nil list
        (if (member TOP lor-tmp)   ; there is a TOP in the OR
            TOP ; otherwise look for conjugated pairs
            (p-mkor lor-tmp)
        )
        BOT    ; all BOT has been eliminated
    )
  )
)

(defun p-all-remove-taut-ctd (p)   ; handles the ALL quantifier's argument 
  (let ((prop (p-remove-taut-ctd (third p))))
       (if (p-istop prop)
           top
	   (p-mkall (second p) prop)
       )
  )
)

(defun p-csome-remove-taut-ctd (p) ; handles the CSOME quantifier's argument
  (let ((prop (p-remove-taut-ctd (third p))))
       (if (p-isbot prop)
           bot
	   (p-mksome (second p) prop)
       )
  )
)


