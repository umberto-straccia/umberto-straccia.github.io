;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% macro definitions for fuzzy language ALC                                %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %                                                                       
;%%% Adapted by Antonio Lopreiato                                            %
;%%% May 5th 1998                                                            %                                                      
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 

(defconstant TOP '*top*)
(defconstant BOT '*bot*)
(defconstant ISC '*isc*)
(defconstant ISR '*isr*)
(defconstant AXM '*axm*)
(defconstant tnum  '*number*)
(defconstant tlbd  '*lambda*)
(defconstant t1-lbd '*1-lambda*)

;;--------------------------------------------------------------------------- 

(defmacro p-get-operant (p)   `(car ,p))   ;get the operant of p
(defmacro p-get-argument (p)  `(cadr ,p))  ;get the argument of unary operant
(defmacro p-get-arguments (p) `(rest ,p))  ;get the arguments of n-ary operant
(defmacro p-get-role-from-quant (p) `(second ,p)) ;get R from (all/csome R.C)
(defmacro p-get-prop-from-quant (p) `(third ,p))  ;get C from (all/csome R.C)

;;--------------------------------------------------------------------------- 

(defmacro p-istop (p)       `(equal ,p TOP))
(defmacro p-isbot (p)       `(equal ,p BOT))

;check if the concept of an assertion is TOP (resp. BOT) 
(defmacro conc-istop (p)    `(equal (third ,p) TOP))
(defmacro conc-isbot (p)    `(equal (third ,p) BOT))


(defun p-isletter (p) 
  (and (symbolp p)
	(not (equal p 'not))
	(not (equal p 'and))
	(not (equal p 'or))
	(not (equal p 'all))
	(not (equal p 'csome))
	(not (equal p 'isc))
	(not (equal p 'isr)))
)

(defmacro p-isnot (p)       `(and (listp ,p)
                                  (= (length ,p) 2) 
                                  (equal (p-get-operant ,p) 'not)))
(defmacro p-isand (p)       `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'and)))
(defmacro p-isemptyand (p)  `(equal p '(and)))
(defmacro p-isor (p)        `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'or)))
(defmacro p-isemptyor (p)   `(equal p '(or)))

(defmacro p-isif (p)        `(and (listp ,p)
                                  (= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'if)))
(defmacro p-isonlyif (p)    `(and (listp ,p)
                                  (= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'onlyif)))
(defmacro p-isiff (p)        `(and (listp ,p)
                                   (= (length ,p) 3) 
                                   (equal (p-get-operant ,p) 'iff)))
                                  
(defmacro p-isall (p)
  `(and (listp ,p)
	(= (length ,p) 3)
	(equal (p-get-operant ,p) 'all))
)

(defmacro p-iscsome (p)
  `(and (listp ,p)
	(= (length ,p) 3)
	(equal (p-get-operant ,p) 'csome))
)

;;--------------------------------------------------------------------------- 

(defmacro p-mktop ()       'TOP)
(defmacro p-mkbot ()       'BOT)
(defmacro p-mknot (p)      `(list 'not ,p))
(defmacro p-mkand (land)   `(if (= 1 (length ,land)) (car ,land) (cons 'and ,land)))
(defmacro p-mkor  (lor)    `(if (= 1 (length ,lor)) (car ,lor) (cons 'or  ,lor)))
(defmacro p-mkif  (lif)    `(cons 'if  ,lif))
(defmacro p-mkiff  (liff)  `(cons 'iff  ,liff))
(defmacro p-mkall (r c) `(list 'all ,r ,c))
(defmacro p-mksome (r c) `(list 'csome ,r ,c))

(defmacro mknot-conc-ass (c-ass)
  `(mk-concept-ass (second ,c-ass) (p-mknot (third ,c-ass)))
)

(defun p-mknumletter (num) (intern (concatenate 'string "p" (write-to-string num))))

(defun mk-sys-gen-indname (num) (intern (concatenate 'string "b" (write-to-string num))))

(defun mk-indname (num) (intern (concatenate 'string "a" (write-to-string num))))

(defun mk-rolename (num) (intern (concatenate 'string "r" (write-to-string num))))

(defmacro is-a-concept-ass (ass)
  `(and (listp ,ass)
	(= (length ,ass) 3)
	(equal (first ,ass) ISC))
)

(defmacro is-a-role-ass (ass)
  `(and (listp ,ass)
	(= (length ,ass) 3)
	(equal (first ,ass) ISR))
)

(defmacro is-an-axiom (ass)
  `(and (listp ,ass)
	(= (length ,ass) 2)
	(equal (first ,ass) AXM))
)

(defmacro cs-get-relop (cs-ass)
 `(first (first ,cs-ass))
)

(defmacro cs-get-sup (cs-ass)
 `(fourth (first ,cs-ass))
)

(defmacro cs-get-type (cs-ass)
 `(third (first ,cs-ass))
)

(defmacro cs-get-axiom (cs-ass)
 `(second (second ,cs-ass))
)

(defmacro cs-get-degree (cs-ass)
 `(second (first ,cs-ass))
)

(defmacro cs-get-crisp (cs-ass)
 `(second ,cs-ass)
)

(defmacro cs-is-a-role-ass (cs-ass)
 `(is-a-role-ass (second ,cs-ass))
)

(defmacro cs-is-a-concept-ass (cs-ass)
 `(is-a-concept-ass (second ,cs-ass))
)

(defmacro cs-is-an-axiom (cs-ass)
 `(is-an-axiom (second ,cs-ass))
)

(defmacro cs-get-rolename (cs-ass)
 `(third (second ,cs-ass))
)

(defmacro cs-get-concept (cs-ass)
 `(third (second ,cs-ass))
)

(defmacro cs-get-arguments (cs-ass)
 `(p-get-arguments (cs-get-concept ,cs-ass))
)

(defmacro cs-isand (cs-ass)
 `(p-isand (cs-get-concept ,cs-ass))
)

(defmacro cs-isor (cs-ass)
 `(p-isor (cs-get-concept ,cs-ass))
)

(defmacro cs-isall (cs-ass)
 `(p-isall (cs-get-concept ,cs-ass))
)

(defmacro cs-get-individuals (cs-ass)
 `(second (second ,cs-ass))
)

(defmacro cs-get-conc-from-quant (cs-ass)
 `(p-get-prop-from-quant (cs-get-concept ,cs-ass))
)

(defmacro cs-get-role-from-quant (cs-ass)
 `(p-get-role-from-quant (cs-get-concept ,cs-ass))
)

(defmacro cs-istop (cs-ass)
 `(equal TOP (cs-get-concept ,cs-ass))
)

(defmacro cs-isbot (cs-ass)
 `(equal BOT (cs-get-concept ,cs-ass))
)

(defmacro get-inverse-relop (relop)
 `(cond ((equal ,relop '>=) '<=)
        ((equal ,relop '<) '>)
        ((equal ,relop '<=) '>=)
        ((equal ,relop '>) '<)
  )
)

(defmacro get-inverse-ltype (tp)
 `(if (equal ,tp tlbd) t1-lbd tlbd)
)        

(defmacro get-relop (cs-ass)
 `(first ,cs-ass)
)

(defmacro get-sup (cs-ass)
 `(fourth ,cs-ass)
)

(defmacro get-type (cs-ass)
 `(third ,cs-ass)
)

(defmacro get-degree (cs-ass)
 `(second ,cs-ass)
)

(defmacro subst-relop (newrel info)
 `(cons ,newrel (cdr ,info))
)

(defun subst-degree (newdeg info)
 (let ((newinf (copy-list info)))
    (setf (second newinf) newdeg)
    newinf)
)

(defun subst-type (newtp info)
(list (first info) (second info) newtp (fourth info))
 (let ((newinf (copy-list info)))
    (setf (third newinf) newtp)
    newinf)
)

(defun subst-sup (newsup info)
 (let ((newinf (copy-list info)))
    (setf (fourth newinf) newsup)
    newinf)
)

(defun rl-key (r-ass)
 (let ((rnm (cs-get-rolename r-ass))
       (ind (first (cs-get-individuals r-ass))))
   (list rnm ind))
)

(defun all-key (ass)
 (let ((rnm (cs-get-role-from-quant ass))
       (ind (cs-get-individuals ass)))
   (list rnm ind))
)

(defmacro mk-cs-ass (info ass)
 `(list ,info ,ass)
)

(defmacro mk-concept-ass (ind cp)
 `(list isc ,ind ,cp)
)

(defmacro mk-role-ass (ind1 ind2 c)
  `(list isr (list ,ind1 ,ind2) ,c)
)

(defmacro mk-axiom (cond-ex)
 `(list axm ,cond-ex)
)

(defun mk-cs-list (relop type sup aflist)
 (mapcar #'(lambda (af) 
   (list (list relop (second af) type sup) (first af)))
       aflist)
)

(defun mk-af-list (relop aflist)
 (mapcar #'(lambda (af) 
   (list (list relop (second af)) (first af)))
       aflist)
)

(defmacro mk-af-ass (relop ass)
 `(list (list ,relop (second ,ass)) (first ,ass))
)

(defun int-intersection (bounds)
 (if (null bounds)
      0
     (apply #'min bounds))
)

(defun int-union (bounds)
 (if (null bounds)
     0
     (apply #'max bounds))
)

;;---------------------------------------------------------------------------















