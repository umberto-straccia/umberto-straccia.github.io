;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Random Generator         						     %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Antonio Lopreiato                                                       %                                                
;%%% antonio@iei.pi.cnr.it                                                   %                                                
;%%%                                                                         % 
;%%% June, 1st 1998                                                          %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;This random generator is a variant (more general) from the one of Hustadt.

(defvar *primitive_concepts_num* 10)
(defvar *roles_num* 10)
(defvar *individuals_num* 20)
(defvar *and_prob* 0.3)
(defvar *or_prob* 0.01)
(defvar *all_prob* 0.5)
(defvar *quant_prob* 0.55)
(defvar *neg_prob* 0.05)
(defvar *and_args_num* 3)
(defvar *or_args_num* 2)
(defvar *degree* 3)
(defvar *concept_ass_prob* 0.5)

;Returns a random fuzzy ALC assertion
(defun get-fz-alc-random-assertion ()
 (if (rand-event *concept_ass_prob*)
     (list (rand-mk-concept-ass) (random 1.0))
     (list (rand-mk-role-ass) (random 1.0))
 )
)

(defun get-alc-random-proposition ()
 (mk-formula *degree* nil nil)
) 

(defun mk-formula (degree flag subterm)
 (if (zerop degree)
     (mk-rand-literal subterm)
     (cond ((and (rand-event *and_prob*) (not (equal flag 'and)))
            (mk-and (mk-rand-and-formula degree *and_args_num* 'and subterm))
           )
	   ((and (rand-event *or_prob*) (not (equal flag 'or)))
            (mk-or (mk-rand-or-formula degree *or_args_num* 'or subterm))
           )
           ((rand-event *quant_prob*)
            (mk-rand-quant-formula degree 'quant)
           )
           (t (mk-rand-literal subterm))
     ) 
  )                                      
)

(defun mk-rand-literal (subterml)
 (let ((l (p-mknumletter (+ 1 (random *primitive_concepts_num*)))))  
      (if (or (member l subterml :test #'equal)
              (member (p-mknot l) subterml :test #'equal))
          (mk-rand-literal subterml)    
          (if (rand-event *neg_prob*) 
              (p-mknot l)        
              l
          )
      )
 )
)

(defun mk-rand-and-formula (deg subargs flag subterml)
 (let ((f (mk-formula (1- deg) flag subterml)))
      (if (= 1 subargs)
          (list f)
          (cons f (mk-rand-and-formula deg (1- subargs) flag (cons f subterml)))
      )
 )
) 


(defun mk-rand-or-formula (deg subargs flag subterml)
 (let ((f (mk-formula (1- deg) flag subterml)))
      (if (= 1 subargs)
          (list f)
          (cons f (mk-rand-or-formula deg (1- subargs) flag (cons f subterml)))
      )
 )
)

(defun mk-rand-quant-formula (deg flag)   
 (let ((want-an-all (rand-event *all_prob*))
       (r (rand-mk-rolename))
       (c (mk-formula (1- deg) nil nil)))
       (if want-an-all
           (p-mkall r c)
           (p-mksome r c)
       )
 )
)       

(defun mk-and (and-args)
 (if (= 1 (length and-args))
     (car and-args)
     (p-mkand and-args)
 )
)


(defun mk-or (or-args)
 (if (= 1 (length or-args))
     (car or-args)
     (p-mkor or-args)
 )
)

(defun rand-mk-individual ()
 (let ((num (1+ (random *individuals_num*))))
    (mk-indname num))
)

(defun rand-mk-rolename ()
 (let ((num (1+ (random *roles_num*))))
    (mk-rolename num))
)

(defun rand-mk-role-ass ()
 (let ((role (rand-mk-rolename))
       (fst-ind (rand-mk-individual))
       (snd-ind (rand-mk-individual)))
       (mk-role-ass fst-ind snd-ind role))  
)

(defun rand-mk-concept-ass ()
 (let ((f (get-alc-random-proposition))
       (i (rand-mk-individual)))
      (mk-concept-ass i f))
)       

(defvar *MAX_NUM*)
(setq *MAX_NUM* 1000000)

(defun rand-event (prob) (> (* prob *MAX_NUM*) (random *MAX_NUM*) ))


   