;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Executes test, variable definitions                                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;(defvar *sort-clauses*)
(defvar *execute_test*) 
(defvar *time_bound*)
(defvar *timeout*)

;----------------------------------------------------------------------------
;       RANDOM GENERATOR'S VALUES                                  
;----------------------------------------------------------------------------

;NOTE: the values between square brackets [] are the default values

;----------------------------------------------------------------------------
;SETTABLE VALUES                                                   
;----------------------------------------------------------------------------
;FLAGS
(setq *sort-clauses* T)    ;[T] if T, wffs are generated sorted
(setq *execute_test* T)    ;[T] if nil, no satisfiability test, 
                           ; only generation of propositions 

;TIMEOUT
(setq *timeout*  NIL)           ; do not change this value!!!!
#+ALLEGRO (setq *timeout* 1000) ; [1000] execution timeout (in seconds)
                                ; if NIL, no timeout
;OUTPUT:
(setq *result-file* "test/test-data/result.txt")  ; result file
(setq *wff-file*    "test/test-data/wff.txt")     ; file of generated testing propositions



;----------------------------------------------------------------------------
;DEFAULT VALUES                                                    
;%%% (these values are modified by the testing functions)              
;----------------------------------------------------------------------------

;(setq *var_num* 4)          ; variable number
;(setq *and_br* 120)         ; and branching

;----------------------------------------------------------------------------
; FIXED VALUES                                                     
; (do not change them unless you are sure of what you are doing)    
;----------------------------------------------------------------------------

;(setq *neg_prob* .5)        ; negative literals ratio
;(setq *or_br* 3)            ; or branching


;----------------------------------------------------------------------------



