;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 
;; saf-sat-exec (KB-list)  
;; Input: list of relop-signed ALC fuzzy KB
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	              6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT KB-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun saf-sat-exec (KB-list)
   (saf-state-solver KB-list                 ; initial states
                   #'sat-get-new-states      ; new states generation function
                   #'sat-closed-state        ; determines whether a state is closed
                   #'sat-termination         ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

;;--------------------------------------------------------------------------- 
;; saf-all-models-exec (KB-list) 
;; Input: list of relop-signed ALC fuzzy KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT KB-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun saf-all-models-exec (KB-list)
   (saf-state-solver KB-list                 ; initial states
                   #'sat-get-new-states      ; new states generation function
                   #'sat-closed-state        ; determines whether a state is closed
                   #'model-termination       ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

;;--------------------------------------------------------------------------- 
;; saf-state-solver (KB-list    
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of relop-signed ALC fuzzy KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun saf-state-solver (KB-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       (setq *number-of-states* 0)
       (setq *new-ind-counter* 0)
       (setq *axioms* (make-hash-table :test #'equal))
       (setq *models_axioms* nil)
       (setq KBlist (mapcar #'simplify-cs-list KB-list))  ; reduce every assertion in saf-list in NNF
       ; build first state, the case of multiple initial states is similar
       (setq newstates (mapcar #'sat-initial-state-make KBlist))
       ; call the solver
       (setq lresult-tmp 
             (state-solver newstates              ; initial states
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

;;--------------------------------------------------------------------------- 
;; md-sat-exec (KB-list)   
;; Input: list of constrained relop-signed ALC fuzzy KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	              6. current-state 
;;                7. lintermediate-states),
;;
;;         lcompleted-states = completed states
;;--------------------------------------------------------------------------- 

(defun md-sat-exec (KB-list)
   (md-state-solver KB-list                 ; initial states
                   #'md-get-new-states      ; new states generation function
                   #'md-closed-state        ; determines whether a state is closed
                   #'md-termination         ; determines whether the search is stopped
                   #'sat-get-result)        ; returns a boolean, result of search

)

;;--------------------------------------------------------------------------- 
;; MD-all-models-exec (KB-list) 
;; Input: list of relop-signed ALC fuzzy KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT KB-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun MD-all-models-exec (KB-list)
   (MD-state-solver KB-list                  ; initial states
                   #'MD-get-new-states       ; new states generation function
                   #'MD-closed-state         ; determines whether a state is closed
                   #'model-termination       ; determines whether the search is stopped
                   #'sat-get-result)         ; returns a boolean, result of search

)

;;--------------------------------------------------------------------------- 
;; md-state-solver (KB-list    
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of constrained relop-signed ALC fuzzy KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun md-state-solver (KB-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       (setq *number-of-states* 0)
       (setq *new-ind-counter* 0)
       (setq *axioms* (make-hash-table :test #'equal))
       (setq *models_axioms* nil)
       (setq KBlist (mapcar #'simplify-cs-list KB-list))  ; reduce every proposition in cs-list in NNF
       ; build first state, the case of multiple initial states is similar
       (setq newstates (mapcar #'MD-initial-state-make KBlist))
       ; call the solver
       (setq lresult-tmp 
             (state-solver newstates              ; initial states
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)
