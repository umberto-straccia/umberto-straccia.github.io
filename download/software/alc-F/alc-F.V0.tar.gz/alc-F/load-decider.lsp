;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% load decide procedure                                                   %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; sat-functions
(load "code/decider/sat-functions.lsp")

;; load state-solver
(load "code/decider/state-solver.lsp")

;; load state-solver defs, user modified
(load "code/decider/state-solver-defs.lsp")

;; load state-solver fixed functions
(load "code/decider/state-solver-fixed.lsp")

;; load exec-state-solver
(load "code/decider/exec-state-solver.lsp")

;; load hash-fun.lsp
(load "code/hash-functions.lsp")

;; load state-solver defs, user modified
(load "code/decider/md-state-solver-defs.lsp")
