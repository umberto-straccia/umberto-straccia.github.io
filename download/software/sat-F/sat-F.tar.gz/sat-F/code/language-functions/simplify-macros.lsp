;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% simplify functions  for propositional language L                        %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 
;;fp-NNF(fp):
;;INPUT:   fp = fuzzy expression
;;RETURN:  an equivalent fuzzy expression in Negation Normal Form. 
;;---------------------------------------------------------------------------  

;;as fp-NNF, but work for signed fuzzy expression
(defun s-fp-NNF (sfp)
  (if (s-fp-isTT sfp)
      (s-fp-mkTT (fp-NNF (s-fp-getformula sfp))) 
      (s-fp-mkNT (fp-NNF (s-fp-getformula sfp)))
  )
)

(defun fp-NNF (fp)
  (if (zerop (fp-get-degree fp))
      nil
      (mk-fuzzy-prop (p-NNF (fp-get-propos fp)) (fp-get-degree fp))
  )
)  

;;--------------------------------------------------------------------------- 
;;p-NNF(p):
;;INPUT:   p = propositional expression
;;RETURN:  an equivalent expression in Negation Normal Form. Moreover, 
;;         it simplifies p according to
;;  
;;         (and ..A1 ... A2 ...) |- (and ... A1 ...) 
;;               if p-structural-subs (A2, A1) and Ai are ANDs
;;          
;;         (or ..A1 ... A2 ...) |- (or ... A1 ...) 
;;               if p-structural-subs (A2, A1) and Ai are ORs
;;--------------------------------------------------------------------------- 


(defun p-NNF (p)
  (cond 
    ((p-isletter p) p)
    ((p-isemptyand p) TOP)
    ((p-isemptyor p)  BOT)
    ((p-isnot p)      (p-neg-NNF (p-get-argument p)))
    ((p-isand p)      (p-and-NNF (p-get-arguments p)))
    ((p-isor p)       (p-or-NNF  (p-get-arguments p)))
  )
)

(defun p-and-NNF (p)   ; NNF of a list of arguments of an AND
  (progn
    (setq land-tmp (p-remove-double (p-remove-ands (mapcar #'p-NNF p)) nil))
    (cond ((>= (length land-tmp) 2)
           (p-mkand land-tmp))  ; there are at least two arguments, make an AND
          ((= (length land-tmp) 1)
           (car land-tmp))      ; one argument, no AND and return arg
          ((= (length land-tmp) 0)
            TOP)      ; zero argument, no AND and return TOP 
    )
  )
)

;;; simplyfies ( ... A (and  ...) ...) to (... A ...)

(defun p-remove-ands (and-list) 
  (if (null and-list) 
      nil
      (if (p-isand (first and-list)) ; nested AND  
	      (append (p-get-arguments (first and-list)) (p-remove-ands (rest and-list)))
          (cons (first and-list) (p-remove-ands (rest and-list)))          
      )
  )
)

;;; simplyfies ( ... F1 ... F1 ...) to (...F1 ...)

(defun p-remove-double (p lp-tmp) 
;  (if (null p) 
;      nil
;      (if (member (first p) lp-tmp) ; check if there are doubles 
;          ;(member (first p) lp-tmp :test #'equal) ; check if there are doubles 
;          ;(member (first p) lp-tmp :test #'p-structural-equiv) ; check if there are doubles
;	      (p-remove-double (rest p) lp-tmp)
;          (cons (first p) (p-remove-double (rest p) (cons (first p) lp-tmp)))
;      )
;  )
  (if (null p) 
      nil
      (if ;(member (first p) lp-tmp) ; check if there are doubles 
          (member (first p) lp-tmp :test #'equal) ; check if there are doubles 
          ;(member (first p) (union (rest p) lp-tmp) :test #'p-structural-subs) ; check if there are doubles
	      (p-remove-double (rest p) lp-tmp)
          (cons (first p) (p-remove-double (rest p) (cons (first p) lp-tmp)))
      )
  )
  
)


(defun p-or-NNF (p)  ; NNF of a list of arguments of an OR
  (progn
    (setq lor-tmp (p-remove-double (p-remove-ors (mapcar #'p-NNF p)) nil)))
    (cond ((>= (length lor-tmp) 2)
           (p-mkor lor-tmp))  ; there are at least two arguments, make an OR
          ((= (length lor-tmp) 1)
           (car lor-tmp))      ; one argument, no OR and return arg
          ((= (length lor-tmp) 0)
            BOT)      ; zero argument, no AND and return BOT 
    )
  )
)

;;; simplyfies ( ... A (or  ...) ...) to (... A ...)

(defun p-remove-ors (or-list) 
  (if (null or-list) nil
    (if (p-isor (first or-list)) ; nested OR
        (append (p-get-arguments (first or-list)) (p-remove-ors (rest or-list))) 
        (cons (first or-list) (p-remove-ors (rest or-list)))
    )
  )
)

(defun p-neg-NNF (p) ; transforms (and A B) into (or -A -B), similary for "or" and "not"
  (cond     ((p-isbot p) TOP)
	    ((p-istop p) BOT)
	    ((p-isemptyand p) BOT)
	    ((p-isemptyor p) TOP)	  
	    ((p-isletter p) (p-mknot p))
	    (t (case (first p)
	             (not  (p-NNF (p-get-argument p)))
	             (and  (p-or-NNF  (mapcar #'p-neg-NNF (p-get-arguments p))))
	             (or   (p-and-NNF (mapcar #'p-neg-NNF (p-get-arguments p)))) 
	       )
	    )
   )
)


;;--------------------------------------------------------------------------- 
;;p-structural-equiv(p1 p2):
;;INPUT:   pi = two propositional expressions
;;RETURN:  true iff p1 is structurally equivalent to p2 according the 
;;         following inductive definition of equiv
;;
;;         letter1 equiv letter2 if letter1 = letter2
;;         (not A1) equiv (not A2) iff A1 equiv A2
;;         (and A1 ... An) equiv (and B1 ... Bm) 
;;             iff n=m and (for all Ai there is Bj such that Ai equiv Bj)
;;         (or A1 ... An) subs (or B1 ... Bm) 
;;             iff n=m and (for all Ai there is Bj such that Ai equiv Bj)
;;
;;--------------------------------------------------------------------------- 


(defun p-structural-equiv (p1 p2)
  (progn
     (cond ((and (p-isletter p1) 
                 (p-isletter p2))
            (equal p1 p2)
           ) 
           ((and (p-isnot p1) 
                 (p-isnot p2))
            (p-structural-equiv (p-get-argument p1) (p-get-argument p2))
           )
           ((or (and (p-isand p1)
                     (p-isand p2)
                     (= (length p1) (length p2))
                )
                (and (p-isor p1)
                     (p-isor p2)
                     (= (length p1) (length p2))
                )
            ) 
            ;;; for all ... there is ..
            (every     
                #'(lambda (x) 
                      (some #'(lambda (y) (p-structural-equiv x y)) 
                            (p-get-arguments p2)
                      ))
                (p-get-arguments p1)
            )
           )     
           (t nil)
     )          
  )
)

;;--------------------------------------------------------------------------- 
;;p-structural-subs(p1 p2):
;;INPUT:   pi = two propositional expressions
;;RETURN:  true iff p1 is subsumed by p2, p1 <= p2 according the 
;;         following inductive definition of <=
;;
;;         letter1 <= letter2 if letter1 = letter2
;;         (not A1) <= (not A2) iff A1 <= A2
;;         (and A1 ... An) <= (and B1 ... Bm) 
;;             iff (for all Bi there is Aj such that Aj <= Bi)
;;         (or A1 ... An) <= (or B1 ... Bm) 
;;             iff (for all Bi there is Aj such that Aj <= Bi)
;;
;;--------------------------------------------------------------------------- 


(defun p-structural-subs (p1 p2)
  (progn
     (cond ((and (p-isletter p1) 
                 (p-isletter p2))
            (equal p1 p2)
           ) 
           ((and (p-isnot p1) 
                 (p-isnot p2))
            (p-structural-equiv (p-get-argument p1) (p-get-argument p2))
           )
           ((or (and (p-isand p1)
                     (p-isand p2)
                )
                (and (p-isor p1)
                     (p-isor p2)
                )
            ) 
            ;;;; for all ... there is ..
            (every     
                #'(lambda (x) 
                      (some #'(lambda (y) (p-structural-subs y x)) 
                            (p-get-arguments p1)
                      ))
                (p-get-arguments p2)
            )
           )     
           (t nil)
     )          
  )
)

