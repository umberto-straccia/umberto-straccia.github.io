;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% macro definitions for propositional language L                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;;--------------------------------------------------------------------------- 

(defconstant TOP '*top*)
(defconstant BOT '*bot*)

;;--------------------------------------------------------------------------- 

(defmacro p-get-operant (p)   `(car ,p))   ;get the operant of p
(defmacro p-get-argument (p)  `(cadr ,p))  ;get the argument of unary operant
(defmacro p-get-arguments (p) `(rest ,p))  ;get the arguments of n-ary operant
(defmacro fp-get-degree (fp)  `(cadr ,fp)) ;get the degree of fp
(defmacro fp-get-propos (fp)  `(car ,fp))  ;get the proposition of fp

;;--------------------------------------------------------------------------- 

(defmacro p-istop (p)       `(equal ,p TOP))
(defmacro p-isbot (p)       `(equal ,p BOT))
(defmacro p-isletter (p)    `(and (symbolp ,p) 
                                  (not (equal ,p 'not))
                                  (not (equal ,p 'and))
                                  (not (equal ,p 'or))   
                             ))
(defmacro p-isvar (p)       `(and (symbolp ,p) 
                                  (not (equal ,p 'not))
                                  (not (equal ,p 'and))
                                  (not (equal ,p 'or)) 
                                  (not (equal ,p BOT))
                                  (not (equal ,p TOP))))                              
(defmacro p-isnot (p)       `(and (listp ,p)
                                  (= (length ,p) 2) 
                                  (equal (p-get-operant ,p) 'not)))
(defmacro p-isand (p)       `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'and)))
(defmacro p-isemptyand (p)  `(equal p '(and)))
(defmacro p-isor (p)        `(and (listp ,p)
                                  (>= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'or)))
(defmacro p-isemptyor (p)   `(equal p '(or)))

(defmacro p-isif (p)        `(and (listp ,p)
                                  (= (length ,p) 3) 
                                  (equal (p-get-operant ,p) 'if)))
(defmacro p-isiff (p)        `(and (listp ,p)
                                   (= (length ,p) 3) 
                                   (equal (p-get-operant ,p) 'iff)))
                                  

;;--------------------------------------------------------------------------- 

(defmacro p-mktop ()       'TOP)
(defmacro p-mkbot ()       'BOT)
(defmacro p-mknot (p)      `(list 'not ,p))
(defmacro p-mkand (land)   `(cons 'and ,land))
(defmacro p-mkor  (lor)    `(cons 'or  ,lor))
(defmacro p-mkif  (lif)    `(cons 'if  ,lif))
(defmacro p-mkiff  (liff)  `(cons 'iff  ,liff))
(defmacro mk-fuzzy-prop (p n)  `(list ,p ,n))

(defun p-mknumletter (num) (intern (concatenate 'string "p" (write-to-string num))))

(defconstant TT '*TT*)   ; positive sign
(defconstant NT '*NT*)   ; negative sign

;;---------------------------------------------------------------------------
;; s-fp-mkTT (p) macro
;;
;; input : a fuzzy formula, fp
;;
;; output: a signed fuzzy formula, (*TT* fp)
;;
;; s-fp-mkNT (fp) macro do same thing returning (*NT* fp)
;;
;;---------------------------------------------------------------------------

(defmacro s-fp-mkTT (fp) `(list TT ,fp))
(defmacro s-fp-mkNT (fp) `(list NT ,fp))

;;---------------------------------------------------------------------------
;; macro s-fp-get-sign (s-fp)
;;
;; input  : a signed fuzzy formula s-fp 
;;
;; output : TT if s-fp is (*TT* fp), NT if s-p is (*NT* fp)
;;
;;---------------------------------------------------------------------------
;; macro s-fp-getformula (s-fp)
;;
;; input : an s-fp signed proposition e.g. (*TT* fp) 
;;
;; output: the proposition fp without sign
;;---------------------------------------------------------------------------

(defmacro s-fp-getsign (s-fp)    `(car ,s-fp))
(defmacro s-fp-getformula (s-fp) `(cadr ,s-fp))
(defmacro s-fp-getpropos (s-fp)  `(fp-get-propos (s-fp-getformula ,s-fp)))
(defmacro s-fp-getdegree (s-fp)  `(fp-get-degree (s-fp-getformula ,s-fp)))

(defmacro s-fp-isTT (s-fp) `(equal TT (s-fp-getsign ,s-fp)))
(defmacro s-fp-isNT (s-fp) `(equal NT (s-fp-getsign ,s-fp)))


;;--------------------------------------------------------------------------- 
;; make-TT-fp-list (fp-list)
;; 
;; input : fp-list, a list of unsigned fuzzy propositions 
;;
;; output: same list, where propositions have been signed with TT
;;
;;--------------------------------------------------------------------------- 


(defun make-TT-fp-list (fp-list)
  (progn
    (setq result ())
    (setq result-tmp ())
    (dolist (arg fp-list)
	    (push (s-fp-mkTT arg) result-tmp)
	    )
    (setq result result-tmp)
    )
)


;;--------------------------------------------------------------------------- 
;; make-NT-fp-list (fp-list)
;; 
;; input : fp-list, a list of unsigned fuzzy propositions 
;;
;; output: same list, where propositions have been signed with NT
;;
;;--------------------------------------------------------------------------- 


(defun make-NT-fp-list (fp-list)
  (progn
    (setq result ())
    (setq result-tmp ())
    (dolist (arg fp-list)
	    (push (s-fp-mkNT arg) result-tmp)
	    )
    (setq result result-tmp)
    )
)
	 
;;---------------------------------------------------------------------------

