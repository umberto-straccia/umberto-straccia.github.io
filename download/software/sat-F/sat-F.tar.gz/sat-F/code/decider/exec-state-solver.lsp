;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                       
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; (defvar *set-calculus* 2)
;; you use the *set-calculus* global variable to set the type of calculus 
;; which can be two-value (default) or four-value

(defvar *set-calculus* 2)

;;--------------------------------------------------------------------------- 
;; s-fp-sat-exec (s-fp-list)
;; Input: list of signed fuzzy propositions, i.e. a KB 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	          6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT s-fp-list.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun s-fp-sat-exec (s-fp-list)
   (if (= *set-calculus* 2)
          (s-fp-state-solver   s-fp-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (s-fp-state-solver   s-fp-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)

;;--------------------------------------------------------------------------- 
;; multistates-s-fp-sat-exec (fkbl)
;; Input: list of list of signed fuzzy propositions, i.e. a list of KBs 
;; Return: (list  
;;                1. *number-of-states* 
;;                2. result 
;;                3. lopen-states 
;;                4. lclosed-states 
;;                5. lcompleted-states
;;	          6. current-state 
;;                7. lintermediate-states),
;;
;;         result = true iff SAT fkbl.
;;         lcompleted-states = one completed state
;;--------------------------------------------------------------------------- 

(defun multistates-s-fp-sat-exec (fkbl)
  (if (= *set-calculus* 2)
          (multistates-s-fp-state-solver fkbl                         ; initial states
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (multistates-s-fp-state-solver fkbl                         ; initial states
                              #'sat-get-new-states      ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'sat-termination         ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
  )
)

;;--------------------------------------------------------------------------- 
;; s-p-all-models-exec (s-fp-list)
;; Input: list of signed fuzzy propositions, i.e. a KB 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT s-fp-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun s-fp-all-models-exec (s-fp-list)
   (if (= *set-calculus* 2)
          (s-fp-state-solver   s-fp-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (s-fp-state-solver   s-fp-list                  ; initial state
                              #'sat-get-new-states   ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)

;;--------------------------------------------------------------------------- 
;; multistates-s-fp-all-models-exec (s-fp-list)
;; Input: list of list of signed fuzzy propositions, i.e. a list of KBs 
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states),
;;         result = true iff SAT s-fp-list.
;;         lcompleted-states = all completed states
;;--------------------------------------------------------------------------- 

(defun multistates-s-fp-all-models-exec (s-fp-list)
   (if (= *set-calculus* 2)
          (multistates-s-fp-state-solver   s-fp-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'2V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
	  (multistates-s-fp-state-solver   s-fp-list                  ; initial state
                              #'sat-get-new-states      ; new states generation function
                              #'4V-sat-closed-state     ; determines whether a state is closed
                              #'model-termination       ; determines whether the search is stopped
                              #'sat-get-result)         ; returns a boolean, result of search
   )
)


;;--------------------------------------------------------------------------- 
;; s-fp-state-solver (s-fp-list 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of signed fuzzy propositions, i.e. a KB 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun s-fp-state-solver (s-fp-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn
       (setq s-fp-list (delete nil (mapcar #'s-fp-NNF s-fp-list)))  
       ; build first state, the case of multiple initial states is similar
       (setq newstate (sat-initial-state-make s-fp-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver (list newstate)        ; initial state
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

;;--------------------------------------------------------------------------- 
;; multistates-s-fp-state-solver (KB-list 
;;                 get-new-states-fn
;;                 closed-state-fn
;;                 termination-fn
;;                 get-result-fn
;;                 )
;; Input: list of lists of signed fuzzy propositions, i.e. a list of KBs 
;;        get-new-states-fn      ; new states generation function
;;        closed-state-fn        ; determines whether a state is closed
;;        termination-fn         ; determines whether the search is stopped
;;        get-result-fn          ; returns a boolean, result of search
;;
;; Return: (list  *number-of-states* result 
;;                lopen-states lclosed-states lcompleted-states
;;	              current-state lintermediate-states)
;;---------------------------------------------------------------------------

(defun multistates-s-fp-state-solver (KB-list 
                       get-new-states-fn
                       closed-state-fn
                       termination-fn
                       get-result-fn)
  (progn   
       ; reduce every proposition in p-list in NNF
       (setq KB-list (delete nil (mapcar #'(lambda (kb) (mapcar #'s-fp-NNF kb)) KB-list)))  
       ; build first state, the case of multiple initial states is similar
       (setq newstates (mapcar #'sat-initial-state-make KB-list))
       ; call the solver
       (setq lresult-tmp 
             (state-solver newstates              ; initial states
                           get-new-states-fn      ; new states generation function
                           closed-state-fn        ; determines whether a state is closed
                           termination-fn         ; determines whether the search is stopped
                           get-result-fn))        ; returns a boolean, result of search
       (setq result (first lresult-tmp))
       (setq lopen-states (second lresult-tmp))
       (setq lclosed-states (third lresult-tmp))
       (setq lcompleted-states (fourth lresult-tmp))
       (setq current-state (fifth lresult-tmp)) 
       (setq lintermediate-states (sixth lresult-tmp)) 
       (list
 	    *number-of-states*
 	    result 
 	    lopen-states
	    lclosed-states 
	    lcompleted-states
	    current-state
	    lintermediate-states
       ) ; values returned of the function
   )
)

