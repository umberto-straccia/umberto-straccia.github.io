;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Definitions and functions related to the Search Space algorithm         %                                         
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             % 
;%%%                                                                         %                    
;%%%                                                                         %
;%%% Modified, in order to implement calculus for signed proposition,        %
;%%% by Antonio Lopreiato                                                    %
;%%%                                                                         %
;%%% February, 20th 1998                                                     %
;%%%                                                                         %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;;---------------------------------------------------------------------------- 
;; number of states
;;--------------------------------------------------------------------------- 

(defvar *number-of-states* 0)

(defun init-number-of-states ()
   (setq *number-of-states* 0)
)

;;---------------------------------------------------------------------------- 
;; Sat state type definition

            
(defstruct sat-state
    id                            ; the key id for the state
    pred                          ; predecessor states
    succ                          ; succesor states
    (info nil :type sat-state-info)  ; our data information 
)

(defstruct sat-state-info
    andl                        ; list of ANDs
    orl                         ; list of ORs
    posl                        ; list of positive letters
    negl                        ; list of negative  letters
    nposl                    ; list of positive not's, i.e. (TT (not A))
    nnegl                    ; list of negative not's, i.e. (NT (not A))
    posl-modified               ; boolean = true iff posl modified
    negl-modified               ; boolean = true iff negl modified
    nposl-modified           ; boolean = true iff not-posl modified
    nnegl-modified           ; boolean = true iff not-negl modified
)

(defun sat-state-make (state info-arg)
 (progn
    (setq newid (incf *number-of-states*))
    (setf (sat-state-succ state) (push newid (sat-state-succ state)))
    (setq result (make-sat-state 
                    :id newid 
                    :pred (sat-state-id state)
                    :succ ()
                    :info info-arg))
    result ; returned value
                    
 )
)

(defun sat-initial-state-make (argl)
 (progn
    (setq result nil)
    (setq newid (incf *number-of-states*))
    (setq sat-state-info-tmp
            (sat-state-info-make-from-choice argl () () () () () () nil nil nil nil))        
     
    (setq result (make-sat-state :id newid
                                 :pred ()
                                 :succ ()
                                 :info sat-state-info-tmp))
     result   ; returned result
 )
)

(defun sat-state-info-make 
    (andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)
 (make-sat-state-info  :andl andl-arg 
                       :orl  orl-arg 
                       :posl posl-arg 
                       :negl negl-arg 
                       :nposl not-posl-arg
                       :nnegl not-negl-arg
                       :posl-modified posl-modified-arg  
                       :negl-modified negl-modified-arg
                       :nposl-modified not-posl-modified-arg  
                       :nnegl-modified not-negl-modified-arg)
                                                   
)

;;--------------------------------------------------------------------------- 
;;
;; sat-state-info-from-choice
;; (arg-list andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg 
;;  posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)  
;;
;; input : arg-list which is a sub-signed-formula, other arguments are 
;;         informations on previous state 
;;
;; output: information field for new state
;;
;;--------------------------------------------------------------------------- 

(defun sat-state-info-make-from-choice 
  (arg-list andl-arg orl-arg posl-arg negl-arg not-posl-arg not-negl-arg posl-modified-arg negl-modified-arg not-posl-modified-arg not-negl-modified-arg)  
   (progn 
     (dolist (arg arg-list)        
     	(setq fp (s-fp-getformula arg))
     	(setq p (fp-get-propos fp))     	     	     					
	(if (s-fp-isTT arg)
            (cond ((p-isbot p)
		   (pushnew BOT posl-arg)
		   (setq posl-modified-arg t)
		  )
		  ((p-isvar p)
		   (pushnew fp posl-arg)
		   (setq posl-modified-arg t)		       
		  )	    	      
		  ((p-isnot p)
		   (pushnew fp not-posl-arg)
		   (setq not-posl-modified-arg t)
		  )
		  ((p-isand p)
		   (pushnew fp andl-arg)
		  )
		  ((p-isor p)
		   (pushnew fp orl-arg)
		  )
	     )
	     (cond ((p-istop p)
	            (pushnew TOP negl-arg)
	            (setq negl-modified-arg t)
		   )
	           ((p-isvar p)
		    (pushnew fp negl-arg)
		    (setq negl-modified-arg t)		       
		   )
		   ((p-isnot p)
		    (pushnew fp not-negl-arg)
		    (setq not-negl-modified-arg t)
		   )
		   ((p-isand p)
		    (pushnew fp orl-arg)
		   )
		   ((p-isor p)
		    (pushnew fp andl-arg)
		   )
              )
	 )
      )
        (setq result (sat-state-info-make 
                       andl-arg                               ; andl
                       orl-arg                                ; orl
                       posl-arg                               ; posl
                       negl-arg                               ; negl
                       not-posl-arg                           ; not-posl
                       not-negl-arg                           ; not-negl
                       posl-modified-arg                      ; posl-modified
                       negl-modified-arg                      ; negl-modified
                       not-posl-modified-arg                  ; not-posl-modified
                       not-negl-modified-arg                  ; not-negl-modified
                     )
	      )                  
        result
  )
)

;;--------------------------------------------------------------------------- 
;; sat-closed-state (state)
;; Input  : state = a state
;; Return : true iff state is closed
;;          a state is closed whenever either
;;          1. BOT is in posl
;;          2. TOP is in negl
;;          3. there is a clash according to the fuzzy logic rules
;;
;;--------------------------------------------------------------------------- 

(defun 2V-sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info)            
              (sat-state-info-nposl-modified sat-info) 
              (sat-state-info-nnegl-modified sat-info))
            ; check return condition
            (setq result (2v-sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)
                              (sat-state-info-nposl sat-info)
                              (sat-state-info-nnegl sat-info)))            
            (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
)

(defun 4V-sat-closed-state (state)
 (progn 
      (setq result nil)
      (setq sat-info (sat-state-info state))
      (if (or (sat-state-info-posl-modified sat-info) 
              (sat-state-info-negl-modified sat-info)            
              (sat-state-info-nposl-modified sat-info) 
              (sat-state-info-nnegl-modified sat-info))
            ; check return condition
            (setq result (4v-sat-closed-state-test 
                              (sat-state-info-posl sat-info)
                              (sat-state-info-negl sat-info)
                              (sat-state-info-nposl sat-info)
                              (sat-state-info-nnegl sat-info)))            
            (setq result  nil) ; nothing has been modified, so return false
      )    
      result  ; returns result.
 )
)

;; test for sat-closed-state 
;;

(defun 2V-sat-closed-state-test (pl nl npl nnl) 
  (or (member BOT pl)  ; false test
      (member TOP nl)  ; true test                    
      ; check if there is complementary pair
      (some #'(lambda (x) 
        (some #'(lambda (y) 
           (and (equal (fp-get-propos x) (fp-get-propos y)) 
                (>= (fp-get-degree x) (fp-get-degree y))))
             nl)) pl)
      (some #'(lambda (x) 
        (some #'(lambda (y) 
           (and (equal (fp-get-propos x) (p-get-argument (fp-get-propos y))) 
                (> (fp-get-degree x) (- 1 (fp-get-degree y)))))
             npl)) pl)       
      (some #'(lambda (x) 
        (some #'(lambda (y) 
           (and (equal (fp-get-propos x) (p-get-argument (fp-get-propos y))) 
                (<= (fp-get-degree x) (- 1 (fp-get-degree y)))))
             nnl)) nl)       
      (some #'(lambda (x) 
        (some #'(lambda (y) 
           (and (equal (p-get-argument (fp-get-propos x)) (p-get-argument (fp-get-propos y))) 
                (>= (fp-get-degree x) (fp-get-degree y))))
             nnl)) npl)       
  ) 
) 

(defun 4V-sat-closed-state-test (pl nl npl nnl) 
 (or (member BOT pl)  ; false test
     (member TOP nl)  ; true test    
     ; check if there is complementary pair
     (some #'(lambda (x) 
        (some #'(lambda (y) 
           (and (equal (fp-get-propos x) (fp-get-propos y)) 
                (>= (fp-get-degree x) (fp-get-degree y))))
             nl)) pl)     
     (some #'(lambda (x) 
        (some #'(lambda (y) 
           (and (equal (fp-get-propos x) (fp-get-propos y)) 
                (>= (fp-get-degree x) (fp-get-degree y))))
             nnl)) npl)  
 )
) 

;;--------------------------------------------------------------------------- 
;; sat-get-new-states (state)
;;
;; Input  : a state
;; Return : list of new states to be solved, generated from current-state
;;          applying the following simple rules. 
;;          Remember that the initial proposition should be in NNF.
;;
;;                T((and A1 ... An) k)                    
;;         (A)   -------------------------         
;;                T(A1 k), ... , T(An k)                 
;;
;;
;;                 NT((or A1 ... An) k)
;;         (A)   ------------------------    
;;                NT(A1 k), ... , NT(An k)
;;     
;;
;;                        T((or A1 A2... An) k)
;;         (PB)  ------------------------------------------           
;;               T(A1 k)  |  NT(A1 k), T((or A2 ... An) k)
;;
;;
;;
;;                        NT((and A1 A2... An) k)
;;         (PB)  ---------------------------------------------           
;;               NT(A1 k)  |  T(A1 k), NT((and A2 ... An) k)
;;
;;
;;          the only branching rule is (PB).
;;          the priority between rules is  (A) > (PB)
;;
;;--------------------------------------------------------------------------- 
               

(defun sat-get-new-states (state)
  (progn
    (setq result nil)
    (setq sat-info (sat-state-info state))
    (cond ((sat-state-info-andl sat-info)
	   (setq result (sat-and-get-new-states state))
	  )
	  ((sat-state-info-orl sat-info)       
	   (setq result (sat-or-get-new-states state))      	
	  )
	  (t (setq result ()))
	  )
    result
    )
)

(defun sat-and-get-new-states (state)
  (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-nposl info-tmp))
    (setq not-negl-tmp  (sat-state-info-nnegl info-tmp))
    ;(setq posl-modified-tmp nil)
    ;(setq negl-modified-tmp nil)
    ;(setq not-posl-modified-tmp nil)
    ;(setq not-negl-modified-tmp nil)
    (setq and-args ())
    (dolist (arg andl-tmp)   
        (setq arg-p (fp-get-propos arg))
        (setq arg-d (fp-get-degree arg))
        (cond ((p-isand arg-p)
	       (setq and-args (concatenate 'list and-args 
	                         (make-TT-fp-list (mapcar #'(lambda (p) (mk-fuzzy-prop p arg-d)) 
	                                             (p-get-arguments arg-p)))))
	      )
	      ((p-isor arg-p)
               (setq and-args (concatenate 'list and-args 
                                 (make-NT-fp-list (mapcar #'(lambda (p) (mk-fuzzy-prop p arg-d))
                                                     (p-get-arguments arg-p)))))
	      )
        )
    )
    (setq sat-state-info-tmp
	  (sat-state-info-make-from-choice
	   and-args
	   nil ;andl-tmp                               ; andl
           orl-tmp                                ; orl
           posl-tmp                               ; posl
           negl-tmp                               ; negl
           not-posl-tmp                           ; not-posl
           not-negl-tmp                           ; not-negl
           nil ;posl-modified-tmp                      ; posl-modified
           nil ;negl-modified-tmp                      ; negl-modified
           nil ;not-posl-modified-tmp                  ; not-posl-modified
           nil ;not-negl-modified-tmp                  ; not-negl-modified
	  )
    )
    (setq result (sat-state-make state sat-state-info-tmp))
    (list result)
    )
  )



(defun sat-or-get-new-states (state)
 (progn
    (setq result nil)
    (setq info-tmp  (sat-state-info state))
    (setq andl-tmp  (sat-state-info-andl info-tmp))   
    (setq orl-tmp   (sat-state-info-orl info-tmp))
    (setq posl-tmp  (sat-state-info-posl info-tmp))
    (setq negl-tmp  (sat-state-info-negl info-tmp))
    (setq not-posl-tmp  (sat-state-info-nposl info-tmp))
    (setq not-negl-tmp  (sat-state-info-nnegl info-tmp))
    ;(setq posl-modified-tmp nil)
    ;(setq negl-modified-tmp nil)
    ;(setq not-posl-modified-tmp nil)
    ;(setq not-negl-modified-tmp nil)       
    (setq p (fp-get-propos (first orl-tmp)))
    (setq d (fp-get-degree (first orl-tmp)))
    (setq orl-tmp (rest orl-tmp))
    (cond ((p-isor p)
              (progn
	         (setq primo (first (p-get-arguments p)))
	         (setq resto (rest (p-get-arguments p)))
	         (setq arg (s-fp-mkTT (mk-fuzzy-prop primo d)))
	         (setq notA1 (s-fp-mkNT (mk-fuzzy-prop primo d)))
	         (if (= 1 (length resto))
                     (setq orA1 (s-fp-mkTT (mk-fuzzy-prop (car resto) d)))                        
                     (setq orA1 (s-fp-mkTT (mk-fuzzy-prop (p-mkor resto) d)))    
                 )
              )
	   )
	   ((p-isand p)
	       (progn
	          (setq primo (first (p-get-arguments p)))
	          (setq resto (rest (p-get-arguments p)))
	          (setq arg (s-fp-mkNT (mk-fuzzy-prop primo d)))
	          (setq notA1 (s-fp-mkTT (mk-fuzzy-prop primo d)))
	          (if (= 1 (length resto))
                     (setq orA1 (s-fp-mkNT (mk-fuzzy-prop (car resto) d)))                        
                     (setq orA1 (s-fp-mkNT (mk-fuzzy-prop (p-mkand resto) d)))    
                  )
	       )
	   )
    )
      (setq sat-state-info-tmp1
            (sat-state-info-make-from-choice
                (list arg) 
                andl-tmp                               ; andl
                orl-tmp                                ; orl
	        posl-tmp                               ; posl
        	negl-tmp                               ; negl
	        not-posl-tmp                           ; not-posl
        	not-negl-tmp                           ; not-negl
	        nil ;posl-modified-tmp                      ; posl-modified
                nil ;negl-modified-tmp                      ; negl-modified
                nil ;not-posl-modified-tmp                  ; not-posl-modified
                nil ;not-negl-modified-tmp                  ; not-negl-modified                    
            )
      )
      (setq sat-state-info-tmp2
            (sat-state-info-make-from-choice
                (list notA1 orA1) 
                andl-tmp                               ; andl
                orl-tmp                                ; orl
                posl-tmp                               ; posl
                negl-tmp                               ; negl
                not-posl-tmp                           ; not-posl
                not-negl-tmp                           ; not-negl
                nil ;posl-modified-tmp                      ; posl-modified
                nil ;negl-modified-tmp                      ; negl-modified
                nil ;not-posl-modified-tmp                  ; not-posl-modified
                nil ;not-negl-modified-tmp                  ; not-negl-modified                    
            )
      )
      (setq newstate1 (sat-state-make state sat-state-info-tmp1))
      (setq newstate2 (sat-state-make state sat-state-info-tmp2))
      (list newstate1 newstate2) 
 )
)

;;--------------------------------------------------------------------------- 
;; sat-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun sat-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (or (null lopen-states)   ; no more states to be processed
                       (not (null lcompleted-states))))   ; there is a not closed completed branch
      result
 )
)  

;;--------------------------------------------------------------------------- 
;; sat-get-result (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a succesful search
;;--------------------------------------------------------------------------- 

(defun sat-get-result (lopen-states lclosed-states lcompleted-states)
 (progn
      ;; return true if there is a not closed and completed state S, i.e. 
      ;; S encodes a model 
      ;; 
      (setq result (not (null lcompleted-states)))
      result
 )
)

;;--------------------------------------------------------------------------- 
;; model-termination (lopen-states lclosed-states lcompleted-states)
;; Input  : 3 lists of states
;; Return : true if they encode a search stop case
;;--------------------------------------------------------------------------- 
            
(defun model-termination (lopen-states lclosed-states lcompleted-states)
 (progn
      (setq result (null lopen-states)) ; no more states to be processed
      result
 )
)  


;;--------------------------------------------------------------------------- 
;; sat-build-models (lcompleted-states)
;; Input  :  lists of completed states
;; Return : list of Herbrand models
;;---------------------------------------------------------------------------

(defun sat-build-models (lcompleted-states)
  (if (null lcompleted-states) 
       nil
      (let ((m (build-models              
                (sat-state-info-posl (sat-state-info (first lcompleted-states)))
                (sat-state-info-nposl (sat-state-info (first lcompleted-states))))))
           (if m (cons m (sat-build-models (rest lcompleted-states)))
                 (sat-build-models (rest lcompleted-states)))
      )           
  )
)

(defun build-models (pl nl)
 (let ((wpl pl) (wnl nl) (model nil))
      (do ((arg (fp-get-propos (car wpl)) (setq arg (fp-get-propos (car wpl)))))
          ((null wpl))
          (setq res1 (find&delete arg wpl))
          (push (first res1) model)
          (setq wpl (second res1))       
      )
      (do ((arg (fp-get-propos (car wnl)) (setq arg (fp-get-propos (car wnl)))))
          ((null wnl))
          (setq res (find&delete arg wnl)) 
          (push (first res) model)
          (setq wnl (second res))
      )
      model
 )
)

(defun find&delete (p ml)
 (let ((degl nil) (rml nil) (p-res nil))
      (mapcar #'(lambda (f) (if (equal (fp-get-propos f) p)
                 	        (push (fp-get-degree f) degl)
                 	        (push f rml)
                 	    )) ml)
      (if degl (setq p-res (list p (apply #'max degl))))                 	    
      (list p-res rml)
 )
)

;;The following are functions for finding the maximal degree n
;;of a fuzzy proposition P such that kb |= (P n), given a kb
;;Note that lmodels is not nil.

(defun lookfor-maxdeg (lmodels p vmin)
  (if (null lmodels) 
      vmin
      (let ((v (p-model-deg (car lmodels) p)))
           (cond ((zerop v) 0)
                 ((> vmin v)
                  (lookfor-maxdeg (cdr lmodels) p v))
      	 	 (t (lookfor-maxdeg (cdr lmodels) p vmin))
           )
      )
  )
)  
      
(defun p-model-deg (model p)                        
  (cond ((p-isand p)
         (and-model-deg model (p-get-arguments p) 1))
        ((p-isor p)
         (or-model-deg model (p-get-arguments p) 0)) 
        (t (literal-model-deg model p))
  )
)  

(defun and-model-deg (model args value)
 (if (null args) 
     value
     (let ((v (p-model-deg model (car args))))
          (cond ((zerop v) 0)
                ((> value v)
                 (and-model-deg model (cdr args) v))
      	 	(t (and-model-deg model (cdr args) value))
          )
     )
 )
) 


(defun or-model-deg (model args value)
 (if (null args) 
     value
     (let ((v (p-model-deg model (car args))))
          (cond ((= 1 v) 1)
                ((< value v)
                 (or-model-deg model (cdr args) v))
      	 	(t (or-model-deg model (cdr args) value))
          )
     )
 )
)     

(defun literal-model-deg (model p)
 (cond ((null model) 0)
       ((equal (fp-get-propos (car model)) p)
        (fp-get-degree (car model)))
       (t (literal-model-deg (cdr model) p)))
)

;;---------------------------------------------------------------------------


















