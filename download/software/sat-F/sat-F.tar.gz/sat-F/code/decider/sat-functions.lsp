;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Execute Search Space algorithm                                          %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


;; This file contains the function in order to execute about sat problems

;;--------------------------------------------------------------------------- 
;; fp-sat (fp)
;; Input: fuzzy proposition 
;; Return: result = true if SAT fp
;;--------------------------------------------------------------------------- 

(defun fp-sat (fp) 
 (progn
       (setq sfp (s-fp-mkTT fp))
       (setq result (s-fp-sat-exec (list sfp)))
       (second result) ;; return result
 )
)

;;--------------------------------------------------------------------------- 
;; fp-sat-KB (fp-list)
;; Input: list of fuzzy propositions, i.e. a KB 
;; Return: result = true if SAT fp-list
;;--------------------------------------------------------------------------- 

(defun fp-sat-KB (fp-list) 
 (progn
       (setq sfp-list (make-TT-fp-list fp-list))
       (setq result (s-fp-sat-exec sfp-list))
       (second result) ;; return result
 )
)

;;--------------------------------------------------------------------------- 
;; fp-logically-implies (fkb fp)
;; Input: fkb = list of fuzzy propositions, i.e. a KB 
;;        fp  = a fuzzy proposition
;; Return: result = true if KB |= fp
;;--------------------------------------------------------------------------- 

(defun fp-logically-implies (fkb fp)
 (progn
   (setq sfp-list (make-TT-fp-list fkb))
   (setq sfp (s-fp-mkNT fp))
   (setq result (s-fp-sat-exec (push sfp sfp-list)))
   (not (second result))
 )
)

;;--------------------------------------------------------------------------- 
;; fp-tautology (fp)
;; Input: fp  = a fuzzy proposition
;; Return: result = true if |= fp
;;--------------------------------------------------------------------------- 

(defun fp-tautology (fp)
  (progn
    (setq sfp (s-fp-mkNT fp))   
    (setq result (s-fp-sat-exec (list sfp)))
    (not (second result))
  )
)
 
;;--------------------------------------------------------------------------- 
;; fp-get-a-model (p)
;; Input: a fuzzy proposition 
;; Return: a list of weighted literals in the form (A d) or ((NOT A) d).
;;         (A d) [resp. ((not A) d)] stand for (A >= d) [resp. ((not A) >= d)].
;;         In the two-values calculus literals of form ((not A) >= d)
;;         are equivalent to (A <= (1-d)).
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun fp-get-a-model (fp) 
 (progn
       (setq result (s-fp-sat-exec (list (s-fp-mkTT fp))))
       (setq lcompleted-states (fifth result)) 
       (if (null lcompleted-states)
             nil ; no models
            (first (sat-build-models lcompleted-states)) ;; return first model
       )
 )
)

;;--------------------------------------------------------------------------- 
;; fp-KB-get-a-model (fp-list)
;; Input: a list of fuzzy propositions 
;; Return: a list of weighted literals in the form (A d) or ((NOT A) d).
;;         (A d) [resp. ((not A) d)] stand for (A >= d) [resp. ((not A) >= d)].
;;         In the two-values calculus literals of form ((not A) >= d)
;;         are equivalent to (A <= (1-d)).
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun fp-KB-get-a-model (fp-list) 
 (progn
       (setq result (s-fp-sat-exec (make-TT-fp-list fp-list)))
       (setq lcompleted-states (fifth result))
       (if (null lcompleted-states)
             nil ; no models
            (first (sat-build-models lcompleted-states)) ;; return first model
       )       
 )
)

;;--------------------------------------------------------------------------- 
;; fp-get-all-models (fp)
;; Input: a fuzzy proposition 
;; Return: a list of weighted literals in the form (A d) or ((NOT A) d).
;;         (A d) [resp. ((not A) d)] stand for (A >= d) [resp. ((not A) >= d)].
;;         In the two-values calculus literals of form ((not A) >= d)
;;         are equivalent to (A <= (1-d)).
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun fp-get-all-models (fp) 
 (progn
       (setq result (s-fp-all-models-exec (list (s-fp-mkTT fp))))
       (setq lcompleted-states (fifth result)) 
       (if (null lcompleted-states)
             nil ; no models
            (sat-build-models lcompleted-states) ;; return all models
       )  
 )
)

;;--------------------------------------------------------------------------- 
;; fp-KB-get-all-models (fp-list)
;; Input: a list of fuzzy propositions 
;; Return: a list of weighted literals in the form (A d) or ((NOT A) d).
;;         (A d) [resp. ((not A) d)] stand for (A >= d) [resp. ((not A) >= d)].
;;         In the two-values calculus literals of form ((not A) >= d)
;;         are equivalent to (A <= (1-d)).
;;         Return nil if no models are avalaible
;;--------------------------------------------------------------------------- 

(defun fp-KB-get-all-models (fp-list) 
 (progn
       (setq result (s-fp-all-models-exec (make-TT-fp-list fp-list)))
       (setq lcompleted-states (fifth result)) 
       (if (null lcompleted-states)
             nil ; no models
            (sat-build-models lcompleted-states) ;; return all models
       )        
 )
)

;;--------------------------------------------------------------------------- 
;; fp-maxDegree (fkb p)
;; Input: fkb = list of fuzzy propositions, i.e. a KB 
;;        p  = a proposition
;; Return: the max n belonging to real interval (0,1] such that KB |= (p n),
;;         or 0 if does'nt exist such n 
;;--------------------------------------------------------------------------- 

(defun fp-maxdegree (fkb p)
 (progn
   (setq ml (fp-KB-get-all-models fkb))   
   (if (null ml)
       (if (= 2 *set-calculus*)
           (let ((flag (fp-tautology (mk-fuzzy-prop p 0.5))))
                (if flag 0.5 0))                         
           0
       )
       (lookfor-maxdeg ml p 1)
   ) 
 )
) 

;----------------------------------------------------------------------------
