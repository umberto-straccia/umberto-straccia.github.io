;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
;%%% Executes test                                                           %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                                                                        %
;%%%                                                                         %
;%%% Umberto Straccia                                                        %                                                
;%%% http://faure.iei.pi.cnr.it/~straccia                                    %
;%%% straccia@iei.pi.cnr.it                                                  %                                                
;%%%                                                                         % 
;%%% October, 6th 1997                                                       %
;%%%                                                                         %
;%%% Version 0.0                                                             %
;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

;; execute test with
;; (exec-test 100 4 120 4 4) 
; (exec-test 3 4 8 4 4) ; test

;;--------------------------------------------------------------------------- 
;; exec-test (samples-per-point num-cl-start num-cl-end step nvar)
;; Input: 
;;       samples-per-point            ;; number of samples/point
;;       num-cl-start                 ;; number of clauses : start
;;       num-cl-end                   ;; number of clauses : end
;;       step                         ;; number of clauses : step
;;       nvar                         ;; number of variables
;;
;; Return: prints in *wff-file* the test propositions
;;         prints in *result-file* the test results, in he form
;;         <sat-value> <number-of-states> <time>
;;
;;         where <sat-value> is S (satisfiable), U (not satisfiable)
;;               <number-of-states> is the number of states created
;;               <time> is the time required
;;
;;---------------------------------------------------------------------------



(defun exec-test (samples-per-point num-cl-start num-cl-end step nvar)
 (progn
   (setq *var_num* nvar)
   (setq *result-stream* (open *result-file* :direction :output))
   (setq *wff-stream* (open *wff-file* :direction :output))
   (print-header samples-per-point num-cl-start num-cl-end step)
   (do ((n_cl num-cl-start (+ n_cl step))) ; for each number of clauses
       ((>= n_cl (+ step num-cl-end)))
       (print-clauses-num n_cl)
       (setq *and_br* n_cl)   ; new number of and operants 
       (do ((j 0 (+ j 1))) 
           ((= j samples-per-point))
           (generate_and_test)
       )
   )
   (close  *result-stream*) 
   (close  *wff-stream*)     
 )
)

(defun generate_and_test ()
 (let ((p (s-fp-mkTT (get-3sat-random-fuzzy-prop))))
  (progn
   (print-wff p)
   (if *execute_test* 
      (if (null *timeout*)
          (test_sat p)
          (bounded_test_sat p)
      )
   )
  )
 )
)


(defun test_sat (p) 
 (progn
  (setq *number-of-states* 0)
  (gc t)                    ; GARBAGE COLLECTING
  (setq t1 (get-internal-run-time))
  (setq result (s-fp-sat-exec (list p)))
  (setq t2 (get-internal-run-time))
  (setq deltat (float (/ (- t2 t1) 
                         internal-time-units-per-second
                      )
               )
  )
  (print-sat result deltat)
  )
)

;----------------------------------------------------------------------------





